package com.nexoestore.autoia

data class RuleDecision(
    val shouldReply: Boolean,
    val useGemini: Boolean,
    val reply: String,
    val reason: String
)

object RuleEngine {
    fun decide(
        customerName: String,
        customerMessage: String,
        settings: SettingsStore
    ): RuleDecision {
        val msg = customerMessage.trim()
        val lower = msg.lowercase()

        if (msg.isBlank()) {
            return RuleDecision(false, false, "", "Mensaje vacío")
        }

        if (containsAny(lower, listOf("asesor", "humano", "reclamo", "garantía", "garantia"))) {
            return RuleDecision(true, false, "Claro 😊 Te comunico con un asesor de Nexo E Store para revisar tu caso.", "Derivar a asesor")
        }

        if (lower.contains("netflix") && containsAny(lower, listOf("renov", "renuevo", "renovar", "renovación", "renovacion"))) {
            return RuleDecision(
                true,
                false,
                "Hola 😊 Por el momento no manejamos renovación de Netflix. Tenemos otros servicios disponibles. ¿Deseas que te comparta opciones?",
                "Regla crítica: no renovar Netflix"
            )
        }

        if (settings.isWelcomeEnabled() && isGreeting(lower)) {
            return RuleDecision(true, false, settings.getWelcomeMessage(), "Mensaje de bienvenida")
        }

        if (settings.isMenuEnabled() && containsAny(lower, listOf("menu", "menú", "opciones", "catalogo", "catálogo", "servicios"))) {
            return RuleDecision(true, false, settings.getMenuMessage(), "Menú automático")
        }

        if (settings.areKeywordRulesEnabled()) {
            parseKeywordRules(settings.getKeywordRules()).forEach { (keyword, response) ->
                if (keyword.isNotBlank() && lower.contains(keyword.lowercase())) {
                    return RuleDecision(true, false, response, "Palabra clave: $keyword")
                }
            }
        }

        return RuleDecision(true, true, "", "Sin regla local: consultar Gemini")
    }

    fun parseKeywordRules(raw: String): List<Pair<String, String>> {
        return raw.lines()
            .map { it.trim() }
            .filter { it.isNotBlank() && !it.startsWith("#") && it.contains("=") }
            .mapNotNull { line ->
                val parts = line.split("=", limit = 2)
                val key = parts.getOrNull(0)?.trim().orEmpty()
                val value = parts.getOrNull(1)?.trim().orEmpty()
                if (key.isBlank() || value.isBlank()) null else key to value
            }
    }

    private fun containsAny(text: String, words: List<String>): Boolean {
        return words.any { text.contains(it.lowercase()) }
    }

    private fun isGreeting(text: String): Boolean {
        val cleaned = text.trim().lowercase()
        return cleaned in listOf("hola", "buenas", "buenos dias", "buenos días", "buenas tardes", "buenas noches", "hey", "ola")
    }
}
