package com.nexoestore.autoia

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class AiResponse(
    val ok: Boolean,
    val text: String,
    val diagnostic: String
)

object GeminiService {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json".toMediaType()

    fun isValidKeyFormat(key: String): Boolean {
        val value = key.trim()
        return value.startsWith("AIza") || value.startsWith("AQ")
    }

    fun generate(
        apiKey: String,
        model: String,
        systemPrompt: String,
        userMessage: String
    ): AiResponse {
        val cleanKey = apiKey.trim()
        if (!isValidKeyFormat(cleanKey)) {
            return AiResponse(false, SettingsStore.DEFAULT_FALLBACK, "API Key inválida: debe empezar por AIza o AQ.")
        }

        return try {
            val body = JSONObject()
                .put(
                    "systemInstruction",
                    JSONObject().put(
                        "parts",
                        JSONArray().put(JSONObject().put("text", systemPrompt))
                    )
                )
                .put(
                    "contents",
                    JSONArray().put(
                        JSONObject()
                            .put("role", "user")
                            .put("parts", JSONArray().put(JSONObject().put("text", userMessage)))
                    )
                )
                .put(
                    "generationConfig",
                    JSONObject()
                        .put("temperature", 0.4)
                        .put("maxOutputTokens", 220)
                )

            val url = "https://generativelanguage.googleapis.com/v1beta/models/${model.trim()}:generateContent"

            val request = Request.Builder()
                .url(url)
                .addHeader("x-goog-api-key", cleanKey)
                .addHeader("Content-Type", "application/json")
                .post(body.toString().toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val responseBody = response.body?.string().orEmpty()

                if (!response.isSuccessful) {
                    val detail = extractError(responseBody).ifBlank { responseBody.take(600) }
                    return AiResponse(false, SettingsStore.DEFAULT_FALLBACK, "Gemini error HTTP ${response.code}: $detail")
                }

                val json = JSONObject(responseBody)
                val candidates = json.optJSONArray("candidates")
                if (candidates == null || candidates.length() == 0) {
                    return AiResponse(false, SettingsStore.DEFAULT_FALLBACK, "Gemini respondió sin candidatos. Respuesta: ${responseBody.take(600)}")
                }

                val parts = candidates
                    .getJSONObject(0)
                    .optJSONObject("content")
                    ?.optJSONArray("parts")

                val text = parts
                    ?.let { arr ->
                        buildString {
                            for (i in 0 until arr.length()) {
                                append(arr.getJSONObject(i).optString("text"))
                            }
                        }
                    }
                    ?.trim()
                    .orEmpty()

                if (text.isBlank()) {
                    AiResponse(false, SettingsStore.DEFAULT_FALLBACK, "Gemini respondió vacío. Respuesta: ${responseBody.take(600)}")
                } else {
                    AiResponse(true, text, "Gemini OK. Modelo: $model. Longitud: ${text.length} caracteres.")
                }
            }
        } catch (e: Exception) {
            AiResponse(false, SettingsStore.DEFAULT_FALLBACK, "Error conectando con Gemini: ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    private fun extractError(body: String): String {
        return try {
            JSONObject(body).optJSONObject("error")?.let { error ->
                val message = error.optString("message")
                val status = error.optString("status")
                "$status $message".trim()
            }.orEmpty()
        } catch (_: Exception) {
            ""
        }
    }
}
