# Nexo Auto IA v10 Gemini

Versión avanzada con Gemini, motor de reglas, entrenamiento de negocio y diagnóstico.

## Funciones
- Gemini API real con claves `AQ...` o `AIza...`.
- Motor de reglas antes de llamar a Gemini.
- Regla crítica: Nexo E Store NO renueva Netflix.
- Palabras clave configurables.
- Menú automático configurable.
- Mensaje de bienvenida configurable.
- Entrenamiento/prompt editable.
- Diagnóstico visible de errores Gemini.
- Historial básico.
- Permisos y selección de WhatsApp normal / Business.

## Compilar sin PC
Sube este ZIP a GitHub con el nombre exacto:

`NexoAutoIA_cloudbuild_sin_pc.zip`

Luego ejecuta:

Actions → Construir APK desde ZIP → Run workflow
