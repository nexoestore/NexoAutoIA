package com.nexoestore.autoia

object AutoReplyEngine {

    fun generateReply(
        customerName: String,
        customerMessage: String,
        settings: SettingsStore
    ): String {
        val lower = customerMessage.lowercase()

        if (lower.contains("asesor") || lower.contains("humano") || lower.contains("reclamo") || lower.contains("garantía")) {
            return "Claro, te comunico con un asesor de Nexo E Store para revisar tu caso. 😊"
        }

        val apiKey = settings.getOpenAiApiKey()
        if (apiKey.isBlank()) {
            return settings.getFallbackMessage()
        }

        val response = OpenAiService.createChatResponse(
            apiKey = apiKey,
            model = settings.getAiModel(),
            systemPrompt = settings.getBusinessPrompt(),
            userMessage = """
                Cliente: $customerName
                Mensaje recibido por WhatsApp: $customerMessage
            """.trimIndent()
        )

        return response
            .replace("\n\n\n", "\n")
            .trim()
            .take(settings.getMaxWhatsappChars())
    }
}
