package com.nexoestore.autoia

object AutoReplyEngine {

    fun generateReply(
        customerName: String,
        customerMessage: String,
        settings: SettingsStore,
        diagnostic: Boolean = false
    ): String {
        val lower = customerMessage.lowercase().trim()

        if (lower.isBlank()) return settings.getFallbackMessage()

        if (
            lower.contains("asesor") ||
            lower.contains("humano") ||
            lower.contains("reclamo") ||
            lower.contains("garantía") ||
            lower.contains("garantia")
        ) {
            return "Claro 😊 Te comunico con un asesor de Nexo E Store para revisar tu caso."
        }

        val mode = settings.getResponseMode()

        return when (mode) {
            "WELCOME" -> settings.getWelcomeMessage().limit(settings)
            "MENU" -> settings.getMenuMessage().limit(settings)
            "KEYWORD" -> keywordReply(customerMessage, settings)?.limit(settings) ?: settings.getFallbackMessage()
            "SERVER" -> tryServer(customerName, customerMessage, settings, diagnostic).limit(settings)
            "GEMINI" -> tryGemini(customerName, customerMessage, settings, diagnostic).limit(settings)
            else -> {
                keywordReply(customerMessage, settings)?.limit(settings)
                    ?: tryGemini(customerName, customerMessage, settings, diagnostic).limit(settings)
            }
        }
    }

    fun keywordReply(message: String, settings: SettingsStore): String? {
        val lower = message.lowercase()
        val lines = settings.getKeywordRules().lines()
        for (line in lines) {
            val clean = line.trim()
            if (clean.isBlank() || !clean.contains("=")) continue
            val key = clean.substringBefore("=").trim().lowercase()
            val value = clean.substringAfter("=").trim()
            if (key.isNotBlank() && value.isNotBlank() && lower.contains(key)) return value
        }
        return null
    }

    private fun tryGemini(
        customerName: String,
        customerMessage: String,
        settings: SettingsStore,
        diagnostic: Boolean
    ): String {
        val apiKey = settings.getGeminiApiKey()
        if (!GeminiService.isValidKey(apiKey)) {
            return if (diagnostic) "ERROR: Falta API Key Gemini válida. Debe empezar por AIza." else settings.getFallbackMessage()
        }

        return try {
            GeminiService.createChatResponse(
                apiKey = apiKey,
                model = settings.getGeminiModel(),
                systemPrompt = settings.getBusinessPrompt(),
                userMessage = """
                    Cliente: $customerName
                    Mensaje recibido por WhatsApp: $customerMessage
                """.trimIndent(),
                maxOutputTokens = (settings.getMaxWhatsappChars() / 3).coerceIn(80, 500)
            )
        } catch (e: Exception) {
            if (diagnostic) "ERROR GEMINI: ${e.message}" else settings.getFallbackMessage()
        }
    }

    private fun tryServer(
        customerName: String,
        customerMessage: String,
        settings: SettingsStore,
        diagnostic: Boolean
    ): String {
        val url = settings.getServerUrl()
        if (url.isBlank()) return if (diagnostic) "ERROR: Falta configurar URL del servidor." else settings.getFallbackMessage()

        return try {
            ServerReplyService.getReply(url, customerName, customerMessage)
        } catch (e: Exception) {
            if (diagnostic) "ERROR SERVIDOR: ${e.message}" else settings.getFallbackMessage()
        }
    }

    private fun String.limit(settings: SettingsStore): String =
        this.replace("\n\n\n", "\n").trim().take(settings.getMaxWhatsappChars())
}
