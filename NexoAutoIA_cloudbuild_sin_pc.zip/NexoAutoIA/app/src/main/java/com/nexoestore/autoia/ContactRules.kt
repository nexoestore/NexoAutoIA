package com.nexoestore.autoia

import android.content.Context

object ContactRules {

    fun shouldReply(context: Context, chatTitle: String, messageText: String, settings: SettingsStore): Boolean {
        if (chatTitle.isBlank() || messageText.isBlank()) return false

        val lowerTitle = chatTitle.lowercase()
        val lowerText = messageText.lowercase()

        if (lowerTitle.contains("whatsapp") && (lowerText.contains("mensajes nuevos") || lowerText.contains("new messages"))) {
            return false
        }

        val isPossibleGroup =
            chatTitle.contains(":") ||
            messageText.startsWith("~") ||
            lowerText.contains("@g.us") ||
            lowerTitle.contains("grupo")

        if (isPossibleGroup && !settings.areGroupsEnabled()) return false

        return when (settings.getContactMode()) {
            "ALL" -> true
            "INDIVIDUAL_ONLY" -> !isPossibleGroup
            else -> !isPossibleGroup
        }
    }
}
