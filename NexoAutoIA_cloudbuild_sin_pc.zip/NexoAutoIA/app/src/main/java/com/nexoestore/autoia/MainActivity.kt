package com.nexoestore.autoia

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : Activity() {

    private lateinit var settings: SettingsStore
    private lateinit var content: LinearLayout

    private val bg = 0xFF0B1822.toInt()
    private val card = 0xFF132838.toInt()
    private val accent = 0xFF009688.toInt()
    private val textColor = 0xFFFFFFFF.toInt()
    private val muted = 0xFFB7C0C7.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = SettingsStore(this)
        askNotificationPermissionIfNeeded()
        showMain()
    }

    private fun showMain() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

        val title = TextView(this).apply {
            setTextColor(textColor)
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            text = "Nexo Auto IA"
            setPadding(28, 35, 28, 18)
        }
        root.addView(title)

        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(16, 0, 16, 8)
        }

        val menu = tabButton("MENÚ") { showMenu() }
        val inicio = tabButton("INICIO") { showInicio() }
        val contactos = tabButton("CONTACTOS") { showContactos() }
        val config = tabButton("CONFIG") { showConfiguracion() }

        tabs.addView(menu)
        tabs.addView(inicio)
        tabs.addView(contactos)
        tabs.addView(config)
        root.addView(tabs)

        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 12, 20, 24)
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
        showInicio()
    }

    private fun tabButton(label: String, action: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(textColor)
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(10, 15, 10, 15)
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
    }

    private fun showInicio() {
        content.removeAllViews()

        content.addView(cardView("Respuesta automática", if (settings.isBotEnabled()) "ACTIVADA" else "DESACTIVADA") {
            val sw = Switch(this@MainActivity)
            sw.isChecked = settings.isBotEnabled()
            sw.setOnCheckedChangeListener { _, checked -> settings.setBotEnabled(checked) }
            addView(sw)
        })

        content.addView(cardView("Motor de respuesta", "ChatGPT IA / OpenAI") {
            button("Configurar IA") { showRespuestaIA() }
        })

        content.addView(cardView("Estado del sistema", buildString {
            append("Permiso de notificaciones: abre y activa Nexo Auto IA\n")
            append("WhatsApp soportado: WhatsApp y WhatsApp Business\n")
            append("OpenAI: ${if (settings.getOpenAiApiKey().isBlank()) "Falta API Key" else "Configurado"}")
        }) {
            button("Abrir permiso de notificaciones") {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        })

        content.addView(cardView("Acciones rápidas", "Prueba el comportamiento del bot antes de activarlo.") {
            button("Probar respuesta IA") { showTestReply() }
            button("Ver historial") { showHistorial() }
        })
    }

    private fun showMenu() {
        content.removeAllViews()
        val items = listOf(
            "Apps soportadas" to "WhatsApp normal y WhatsApp Business.",
            "Respuesta de IA" to "Configura ChatGPT para responder clientes.",
            "Respuesta por palabra clave" to "Próxima versión: Netflix, Nequi, soporte.",
            "Respuesta del menú" to "Próxima versión: menú 1, 2, 3, 4.",
            "Mensaje de bienvenida" to "Configura el mensaje inicial.",
            "Respuesta de prueba" to "Simula una respuesta antes de usarla.",
            "Configuración" to "Tiempo, seguridad, prompt y tema."
        )

        items.forEach { (title, desc) ->
            content.addView(cardView(title, desc) {
                if (title == "Respuesta de IA") {
                    button("Abrir") { showRespuestaIA() }
                }
                if (title == "Respuesta de prueba") {
                    button("Probar") { showTestReply() }
                }
            })
        }
    }

    private fun showContactos() {
        content.removeAllViews()

        content.addView(label("Responder automáticamente a"))

        val all = RadioButton(this).apply {
            text = "Todos los chats"
            setTextColor(textColor)
            isChecked = settings.getContactMode() == "ALL"
            setOnClickListener {
                settings.setContactMode("ALL")
                showContactos()
            }
        }

        val unknown = RadioButton(this).apply {
            text = "Números no guardados / clientes nuevos"
            setTextColor(textColor)
            isChecked = settings.getContactMode() == "UNKNOWN_ONLY"
            setOnClickListener {
                settings.setContactMode("UNKNOWN_ONLY")
                showContactos()
            }
        }

        val groups = CheckBox(this).apply {
            text = "Habilitar grupos"
            setTextColor(textColor)
            isChecked = settings.areGroupsEnabled()
            setOnCheckedChangeListener { _, checked -> settings.setGroupsEnabled(checked) }
        }

        content.addView(all)
        content.addView(unknown)
        content.addView(groups)

        content.addView(cardView("Recomendación para Nexo", "Usa clientes nuevos y grupos desactivados para evitar respuestas a contactos personales.") {})
    }

    private fun showConfiguracion() {
        content.removeAllViews()
        content.addView(cardView("Tiempo de respuesta", "${settings.getResponseDelaySeconds()} segundos") {
            val input = EditText(this@MainActivity).apply {
                setText(settings.getResponseDelaySeconds().toString())
                setTextColor(textColor)
                setHintTextColor(muted)
                inputType = InputType.TYPE_CLASS_NUMBER
                hint = "3"
            }
            addView(input)
            button("Guardar tiempo") {
                settings.setResponseDelaySeconds(input.text.toString().toIntOrNull() ?: 3)
                toast("Tiempo guardado")
            }
        })

        content.addView(cardView("Mensaje de respaldo", settings.getFallbackMessage()) {
            val input = EditText(this@MainActivity).apply {
                setText(settings.getFallbackMessage())
                setTextColor(textColor)
                setHintTextColor(muted)
                minLines = 2
            }
            addView(input)
            button("Guardar mensaje") {
                settings.setFallbackMessage(input.text.toString())
                toast("Mensaje guardado")
            }
        })

        content.addView(cardView("Seguridad", "La API Key se guarda localmente en este teléfono. No compartas capturas ni backups con tu clave visible.") {})
    }

    private fun showRespuestaIA() {
        content.removeAllViews()
        content.addView(label("Respuesta de IA"))

        content.addView(cardView("Proveedor", "ChatGPT / OpenAI") {})

        content.addView(cardView("Clave API de OpenAI", "Pega aquí tu API Key. Se guarda localmente.") {
            val keyInput = EditText(this@MainActivity).apply {
                setText(settings.getOpenAiApiKey())
                setTextColor(textColor)
                setHintTextColor(muted)
                hint = "sk-..."
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            }
            addView(keyInput)

            val modelInput = EditText(this@MainActivity).apply {
                setText(settings.getAiModel())
                setTextColor(textColor)
                setHintTextColor(muted)
                hint = "gpt-4o-mini"
            }
            addView(modelInput)

            button("Guardar IA") {
                settings.setOpenAiApiKey(keyInput.text.toString())
                settings.setAiModel(modelInput.text.toString().ifBlank { "gpt-4o-mini" })
                toast("Configuración IA guardada")
            }
        })

        content.addView(cardView("Entrenar IA", "Personaliza las respuestas de Nexo E Store.") {
            val prompt = EditText(this@MainActivity).apply {
                setText(settings.getBusinessPrompt())
                setTextColor(textColor)
                setHintTextColor(muted)
                minLines = 8
                gravity = Gravity.TOP
            }
            addView(prompt)
            button("Guardar entrenamiento") {
                settings.setBusinessPrompt(prompt.text.toString())
                toast("Prompt guardado")
            }
        })
    }

    private fun showTestReply() {
        content.removeAllViews()
        content.addView(label("Respuesta de prueba"))

        val input = EditText(this).apply {
            hint = "Ejemplo: Hola, tienes Netflix?"
            setHintTextColor(muted)
            setTextColor(textColor)
            minLines = 3
        }
        content.addView(input)

        val result = TextView(this).apply {
            setTextColor(textColor)
            textSize = 16f
            setPadding(0, 18, 0, 18)
        }
        content.addView(result)

        button("Generar respuesta") {
            result.text = "Generando..."
            CoroutineScope(Dispatchers.IO).launch {
                val reply = AutoReplyEngine.generateReply(
                    customerName = "Cliente de prueba",
                    customerMessage = input.text.toString(),
                    settings = settings
                )
                withContext(Dispatchers.Main) {
                    result.text = reply
                }
            }
        }.also { content.addView(it) }
    }

    private fun showHistorial() {
        content.removeAllViews()
        content.addView(label("Historial básico"))
        val logs = MessageHistoryStore(this).getLogs().ifBlank { "Aún no hay mensajes respondidos." }
        content.addView(cardView("Mensajes", logs) {
            button("Limpiar historial") {
                MessageHistoryStore(this@MainActivity).clear()
                showHistorial()
            }
        })
    }

    private fun cardView(title: String, desc: String, extra: LinearLayout.() -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(card)
            setPadding(26, 22, 26, 22)
            val params = LinearLayout.LayoutParams(-1, -2)
            params.setMargins(0, 0, 0, 18)
            layoutParams = params

            addView(TextView(this@MainActivity).apply {
                text = title
                setTextColor(textColor)
                textSize = 20f
                typeface = Typeface.DEFAULT_BOLD
            })

            addView(TextView(this@MainActivity).apply {
                text = desc
                setTextColor(muted)
                textSize = 16f
                setPadding(0, 8, 0, 8)
            })

            extra()
        }
    }

    private fun label(value: String): TextView {
        return TextView(this).apply {
            text = value
            setTextColor(accent)
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 10, 0, 18)
        }
    }

    private fun button(value: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = value
            setTextColor(textColor)
            setBackgroundColor(accent)
            setOnClickListener { action() }
        }
    }

    private fun askNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
    }

    private fun toast(value: String) {
        Toast.makeText(this, value, Toast.LENGTH_SHORT).show()
    }
}
