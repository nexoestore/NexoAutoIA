package com.nexoestore.autoia

import android.content.Context
import android.content.SharedPreferences

data class CustomerRecord(
    val id: String,
    val name: String,
    val service: String,
    val duration: String,
    val payment: String,
    val state: String,
    val hot: Boolean,
    val humanPauseUntil: Long,
    val lastMessage: String,
    val lastReply: String,
    val updatedAt: Long
)


class SettingsStore(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("nexo_auto_ia_settings", Context.MODE_PRIVATE)

    fun isBotEnabled(): Boolean = prefs.getBoolean("botEnabled", false)
    fun setBotEnabled(value: Boolean) = prefs.edit().putBoolean("botEnabled", value).apply()

    fun getGeminiApiKey(): String = prefs.getString("geminiApiKey", "") ?: ""
    fun setGeminiApiKey(value: String) = prefs.edit().putString("geminiApiKey", value.trim()).apply()
    fun clearGeminiApiKey() = prefs.edit().remove("geminiApiKey").apply()

    fun getGeminiModel(): String = prefs.getString("geminiModel", "gemini-2.5-flash") ?: "gemini-2.5-flash"
    fun setGeminiModel(value: String) = prefs.edit().putString("geminiModel", value.trim().ifBlank { "gemini-2.5-flash" }).apply()

    fun getBusinessPrompt(): String =
        prefs.getString("businessPrompt", DEFAULT_NEXO_PROMPT) ?: DEFAULT_NEXO_PROMPT

    fun setBusinessPrompt(value: String) =
        prefs.edit().putString("businessPrompt", value.trim().ifBlank { DEFAULT_NEXO_PROMPT }).apply()

    fun getFallbackMessage(): String =
        prefs.getString("fallbackMessage", DEFAULT_FALLBACK) ?: DEFAULT_FALLBACK

    fun setFallbackMessage(value: String) =
        prefs.edit().putString("fallbackMessage", value.trim().ifBlank { DEFAULT_FALLBACK }).apply()

    fun getWelcomeMessage(): String =
        prefs.getString("welcomeMessage", DEFAULT_WELCOME) ?: DEFAULT_WELCOME

    fun setWelcomeMessage(value: String) =
        prefs.edit().putString("welcomeMessage", value.trim().ifBlank { DEFAULT_WELCOME }).apply()

    fun isWelcomeEnabled(): Boolean = prefs.getBoolean("welcomeEnabled", true)
    fun setWelcomeEnabled(value: Boolean) = prefs.edit().putBoolean("welcomeEnabled", value).apply()

    fun getMenuMessage(): String =
        prefs.getString("menuMessage", DEFAULT_MENU) ?: DEFAULT_MENU

    fun setMenuMessage(value: String) =
        prefs.edit().putString("menuMessage", value.trim().ifBlank { DEFAULT_MENU }).apply()

    fun isMenuEnabled(): Boolean = prefs.getBoolean("menuEnabled", true)
    fun setMenuEnabled(value: Boolean) = prefs.edit().putBoolean("menuEnabled", value).apply()

    fun getKeywordRules(): String =
        prefs.getString("keywordRules", DEFAULT_KEYWORDS) ?: DEFAULT_KEYWORDS

    fun setKeywordRules(value: String) =
        prefs.edit().putString("keywordRules", value.trim()).apply()

    fun areKeywordRulesEnabled(): Boolean = prefs.getBoolean("keywordEnabled", true)
    fun setKeywordRulesEnabled(value: Boolean) = prefs.edit().putBoolean("keywordEnabled", value).apply()

    fun getServerUrl(): String = prefs.getString("serverUrl", "") ?: ""
    fun setServerUrl(value: String) = prefs.edit().putString("serverUrl", value.trim()).apply()
    fun isServerEnabled(): Boolean = prefs.getBoolean("serverEnabled", false)
    fun setServerEnabled(value: Boolean) = prefs.edit().putBoolean("serverEnabled", value).apply()

    fun getNotes(): String = prefs.getString("notes", "") ?: ""
    fun setNotes(value: String) = prefs.edit().putString("notes", value).apply()

    fun getMaxWhatsappChars(): Int = prefs.getInt("maxWhatsappChars", 500)
    fun setMaxWhatsappChars(value: Int) = prefs.edit().putInt("maxWhatsappChars", value.coerceIn(80, 1500)).apply()

    fun getResponseDelaySeconds(): Int = prefs.getInt("responseDelaySeconds", 3)
    fun setResponseDelaySeconds(value: Int) = prefs.edit().putInt("responseDelaySeconds", value.coerceIn(0, 60)).apply()

    fun getContactMode(): String = prefs.getString("contactMode", "ALL") ?: "ALL"
    fun setContactMode(value: String) = prefs.edit().putString("contactMode", value).apply()

    fun areGroupsEnabled(): Boolean = prefs.getBoolean("groupsEnabled", false)
    fun setGroupsEnabled(value: Boolean) = prefs.edit().putBoolean("groupsEnabled", value).apply()

    fun getSupportedAppsMode(): String = prefs.getString("supportedAppsMode", "BOTH") ?: "BOTH"
    fun setSupportedAppsMode(value: String) = prefs.edit().putString("supportedAppsMode", value).apply()

    fun getLastDiagnostic(): String = prefs.getString("lastDiagnostic", "Sin diagnóstico todavía.") ?: "Sin diagnóstico todavía."
    fun setLastDiagnostic(value: String) = prefs.edit().putString("lastDiagnostic", value.take(2000)).apply()


    private fun customerKey(value: String): String =
        value.trim().lowercase().replace("|", " ").replace("\n", " ").ifBlank { "cliente" }

    private fun cleanField(value: String): String =
        value.replace("|", " ").replace("\n", " ").trim()

    fun getCustomer(customerName: String): CustomerRecord {
        val key = customerKey(customerName)
        val raw = prefs.getString("crm_$key", "") ?: ""
        if (raw.isBlank()) {
            return CustomerRecord(
                id = key,
                name = customerName.trim().ifBlank { "Cliente" },
                service = "",
                duration = "",
                payment = "",
                state = "NUEVO",
                hot = false,
                humanPauseUntil = 0L,
                lastMessage = "",
                lastReply = "",
                updatedAt = 0L
            )
        }
        val p = raw.split("|")
        return CustomerRecord(
            id = key,
            name = p.getOrNull(0) ?: customerName,
            service = p.getOrNull(1) ?: "",
            duration = p.getOrNull(2) ?: "",
            payment = p.getOrNull(3) ?: "",
            state = p.getOrNull(4) ?: "NUEVO",
            hot = p.getOrNull(5)?.toBooleanStrictOrNull() ?: false,
            humanPauseUntil = p.getOrNull(6)?.toLongOrNull() ?: 0L,
            lastMessage = p.getOrNull(7) ?: "",
            lastReply = p.getOrNull(8) ?: "",
            updatedAt = p.getOrNull(9)?.toLongOrNull() ?: 0L
        )
    }

    fun saveCustomer(record: CustomerRecord) {
        val key = customerKey(record.id)
        val raw = listOf(
            cleanField(record.name),
            cleanField(record.service),
            cleanField(record.duration),
            cleanField(record.payment),
            cleanField(record.state),
            record.hot.toString(),
            record.humanPauseUntil.toString(),
            cleanField(record.lastMessage),
            cleanField(record.lastReply),
            record.updatedAt.toString()
        ).joinToString("|")
        val index = getCustomerIndex().toMutableSet()
        index.add(key)
        prefs.edit()
            .putString("crm_$key", raw)
            .putString("crm_index", index.joinToString("\n"))
            .apply()
    }

    fun updateCustomer(
        customerName: String,
        service: String? = null,
        duration: String? = null,
        payment: String? = null,
        state: String? = null,
        hot: Boolean? = null,
        humanPauseUntil: Long? = null,
        lastMessage: String? = null,
        lastReply: String? = null
    ): CustomerRecord {
        val current = getCustomer(customerName)
        val updated = current.copy(
            id = customerKey(customerName),
            name = customerName.trim().ifBlank { current.name },
            service = service ?: current.service,
            duration = duration ?: current.duration,
            payment = payment ?: current.payment,
            state = state ?: current.state,
            hot = hot ?: current.hot,
            humanPauseUntil = humanPauseUntil ?: current.humanPauseUntil,
            lastMessage = lastMessage ?: current.lastMessage,
            lastReply = lastReply ?: current.lastReply,
            updatedAt = System.currentTimeMillis()
        )
        saveCustomer(updated)
        return updated
    }

    fun getCustomerIndex(): List<String> =
        (prefs.getString("crm_index", "") ?: "")
            .lines()
            .map { it.trim() }
            .filter { it.isNotBlank() }

    fun getAllCustomers(): List<CustomerRecord> =
        getCustomerIndex().map { getCustomer(it) }.sortedByDescending { it.updatedAt }

    fun clearCustomers() {
        val edit = prefs.edit()
        getCustomerIndex().forEach { edit.remove("crm_$it") }
        edit.remove("crm_index").apply()
    }

    fun getCrmSummary(): String {
        val list = getAllCustomers()
        if (list.isEmpty()) return "Aún no hay clientes registrados."
        return list.joinToString("\n\n") { c ->
            val hotTag = if (c.hot) " 🔥" else ""
            "${c.name}$hotTag\nServicio: ${c.service.ifBlank { "sin definir" }}\nEstado: ${c.state}\nPago: ${c.payment.ifBlank { "sin definir" }}\nÚltimo: ${c.lastMessage.take(80)}"
        }
    }

    fun getBroadcastMessage(): String =
        prefs.getString("broadcastMessage", "Hola 😊 Tenemos servicios disponibles: Amazon Prime 2 USD, Max Platino 4.5 USD y Disney Premium 8.5 USD. ¿Deseas activar alguno hoy?") ?: ""

    fun setBroadcastMessage(value: String) =
        prefs.edit().putString("broadcastMessage", value.trim()).apply()

    fun getScheduledMessage(): String =
        prefs.getString("scheduledMessage", "Hola 😊 ¿Aún te interesa tu servicio? Estoy atento para ayudarte.") ?: ""

    fun setScheduledMessage(value: String) =
        prefs.edit().putString("scheduledMessage", value.trim()).apply()

    fun getFollowUpMinutes(): Int = prefs.getInt("followUpMinutes", 30)
    fun setFollowUpMinutes(value: Int) = prefs.edit().putInt("followUpMinutes", value.coerceIn(1, 1440)).apply()

    fun getPendingFollowUps(): List<CustomerRecord> {
        val cutoff = System.currentTimeMillis() - getFollowUpMinutes() * 60_000L
        return getAllCustomers().filter {
            it.hot && it.state in listOf("INTERESADO", "PAGO_PENDIENTE", "ESPERANDO_PAGO") && it.updatedAt > 0L && it.updatedAt < cutoff
        }
    }


    companion object {
        const val DEFAULT_FALLBACK =
            "¡Hola! 😊 Gracias por escribir a Nexo E Store. En breve te ayudamos."

        const val DEFAULT_WELCOME =
            "¡Hola! 😊 Bienvenido a Nexo E Store. ¿Qué servicio necesitas hoy?"

        val DEFAULT_MENU = """
            Menú Nexo E Store 😊
            1. Streaming
            2. Recargas
            3. Métodos de pago
            4. Hablar con asesor
        """.trimIndent()

        val DEFAULT_KEYWORDS = """
            # Reglas locales críticas y de soporte.
            # Los productos disponibles se dejan a Gemini para que actúe como asistente y use el entrenamiento.
            nequi=Puedes pagar por Nequi al 3052154226. Luego envíanos el comprobante para validarlo ✅
            binance=Puedes pagar por Binance al 376619565. Luego envíanos el comprobante para validarlo ✅
            pago=Puedes pagar por Nequi al 3052154226 o por Binance al 376619565. Luego envíanos el comprobante para validarlo ✅
            comprobante=Perfecto ✅ Tu comprobante será validado por un asesor. En breve te confirmamos.
            soporte=Claro, te ayudo con soporte. Envíame tu número de pedido y el problema presentado.
            asesor=Claro 😊 Te comunico con un asesor de Nexo E Store.
        """.trimIndent()

        val DEFAULT_NEXO_PROMPT = """
            Eres el asistente virtual de Nexo E Store.

            Nexo E Store vende servicios de streaming, recargas digitales y productos relacionados.

            Servicios disponibles:
            - Amazon Prime: 2 USD.
            - Max Platino: 4.5 USD.
            - Disney Premium: 8.5 USD.

            Métodos de pago:
            - Nequi: 3052154226.
            - Binance: 376619565.

            Información crítica del negocio:
            - Nexo E Store NO renueva Netflix.
            - Si preguntan por renovación de Netflix, responde que por el momento no se maneja renovación de Netflix y ofrece Amazon Prime, Max Platino o Disney Premium.
            - No inventes precios ni disponibilidad fuera de los servicios listados.
            - No prometas activaciones inmediatas sin validar pago.
            - Si envían comprobante, responde que será validado por un asesor.
            - Si escriben asesor, humano, reclamo o garantía, deriva a atención humana.
            - Si preguntan por precios, responde usando solo los precios listados.
            - Si el cliente dice "1 mes" después de preguntar por Disney, Prime o Max, continúa la conversación sobre ese servicio y pide método de pago.

            Reglas de estilo:
            - Responde en español latino.
            - Sé breve, amable y comercial.
            - Usa máximo 3 líneas.
            - No digas que eres Gemini ni IA.
            - No digas "soy tu asistente".
            - No pidas contraseñas personales.
            - No solicites datos de tarjetas.
            - Si el cliente quiere comprar, pide servicio, duración y método de pago.

            Ejemplos:
            Cliente: ¿Renuevas Netflix?
            Respuesta: Hola 😊 Por el momento no manejamos renovación de Netflix. Tenemos Amazon Prime, Max Platino y Disney Premium disponibles.

            Cliente: ¿Qué tienes disponible?
            Respuesta: Tenemos Amazon Prime por 2 USD, Max Platino por 4.5 USD y Disney Premium por 8.5 USD 😊

            Cliente: Quiero Disney
            Respuesta: Perfecto 😊 Disney Premium cuesta 8.5 USD. ¿Deseas pagar por Nequi o Binance?

            Cliente: ¿Dónde pago?
            Respuesta: Puedes pagar por Nequi al 3052154226 o por Binance al 376619565. Luego envíanos el comprobante para validarlo.
        """.trimIndent()
    }
}
