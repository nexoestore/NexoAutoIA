package com.nexoestore.autoia

object AutoReplyEngine {

    fun generateReply(
        customerName: String,
        customerMessage: String,
        settings: SettingsStore
    ): String {
        val result = generateReplyDetailed(customerName, customerMessage, settings)
        settings.setLastDiagnostic(result.diagnostic)
        return result.text
    }

    fun generateReplyDetailed(
        customerName: String,
        customerMessage: String,
        settings: SettingsStore
    ): AiResponse {
        val decision = RuleEngine.decide(customerName, customerMessage, settings)

        if (!decision.shouldReply) {
            return AiResponse(false, "", decision.reason)
        }

        if (!decision.useGemini) {
            val local = limit(decision.reply, settings)
            return AiResponse(true, local, "Respuesta local: ${decision.reason}")
        }

        if (settings.isServerEnabled() && settings.getServerUrl().isNotBlank()) {
            // Reservado para una integración backend real. Por seguridad, si no hay servidor válido, continúa con Gemini.
        }

        val apiKey = settings.getGeminiApiKey()
        if (apiKey.isBlank()) {
            return AiResponse(false, settings.getFallbackMessage(), "Falta API Key Gemini. Se usó mensaje de respaldo.")
        }

        val prompt = settings.getBusinessPrompt()

        val ai = GeminiService.generate(
            apiKey = apiKey,
            model = settings.getGeminiModel(),
            systemPrompt = prompt,
            userMessage = """
                Cliente: $customerName
                Mensaje recibido por WhatsApp: $customerMessage

                ${RuleEngine.contextForGemini(customerName, settings)}

                Responde como vendedor de Nexo E Store, no como asistente genérico.
                Usa el entrenamiento del negocio, precios y métodos de pago.
                Si el mensaje es seguimiento corto como "1 mes", continúa la venta sin cambiar de servicio.
                No digas "soy tu asistente", no repitas saludos innecesarios y no inventes servicios.
            """.trimIndent()
        )

        val text = if (ai.ok) limit(ai.text, settings) else settings.getFallbackMessage()
        settings.updateCustomer(customerName, lastMessage = customerMessage, lastReply = text)
        return ai.copy(text = text)
    }

    private fun limit(value: String, settings: SettingsStore): String {
        return value
            .replace("\n\n\n", "\n")
            .trim()
            .take(settings.getMaxWhatsappChars())
    }
}
