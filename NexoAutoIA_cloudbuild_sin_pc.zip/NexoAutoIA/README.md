# Nexo Auto IA v9 Gemini

APK Android para responder WhatsApp / WhatsApp Business desde notificaciones usando Gemini.

## Funciones incluidas

- Gemini API en lugar de OpenAI.
- Guardar API Key Gemini.
- Prueba de respuesta con diagnóstico visible.
- Respuesta automática activable/desactivable.
- Apps soportadas: WhatsApp normal, WhatsApp Business o ambos.
- Respuesta por palabra clave.
- Respuesta del menú.
- Mensaje de bienvenida.
- Respuesta desde servidor propio.
- Historial básico.
- Notas internas.
- Configuración de tiempo, modo de respuesta y respaldo.
- Permisos y seguridad.

## Compilación sin PC

Sube este ZIP a GitHub con el nombre:

`NexoAutoIA_cloudbuild_sin_pc.zip`

Luego ejecuta:

Actions → Construir APK desde ZIP → Run workflow

El artifact descargado contiene el APK.
