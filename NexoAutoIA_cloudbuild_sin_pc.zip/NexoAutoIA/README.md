# Nexo Auto IA v7

APK Android para responder WhatsApp usando notificaciones, RemoteInput y OpenAI.

## Cambios v7
- Nueva pestaña PERMISOS.
- Botón directo para Acceso a notificaciones.
- Botón para ajustes de batería.
- Eliminado permiso READ_CONTACTS para reducir advertencias.
- Selector de WhatsApp normal / WhatsApp Business / ambos.
- Mejor guardado de API Key.
- Validación de API Key: debe empezar por `sk-`.
- Historial básico.
- Pantalla de prueba IA.
- Privacidad y uso responsable.

## Importante
La app usa `NotificationListenerService`, por eso Android o Play Protect puede mostrar advertencias. Para máxima estabilidad comercial, la arquitectura recomendada es WhatsApp Cloud API + backend.
