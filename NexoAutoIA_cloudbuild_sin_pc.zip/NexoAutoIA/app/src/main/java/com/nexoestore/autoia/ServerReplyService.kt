package com.nexoestore.autoia

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object ServerReplyService {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(35, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json".toMediaType()

    fun getReply(url: String, customerName: String, customerMessage: String): String {
        val body = JSONObject()
            .put("customerName", customerName)
            .put("message", customerMessage)
            .put("source", "NexoAutoIA")
            .toString()

        val request = Request.Builder()
            .url(url)
            .addHeader("Content-Type", "application/json")
            .post(body.toRequestBody(jsonMediaType))
            .build()

        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw RuntimeException("HTTP ${response.code}: ${raw.take(120)}")
            return try {
                val json = JSONObject(raw)
                json.optString("reply", raw).trim()
            } catch (_: Exception) {
                raw.trim()
            }.ifBlank { throw RuntimeException("Respuesta vacía del servidor.") }
        }
    }
}
