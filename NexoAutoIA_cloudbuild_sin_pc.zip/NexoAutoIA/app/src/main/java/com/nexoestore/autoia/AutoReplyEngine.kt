package com.nexoestore.autoia

object AutoReplyEngine {

    fun generateReply(
        customerName: String,
        customerMessage: String,
        settings: SettingsStore
    ): String {
        val result = generateReplyDetailed(customerName, customerMessage, settings)
        settings.setLastDiagnostic(result.diagnostic)
        return result.text
    }

    fun generateReplyDetailed(
        customerName: String,
        customerMessage: String,
        settings: SettingsStore
    ): AiResponse {
        val stateStore = SalesStateStore(settings.context)
        val decision = SalesAssistantEngine.decide(customerName, customerMessage, settings, stateStore)

        if (!decision.shouldReply) {
            return AiResponse(false, "", decision.reason)
        }

        if (!decision.useGemini) {
            val local = limit(decision.reply, settings)
            return AiResponse(true, local, "Respuesta comercial local: ${decision.reason}")
        }

        if (settings.isServerEnabled() && settings.getServerUrl().isNotBlank()) {
            // Reservado para integración backend futura.
        }

        val apiKey = settings.getGeminiApiKey()
        if (apiKey.isBlank()) {
            return AiResponse(false, settings.getFallbackMessage(), "Falta API Key Gemini. Se usó mensaje de respaldo.")
        }

        val memoryContext = SalesAssistantEngine.buildMemoryContext(customerName, settings)

        val ai = GeminiService.generate(
            apiKey = apiKey,
            model = settings.getGeminiModel(),
            systemPrompt = settings.getBusinessPrompt(),
            userMessage = """
                Cliente: $customerName
                Mensaje recibido por WhatsApp: $customerMessage

                $memoryContext

                Instrucciones finales:
                - Responde como asesor vendedor profesional de Nexo E Store.
                - Sigue el flujo: producto → duración → pago → comprobante → asesor.
                - Usa solo servicios y precios oficiales.
                - Máximo 2 líneas.
                - Si el cliente ya eligió método de pago, entrega solo ese método y pide comprobante.
                - No repitas preguntas ya respondidas.
            """.trimIndent()
        )

        val text = if (ai.ok) limit(ai.text, settings) else settings.getFallbackMessage()
        if (text.isNotBlank()) {
            if (stateStore.shouldSuppressDuplicate(customerName, customerMessage, text)) {
                return AiResponse(false, "", "Anti-spam: Gemini propuso una respuesta repetida recientemente")
            }
            SalesAssistantEngine.rememberGeminiReply(customerName, customerMessage, text, settings)
        }
        return ai.copy(text = text)
    }

    private fun limit(value: String, settings: SettingsStore): String {
        val clean = value
            .replace("\r", "")
            .replace(Regex("\n{3,}"), "\n\n")
            .trim()

        val max = settings.getMaxWhatsappChars().coerceAtLeast(220)
        if (clean.length <= max) return clean

        val cut = clean.take(max)
        val lastSentence = maxOf(cut.lastIndexOf("."), cut.lastIndexOf("?"), cut.lastIndexOf("!"))
        return if (lastSentence > 80) cut.take(lastSentence + 1).trim() else cut.trim()
    }
}
