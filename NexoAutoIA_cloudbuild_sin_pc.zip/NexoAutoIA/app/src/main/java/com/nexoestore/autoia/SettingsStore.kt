package com.nexoestore.autoia

import android.content.Context
import android.content.SharedPreferences

class SettingsStore(val context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("nexo_auto_ia_settings", Context.MODE_PRIVATE)

    fun isBotEnabled(): Boolean = prefs.getBoolean("botEnabled", false)
    fun setBotEnabled(value: Boolean) = prefs.edit().putBoolean("botEnabled", value).apply()

    fun getGeminiApiKey(): String = prefs.getString("geminiApiKey", "") ?: ""
    fun setGeminiApiKey(value: String) = prefs.edit().putString("geminiApiKey", value.trim()).apply()
    fun clearGeminiApiKey() = prefs.edit().remove("geminiApiKey").apply()

    fun getGeminiModel(): String = prefs.getString("geminiModel", "gemini-2.5-flash") ?: "gemini-2.5-flash"
    fun setGeminiModel(value: String) = prefs.edit().putString("geminiModel", value.trim().ifBlank { "gemini-2.5-flash" }).apply()

    fun getBusinessPrompt(): String =
        prefs.getString("businessPrompt", DEFAULT_NEXO_PROMPT) ?: DEFAULT_NEXO_PROMPT

    fun setBusinessPrompt(value: String) =
        prefs.edit().putString("businessPrompt", value.trim().ifBlank { DEFAULT_NEXO_PROMPT }).apply()

    fun getFallbackMessage(): String =
        prefs.getString("fallbackMessage", DEFAULT_FALLBACK) ?: DEFAULT_FALLBACK

    fun setFallbackMessage(value: String) =
        prefs.edit().putString("fallbackMessage", value.trim().ifBlank { DEFAULT_FALLBACK }).apply()

    fun getWelcomeMessage(): String =
        prefs.getString("welcomeMessage", DEFAULT_WELCOME) ?: DEFAULT_WELCOME

    fun setWelcomeMessage(value: String) =
        prefs.edit().putString("welcomeMessage", value.trim().ifBlank { DEFAULT_WELCOME }).apply()

    fun isWelcomeEnabled(): Boolean = prefs.getBoolean("welcomeEnabled", true)
    fun setWelcomeEnabled(value: Boolean) = prefs.edit().putBoolean("welcomeEnabled", value).apply()

    fun getMenuMessage(): String =
        prefs.getString("menuMessage", DEFAULT_MENU) ?: DEFAULT_MENU

    fun setMenuMessage(value: String) =
        prefs.edit().putString("menuMessage", value.trim().ifBlank { DEFAULT_MENU }).apply()

    fun isMenuEnabled(): Boolean = prefs.getBoolean("menuEnabled", true)
    fun setMenuEnabled(value: Boolean) = prefs.edit().putBoolean("menuEnabled", value).apply()

    fun getKeywordRules(): String =
        prefs.getString("keywordRules", DEFAULT_KEYWORDS) ?: DEFAULT_KEYWORDS

    fun setKeywordRules(value: String) =
        prefs.edit().putString("keywordRules", value.trim()).apply()

    fun areKeywordRulesEnabled(): Boolean = prefs.getBoolean("keywordEnabled", true)
    fun setKeywordRulesEnabled(value: Boolean) = prefs.edit().putBoolean("keywordEnabled", value).apply()

    fun getServerUrl(): String = prefs.getString("serverUrl", "") ?: ""
    fun setServerUrl(value: String) = prefs.edit().putString("serverUrl", value.trim()).apply()
    fun isServerEnabled(): Boolean = prefs.getBoolean("serverEnabled", false)
    fun setServerEnabled(value: Boolean) = prefs.edit().putBoolean("serverEnabled", value).apply()

    fun getNotes(): String = prefs.getString("notes", "") ?: ""
    fun setNotes(value: String) = prefs.edit().putString("notes", value).apply()

    fun getMaxWhatsappChars(): Int = prefs.getInt("maxWhatsappChars", 500)
    fun setMaxWhatsappChars(value: Int) = prefs.edit().putInt("maxWhatsappChars", value.coerceIn(80, 1500)).apply()

    fun getResponseDelaySeconds(): Int = prefs.getInt("responseDelaySeconds", 3)
    fun setResponseDelaySeconds(value: Int) = prefs.edit().putInt("responseDelaySeconds", value.coerceIn(0, 60)).apply()

    fun getContactMode(): String = prefs.getString("contactMode", "ALL") ?: "ALL"
    fun setContactMode(value: String) = prefs.edit().putString("contactMode", value).apply()

    fun areGroupsEnabled(): Boolean = prefs.getBoolean("groupsEnabled", false)
    fun setGroupsEnabled(value: Boolean) = prefs.edit().putBoolean("groupsEnabled", value).apply()

    fun getSupportedAppsMode(): String = prefs.getString("supportedAppsMode", "BOTH") ?: "BOTH"
    fun setSupportedAppsMode(value: String) = prefs.edit().putString("supportedAppsMode", value).apply()

    fun getLastDiagnostic(): String = prefs.getString("lastDiagnostic", "Sin diagnóstico todavía.") ?: "Sin diagnóstico todavía."
    fun setLastDiagnostic(value: String) = prefs.edit().putString("lastDiagnostic", value.take(2000)).apply()

    fun isFollowUpEnabled(): Boolean = prefs.getBoolean("followUpEnabled", true)
    fun setFollowUpEnabled(value: Boolean) = prefs.edit().putBoolean("followUpEnabled", value).apply()

    fun getFollowUpMinutes(): Int = prefs.getInt("followUpMinutes", 30)
    fun setFollowUpMinutes(value: Int) = prefs.edit().putInt("followUpMinutes", value.coerceIn(5, 240)).apply()


    companion object {
        const val DEFAULT_FALLBACK =
            "¡Hola! 😊 Gracias por escribir a Nexo E Store. En breve te ayudamos."

        const val DEFAULT_WELCOME =
            "¡Hola! 😊 Bienvenido a Nexo E Store. ¿Qué servicio necesitas hoy?"

        val DEFAULT_MENU = """
            Menú Nexo E Store 😊
            1. Streaming
            2. Recargas
            3. Métodos de pago
            4. Hablar con asesor
        """.trimIndent()

        val DEFAULT_KEYWORDS = """
            # Reglas locales críticas y de soporte.
            # Los productos disponibles se dejan a Gemini para que actúe como asistente y use el entrenamiento.
            nequi=Puedes pagar por Nequi al 3052154226. Luego envíanos el comprobante para validarlo ✅
            binance=Puedes pagar por Binance al 376619565. Luego envíanos el comprobante para validarlo ✅
            pago=Puedes pagar por Nequi al 3052154226 o por Binance al 376619565. Luego envíanos el comprobante para validarlo ✅
            comprobante=Perfecto ✅ Tu comprobante será validado por un asesor. En breve te confirmamos.
            soporte=Claro, te ayudo con soporte. Envíame tu número de pedido y el problema presentado.
            asesor=Claro 😊 Te comunico con un asesor de Nexo E Store.
        """.trimIndent()

        val DEFAULT_NEXO_PROMPT = """
            Eres el asesor comercial de Nexo E Store.

            Objetivo:
            Atender clientes por WhatsApp, vender servicios disponibles, guiar el pago y derivar a un asesor humano cuando sea necesario.

            Servicios disponibles:
            - Amazon Prime: 2 USD.
            - Max Platino: 4.5 USD.
            - Disney Premium: 8.5 USD.

            Métodos de pago:
            - Nequi: 3052154226.
            - Binance: 376619565.

            Flujo comercial obligatorio:
            1. Identificar el servicio.
            2. Confirmar duración.
            3. Confirmar precio.
            4. Preguntar método de pago.
            5. Entregar SOLO el dato del método elegido.
            6. Pedir comprobante.
            7. Indicar que un asesor validará el pago.

            Información crítica del negocio:
            - Nexo E Store NO renueva Netflix.
            - Si preguntan por renovación de Netflix, responde que por el momento no se maneja renovación de Netflix y ofrece Amazon Prime, Max Platino o Disney Premium.
            - No inventes servicios, precios ni disponibilidad.
            - No prometas activación inmediata sin validar pago.
            - Si envían comprobante, responde que será validado por un asesor.
            - Si escriben ayuda, asesor, humano, reclamo, devolución o garantía, deriva a atención humana.
            - No repitas preguntas ya respondidas.
            - Si ya sabes servicio y duración, no vuelvas a pedirlos.
            - Si el cliente elige método de pago, entrega solo ese método.

            Estilo:
            - Responde en español latino.
            - Sé breve, amable, seguro y comercial.
            - Usa máximo 2 líneas.
            - Usa emojis con moderación.
            - No digas que eres Gemini, IA ni bot.
            - No digas "soy tu asistente".
            - No pidas contraseñas personales.
            - No solicites datos de tarjetas.

            Ejemplos:
            Cliente: Disney
            Respuesta: Claro 😊 Disney Premium cuesta 8.5 USD. ¿Lo deseas por 1 mes?

            Cliente: 1 mes de Disney
            Respuesta: Perfecto 😊 Disney Premium por 1 mes cuesta 8.5 USD. ¿Deseas pagar por Nequi o Binance?

            Cliente: Binance
            Respuesta: Puedes pagar por Binance al ID 376619565. Luego envíanos el comprobante para validarlo ✅

            Cliente: Nequi
            Respuesta: Puedes pagar por Nequi al 3052154226. Luego envíanos el comprobante para validarlo ✅

            Cliente: Ayuda
            Respuesta: Claro 😊 Te derivaremos con un asesor para ayudarte mejor.

            Cliente: Netflix
            Respuesta: Por el momento no manejamos renovación de Netflix. Tenemos Amazon Prime, Max Platino y Disney Premium disponibles 😊
        """.trimIndent()
    }
}
