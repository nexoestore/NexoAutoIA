package com.nexoestore.autoia

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : Activity() {

    private lateinit var settings: SettingsStore
    private lateinit var content: LinearLayout

    private val bg = 0xFF07131D.toInt()
    private val card = 0xFF102536.toInt()
    private val card2 = 0xFF173247.toInt()
    private val accent = 0xFF00A884.toInt()
    private val danger = 0xFFB3261E.toInt()
    private val white = 0xFFFFFFFF.toInt()
    private val muted = 0xFFC6D0D6.toInt()
    private val warning = 0xFFFFD166.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = SettingsStore(this)
        askNotificationPermissionIfNeeded()
        showMain()
    }

    private fun showMain() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

        root.addView(TextView(this).apply {
            setTextColor(white)
            textSize = 25f
            typeface = Typeface.DEFAULT_BOLD
            text = "Nexo Auto IA v11"
            setPadding(24, 30, 24, 8)
        })

        val tabs1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(8, 0, 8, 0) }
        val tabs2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(8, 0, 8, 6) }

        tabs1.addView(tabButton("INICIO") { showInicio() })
        tabs1.addView(tabButton("GEMINI") { showGemini() })
        tabs1.addView(tabButton("PROBAR") { showTestReply() })
        tabs2.addView(tabButton("REGLAS") { showReglas() })
        tabs2.addView(tabButton("ENTRENAR") { showEntrenamiento() })
        tabs2.addView(tabButton("PERMISOS") { showPermisos() })
        tabs2.addView(tabButton("HISTORIAL") { showHistorial() })

        root.addView(tabs1)
        root.addView(tabs2)

        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 12, 18, 28)
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
        showInicio()
    }

    private fun showInicio() {
        content.removeAllViews()
        content.addView(label("Panel principal"))

        content.addView(cardView("1. Estado del bot", buildString {
            append(if (settings.isBotEnabled()) "Respuesta automática: ACTIVADA ✅" else "Respuesta automática: DESACTIVADA")
            append("\nPermiso notificaciones: ${if (isNotificationListenerEnabled()) "ACTIVO ✅" else "FALTA ACTIVAR ⚠️"}")
            append("\nGemini: ${if (GeminiService.isValidKeyFormat(settings.getGeminiApiKey())) "API Key guardada ✅" else "Falta API Key válida"}")
            append("\nApps: ${settings.getSupportedAppsMode()}")
        }) {
            val sw = Switch(this@MainActivity).apply {
                text = if (settings.isBotEnabled()) "Bot encendido" else "Bot apagado"
                setTextColor(white)
                isChecked = settings.isBotEnabled()
                setOnCheckedChangeListener { _, checked ->
                    settings.setBotEnabled(checked)
                    toast(if (checked) "Bot activado" else "Bot pausado")
                    showInicio()
                }
            }
            addView(sw)
        })

        content.addView(cardView("2. Acciones obligatorias", "Para que responda WhatsApp necesitas API Gemini + permiso de notificaciones + bot activado.") {
            button("CONFIGURAR GEMINI") { showGemini() }.also { addView(it) }
            button("ABRIR PERMISO DE NOTIFICACIONES") { openNotificationAccessSettings() }.also { addView(it) }
            button("PROBAR RESPUESTA") { showTestReply() }.also { addView(it) }
            button("VER HISTORIAL / DIAGNÓSTICO") { showHistorial() }.also { addView(it) }
        })

        content.addView(cardView("3. Último diagnóstico", settings.getLastDiagnostic()) {})
    }

    private fun showGemini() {
        content.removeAllViews()
        content.addView(label("Gemini API"))

        content.addView(cardView("Paso 1: Guardar API Key Gemini", "Pega la clave completa. Acepta claves que empiezan por AQ o AIza. Se guarda localmente en este teléfono.") {
            val keyInput = EditText(this@MainActivity).apply {
                setText(settings.getGeminiApiKey())
                setTextColor(white)
                setHintTextColor(muted)
                hint = "AQ... o AIza..."
                singleLine = true
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            }
            addView(keyInput)

            button("GUARDAR API KEY GEMINI") {
                val key = keyInput.text.toString().trim()
                if (GeminiService.isValidKeyFormat(key)) {
                    settings.setGeminiApiKey(key)
                    settings.setLastDiagnostic("API Key Gemini guardada correctamente. Formato aceptado.")
                    toast("API Key Gemini guardada")
                    showGemini()
                } else {
                    settings.setLastDiagnostic("API Key inválida. Debe empezar por AQ o AIza y estar completa.")
                    toast("No se guardó: debe empezar por AQ o AIza")
                    showGemini()
                }
            }.also { addView(it) }

            redButton("BORRAR API KEY GUARDADA") {
                settings.clearGeminiApiKey()
                settings.setLastDiagnostic("API Key Gemini borrada.")
                toast("API Key borrada")
                showGemini()
            }.also { addView(it) }

            addView(statusLine(if (GeminiService.isValidKeyFormat(settings.getGeminiApiKey())) "Estado: API Key guardada ✅" else "Estado: falta API Key válida ⚠️"))
        })

        content.addView(cardView("Paso 2: Modelo y límite", "Modelo recomendado: gemini-2.5-flash. El límite evita mensajes largos en WhatsApp.") {
            val modelInput = EditText(this@MainActivity).apply {
                setText(settings.getGeminiModel())
                setTextColor(white)
                setHintTextColor(muted)
                hint = "gemini-2.5-flash"
                singleLine = true
            }
            val charsInput = EditText(this@MainActivity).apply {
                setText(settings.getMaxWhatsappChars().toString())
                setTextColor(white)
                setHintTextColor(muted)
                hint = "500"
                inputType = InputType.TYPE_CLASS_NUMBER
                singleLine = true
            }
            addView(modelInput)
            addView(charsInput)

            button("GUARDAR MODELO Y LÍMITE") {
                settings.setGeminiModel(modelInput.text.toString())
                settings.setMaxWhatsappChars(charsInput.text.toString().toIntOrNull() ?: 500)
                settings.setLastDiagnostic("Modelo guardado: ${settings.getGeminiModel()}, límite ${settings.getMaxWhatsappChars()} caracteres.")
                toast("Modelo guardado")
                showGemini()
            }.also { addView(it) }
        })

        content.addView(cardView("Paso 3: Diagnóstico Gemini real", "Este botón llama a Gemini realmente. Si falla, verás el error exacto en Historial.") {
            button("PROBAR CONEXIÓN GEMINI") {
                runGeminiDiagnostic()
            }.also { addView(it) }

            button("IR A PRUEBA DE RESPUESTA") { showTestReply() }.also { addView(it) }
        })

        content.addView(cardView("Resultado actual", settings.getLastDiagnostic()) {})
    }

    private fun showReglas() {
        content.removeAllViews()
        content.addView(label("Motor de reglas"))

        content.addView(cardView("Reglas críticas activas", "Antes de usar Gemini, la app revisa reglas locales: asesor, no renovar Netflix, bienvenida, menú y palabras clave.") {})

        content.addView(cardView("Palabras clave", "Formato: palabra=respuesta. Una regla por línea. Ejemplo: disney=Claro, te ayudo con Disney+.") {
            val enabled = CheckBox(this@MainActivity).apply {
                text = "Activar palabras clave"
                setTextColor(white)
                isChecked = settings.areKeywordRulesEnabled()
                setOnCheckedChangeListener { _, checked -> settings.setKeywordRulesEnabled(checked) }
            }
            val input = EditText(this@MainActivity).apply {
                setText(settings.getKeywordRules())
                setTextColor(white)
                setHintTextColor(muted)
                minLines = 7
                gravity = Gravity.TOP
            }
            addView(enabled)
            addView(input)
            button("GUARDAR PALABRAS CLAVE") {
                settings.setKeywordRules(input.text.toString())
                settings.setLastDiagnostic("Palabras clave guardadas.")
                toast("Reglas guardadas")
            }.also { addView(it) }
        })

        content.addView(cardView("Menú automático", "Se usa cuando el cliente escribe menú, opciones, catálogo o servicios.") {
            val enabled = CheckBox(this@MainActivity).apply {
                text = "Activar menú automático"
                setTextColor(white)
                isChecked = settings.isMenuEnabled()
                setOnCheckedChangeListener { _, checked -> settings.setMenuEnabled(checked) }
            }
            val input = EditText(this@MainActivity).apply {
                setText(settings.getMenuMessage())
                setTextColor(white)
                setHintTextColor(muted)
                minLines = 4
                gravity = Gravity.TOP
            }
            addView(enabled)
            addView(input)
            button("GUARDAR MENÚ") {
                settings.setMenuMessage(input.text.toString())
                settings.setLastDiagnostic("Menú automático guardado.")
                toast("Menú guardado")
            }.also { addView(it) }
        })

        content.addView(cardView("Mensaje de bienvenida", "Se usa para saludos simples como hola, buenas o hey.") {
            val enabled = CheckBox(this@MainActivity).apply {
                text = "Activar bienvenida"
                setTextColor(white)
                isChecked = settings.isWelcomeEnabled()
                setOnCheckedChangeListener { _, checked -> settings.setWelcomeEnabled(checked) }
            }
            val input = EditText(this@MainActivity).apply {
                setText(settings.getWelcomeMessage())
                setTextColor(white)
                setHintTextColor(muted)
                minLines = 3
            }
            addView(enabled)
            addView(input)
            button("GUARDAR BIENVENIDA") {
                settings.setWelcomeMessage(input.text.toString())
                settings.setLastDiagnostic("Mensaje de bienvenida guardado.")
                toast("Bienvenida guardada")
            }.also { addView(it) }
        })
    }

    private fun showEntrenamiento() {
        content.removeAllViews()
        content.addView(label("Entrenamiento Gemini"))

        content.addView(cardView("Qué hace esta sección", "Este prompt se envía a Gemini en cada respuesta. Aquí debes poner servicios disponibles, servicios NO disponibles, horarios, métodos de pago y reglas del negocio.") {})

        content.addView(cardView("Prompt del negocio", "Edita y guarda. Regla incluida: Nexo E Store NO renueva Netflix.") {
            val prompt = EditText(this@MainActivity).apply {
                setText(settings.getBusinessPrompt())
                setTextColor(white)
                setHintTextColor(muted)
                minLines = 8
                gravity = Gravity.TOP
            }
            addView(prompt)

            button("GUARDAR ENTRENAMIENTO") {
                settings.setBusinessPrompt(prompt.text.toString())
                settings.setLastDiagnostic("Entrenamiento Gemini guardado.")
                toast("Entrenamiento guardado")
            }.also { addView(it) }

            button("RESTAURAR PROMPT NEXO") {
                settings.setBusinessPrompt(SettingsStore.DEFAULT_NEXO_PROMPT)
                settings.setLastDiagnostic("Prompt restaurado al valor recomendado.")
                toast("Prompt restaurado")
                showEntrenamiento()
            }.also { addView(it) }
        })

        content.addView(cardView("Notas internas", "Estas notas no se envían automáticamente a Gemini. Son para guardar datos y luego copiarlos al prompt.") {
            val notes = EditText(this@MainActivity).apply {
                setText(settings.getNotes())
                setTextColor(white)
                setHintTextColor(muted)
                minLines = 4
                gravity = Gravity.TOP
                hint = "Ejemplo: Disney 1 mes, métodos de pago, horarios..."
            }
            addView(notes)
            button("GUARDAR NOTAS") {
                settings.setNotes(notes.text.toString())
                settings.setLastDiagnostic("Notas internas guardadas.")
                toast("Notas guardadas")
            }.also { addView(it) }
        })
    }

    private fun showPermisos() {
        content.removeAllViews()
        content.addView(label("Permisos y apps"))

        content.addView(cardView("1. Acceso a notificaciones", buildString {
            append("Estado: ${if (isNotificationListenerEnabled()) "ACTIVO ✅" else "NO ACTIVADO ⚠️"}")
            append("\nObligatorio para leer mensajes de WhatsApp y responder desde la notificación.")
        }) {
            button("ABRIR ACCESO A NOTIFICACIONES") { openNotificationAccessSettings() }.also { addView(it) }
            button("ABRIR AJUSTES DE LA APP") { openAppDetailsSettings() }.also { addView(it) }
            addView(statusLine("Si Android dice permiso restringido, entra a Ajustes de la app y busca 'Permitir ajustes restringidos' o instala versión release firmada. Algunos Android bloquean APKs externas."))
        })

        content.addView(cardView("2. Batería", "Desactiva optimización de batería para que Android no duerma la app.") {
            button("ABRIR AJUSTES DE BATERÍA") {
                try {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                } catch (_: Exception) {
                    openAppDetailsSettings()
                }
            }.also { addView(it) }
        })

        content.addView(cardView("3. Apps soportadas", "Elige dónde responder.") {
            radio("WhatsApp normal", settings.getSupportedAppsMode() == "WHATSAPP") {
                settings.setSupportedAppsMode("WHATSAPP")
                showPermisos()
            }
            radio("WhatsApp Business", settings.getSupportedAppsMode() == "BUSINESS") {
                settings.setSupportedAppsMode("BUSINESS")
                showPermisos()
            }
            radio("Ambos", settings.getSupportedAppsMode() == "BOTH") {
                settings.setSupportedAppsMode("BOTH")
                showPermisos()
            }
        })

        content.addView(cardView("4. Contactos y grupos", "Por seguridad, grupos vienen desactivados.") {
            radio("Responder chats individuales", settings.getContactMode() == "ALL") {
                settings.setContactMode("ALL")
                showPermisos()
            }
            radio("Modo seguro: evitar grupos", settings.getContactMode() == "UNKNOWN_ONLY") {
                settings.setContactMode("UNKNOWN_ONLY")
                showPermisos()
            }
            val groups = CheckBox(this@MainActivity).apply {
                text = "Habilitar grupos"
                setTextColor(white)
                isChecked = settings.areGroupsEnabled()
                setOnCheckedChangeListener { _, checked -> settings.setGroupsEnabled(checked) }
            }
            addView(groups)
        })
    }

    private fun showTestReply() {
        content.removeAllViews()
        content.addView(label("Respuesta de prueba"))

        content.addView(cardView("Prueba local + Gemini", "Escribe como cliente. Primero se aplican reglas; si no hay regla local, consulta Gemini.") {
            val input = EditText(this@MainActivity).apply {
                hint = "Ejemplo: ¿Renuevas Netflix?"
                setHintTextColor(muted)
                setTextColor(white)
                minLines = 2
                setText("Hola, quiero Disney por un mes")
            }
            val result = TextView(this@MainActivity).apply {
                setTextColor(white)
                textSize = 16f
                setPadding(0, 16, 0, 16)
                text = "Resultado pendiente."
            }

            addView(input)

            button("GENERAR RESPUESTA") {
                result.text = "Generando..."
                CoroutineScope(Dispatchers.IO).launch {
                    val reply = AutoReplyEngine.generateReplyDetailed(
                        customerName = "Cliente de prueba",
                        customerMessage = input.text.toString(),
                        settings = settings
                    )
                    settings.setLastDiagnostic(reply.diagnostic)
                    MessageHistoryStore(this@MainActivity).addLog("Cliente de prueba", input.text.toString(), reply.text, reply.diagnostic)
                    withContext(Dispatchers.Main) {
                        result.text = "Respuesta:\n${reply.text}\n\nDiagnóstico:\n${reply.diagnostic}"
                    }
                }
            }.also { addView(it) }

            button("PROBAR NETFLIX NO RENOVACIÓN") {
                input.setText("Hola, ¿me renuevas Netflix?")
            }.also { addView(it) }

            button("PROBAR MENÚ") {
                input.setText("menú")
            }.also { addView(it) }

            addView(result)
        })
    }

    private fun showHistorial() {
        content.removeAllViews()
        content.addView(label("Historial y diagnóstico"))

        content.addView(cardView("Último diagnóstico", settings.getLastDiagnostic()) {
            button("PROBAR CONEXIÓN GEMINI") { runGeminiDiagnostic() }.also { addView(it) }
        })

        val logs = MessageHistoryStore(this).getLogs().ifBlank { "Aún no hay mensajes respondidos." }
        content.addView(cardView("Mensajes", logs) {
            button("LIMPIAR HISTORIAL") {
                MessageHistoryStore(this@MainActivity).clear()
                toast("Historial limpio")
                showHistorial()
            }.also { addView(it) }
        })

        content.addView(cardView("Mensaje de respaldo", settings.getFallbackMessage()) {
            val input = EditText(this@MainActivity).apply {
                setText(settings.getFallbackMessage())
                setTextColor(white)
                setHintTextColor(muted)
                minLines = 3
            }
            addView(input)
            button("GUARDAR RESPALDO") {
                settings.setFallbackMessage(input.text.toString())
                settings.setLastDiagnostic("Mensaje de respaldo guardado.")
                toast("Mensaje de respaldo guardado")
            }.also { addView(it) }
        })
    }

    private fun runGeminiDiagnostic() {
        toast("Probando Gemini...")
        CoroutineScope(Dispatchers.IO).launch {
            val key = settings.getGeminiApiKey()
            val result = GeminiService.generate(
                apiKey = key,
                model = settings.getGeminiModel(),
                systemPrompt = settings.getBusinessPrompt(),
                userMessage = "Responde solo: Diagnóstico Nexo OK"
            )
            val diagnostic = if (result.ok) {
                "Gemini conectado correctamente. Respuesta: ${result.text.take(120)}"
            } else {
                result.diagnostic
            }
            settings.setLastDiagnostic(diagnostic)
            withContext(Dispatchers.Main) {
                toast(if (result.ok) "Gemini OK" else "Gemini falló")
                showHistorial()
            }
        }
    }

    private fun openNotificationAccessSettings() {
        try {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        } catch (_: Exception) {
            openAppDetailsSettings()
        }
    }

    private fun openAppDetailsSettings() {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
        intent.data = Uri.parse("package:$packageName")
        startActivity(intent)
    }

    private fun isNotificationListenerEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return enabled.lowercase().contains(packageName.lowercase())
    }

    private fun tabButton(label: String, action: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(white)
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(4, 12, 4, 12)
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
    }

    private fun cardView(title: String, desc: String, extra: LinearLayout.() -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(card)
            setPadding(22, 18, 22, 18)
            val params = LinearLayout.LayoutParams(-1, -2)
            params.setMargins(0, 0, 0, 14)
            layoutParams = params

            addView(TextView(this@MainActivity).apply {
                text = title
                setTextColor(white)
                textSize = 18f
                typeface = Typeface.DEFAULT_BOLD
            })

            addView(TextView(this@MainActivity).apply {
                text = desc
                setTextColor(muted)
                textSize = 14.5f
                setPadding(0, 8, 0, 10)
            })

            extra()
        }
    }

    private fun label(value: String): TextView {
        return TextView(this).apply {
            text = value
            setTextColor(accent)
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 8, 0, 16)
        }
    }

    private fun statusLine(value: String): TextView {
        return TextView(this).apply {
            text = value
            setTextColor(warning)
            textSize = 13.5f
            setPadding(0, 10, 0, 4)
        }
    }

    private fun button(value: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = value
            setTextColor(white)
            setBackgroundColor(accent)
            setPadding(8, 8, 8, 8)
            setOnClickListener { action() }
        }
    }

    private fun redButton(value: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = value
            setTextColor(white)
            setBackgroundColor(danger)
            setPadding(8, 8, 8, 8)
            setOnClickListener { action() }
        }
    }

    private fun LinearLayout.radio(value: String, checked: Boolean, action: () -> Unit) {
        addView(RadioButton(this@MainActivity).apply {
            text = value
            setTextColor(white)
            isChecked = checked
            setOnClickListener { action() }
        })
    }

    private fun askNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
    }

    private fun toast(value: String) {
        Toast.makeText(this, value, Toast.LENGTH_LONG).show()
    }
}
