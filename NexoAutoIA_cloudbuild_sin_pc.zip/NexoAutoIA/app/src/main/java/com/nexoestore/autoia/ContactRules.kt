package com.nexoestore.autoia

import android.content.Context

object ContactRules {

    fun shouldReply(context: Context, chatTitle: String, messageText: String, settings: SettingsStore): Boolean {
        if (chatTitle.isBlank() || messageText.isBlank()) return false

        val isPossibleGroup = chatTitle.contains(":") || messageText.startsWith("~")
        if (isPossibleGroup && !settings.areGroupsEnabled()) return false

        return when (settings.getContactMode()) {
            "ALL" -> true
            "UNKNOWN_ONLY" -> !isPossibleGroup
            else -> !isPossibleGroup
        }
    }

    fun supportsPackage(packageName: String, settings: SettingsStore): Boolean {
        return when (settings.getSupportedAppsMode()) {
            "WHATSAPP" -> packageName == "com.whatsapp"
            "BUSINESS" -> packageName == "com.whatsapp.w4b"
            else -> packageName == "com.whatsapp" || packageName == "com.whatsapp.w4b"
        }
    }
}
