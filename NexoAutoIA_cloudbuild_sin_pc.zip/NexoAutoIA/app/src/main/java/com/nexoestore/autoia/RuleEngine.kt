package com.nexoestore.autoia

data class RuleDecision(
    val shouldReply: Boolean,
    val useGemini: Boolean,
    val reply: String,
    val reason: String
)

object RuleEngine {
    fun decide(
        customerName: String,
        customerMessage: String,
        settings: SettingsStore
    ): RuleDecision {
        val msg = customerMessage.trim()
        val lower = msg.lowercase()
        val now = System.currentTimeMillis()

        if (msg.isBlank()) {
            return RuleDecision(false, false, "", "Mensaje vacío")
        }

        if (looksLikeOwnBotReply(lower, settings)) {
            return RuleDecision(false, false, "", "Ignorado: parece una respuesta enviada por el bot")
        }

        var customer = settings.getCustomer(customerName)
        val hot = containsAny(lower, listOf("comprar", "quiero", "pagar", "envíame", "enviame", "me interesa", "listo", "deseo", "activo", "activar"))

        if (customer.humanPauseUntil > now) {
            return RuleDecision(false, false, "", "Modo humano activo para este cliente hasta que termine la pausa")
        }

        if (containsAny(lower, listOf("asesor", "humano", "reclamo", "garantía", "garantia", "devolución", "devolucion"))) {
            settings.updateCustomer(
                customerName,
                state = "HUMANO",
                hot = true,
                humanPauseUntil = now + 30 * 60_000L,
                lastMessage = msg,
                lastReply = "Un asesor continuará tu atención en breve 😊"
            )
            return RuleDecision(true, false, "Un asesor continuará tu atención en breve 😊", "Modo humano 30 minutos")
        }

        if (lower.contains("netflix")) {
            val reply = "Por el momento no manejamos renovación de Netflix. Tenemos Amazon Prime, Max Platino y Disney Premium disponibles 😊"
            settings.updateCustomer(customerName, state = "INTERESADO", hot = hot, lastMessage = msg, lastReply = reply)
            return RuleDecision(true, false, reply, "Regla crítica: no renovar Netflix")
        }

        if (containsAny(lower, listOf("comprobante", "capture", "captura", "ya pagué", "ya pague", "pagué", "pague", "transferencia enviada"))) {
            val reply = "Perfecto ✅ Tu comprobante será validado por un asesor. En breve te confirmamos."
            settings.updateCustomer(customerName, state = "COMPROBANTE_RECIBIDO", hot = true, lastMessage = msg, lastReply = reply)
            return RuleDecision(true, false, reply, "Comprobante recibido")
        }

        val detectedService = detectService(lower)
        if (detectedService.isNotBlank()) {
            val price = servicePrice(detectedService)
            val reply = "Claro 😊 $detectedService está disponible por $price. ¿Lo deseas por 1 mes?"
            settings.updateCustomer(customerName, service = detectedService, state = "INTERESADO", hot = true, lastMessage = msg, lastReply = reply)
            return RuleDecision(true, false, reply, "Producto detectado y guardado en CRM")
        }

        val detectedDuration = detectDuration(lower)
        if (detectedDuration.isNotBlank() && customer.service.isNotBlank()) {
            val price = servicePrice(customer.service)
            val reply = "Perfecto 😊 ${customer.service} por $detectedDuration cuesta $price. ¿Deseas pagar por Nequi o Binance?"
            settings.updateCustomer(customerName, duration = detectedDuration, state = "PAGO_PENDIENTE", hot = true, lastMessage = msg, lastReply = reply)
            return RuleDecision(true, false, reply, "Duración detectada y cliente pasó a pago pendiente")
        }

        val detectedPayment = detectPayment(lower)
        if (detectedPayment.isNotBlank()) {
            val reply = when (detectedPayment) {
                "Nequi" -> "Puedes pagar por Nequi al 3052154226. Luego envíanos el comprobante para validar tu pedido ✅"
                "Binance" -> "Puedes pagar por Binance al ID 376619565. Luego envíanos el comprobante para validar tu pedido ✅"
                else -> "Puedes pagar por Nequi al 3052154226 o por Binance al 376619565. Luego envíanos el comprobante ✅"
            }
            settings.updateCustomer(customerName, payment = detectedPayment, state = "ESPERANDO_COMPROBANTE", hot = true, lastMessage = msg, lastReply = reply)
            return RuleDecision(true, false, reply, "Método de pago detectado")
        }

        if (settings.isMenuEnabled() && containsAny(lower, listOf("menú", "menu", "opciones", "catálogo", "catalogo", "servicios", "disponible", "disponibles"))) {
            val reply = settings.getMenuMessage()
            settings.updateCustomer(customerName, state = "INTERESADO", hot = hot, lastMessage = msg, lastReply = reply)
            return RuleDecision(true, false, reply, "Menú automático")
        }

        if (settings.isWelcomeEnabled() && isGreeting(lower)) {
            val reply = settings.getWelcomeMessage()
            settings.updateCustomer(customerName, state = "NUEVO", hot = hot, lastMessage = msg, lastReply = reply)
            return RuleDecision(true, false, reply, "Bienvenida local")
        }

        if (settings.areKeywordRulesEnabled()) {
            parseKeywordRules(settings.getKeywordRules()).firstOrNull { (keyword, _) ->
                lower.contains(keyword.lowercase())
            }?.let { (_, reply) ->
                settings.updateCustomer(customerName, state = if (hot) "INTERESADO" else customer.state, hot = hot || customer.hot, lastMessage = msg, lastReply = reply)
                return RuleDecision(true, false, reply, "Palabra clave personalizada")
            }
        }

        if (hot) {
            settings.updateCustomer(customerName, state = "INTERESADO", hot = true, lastMessage = msg)
        } else {
            settings.updateCustomer(customerName, lastMessage = msg)
        }

        return RuleDecision(true, true, "", "Sin regla local: se consulta Gemini con contexto CRM")
    }

    fun contextForGemini(customerName: String, settings: SettingsStore): String {
        val c = settings.getCustomer(customerName)
        return """
            Contexto CRM del cliente:
            - Nombre/chat: ${c.name}
            - Servicio seleccionado: ${c.service.ifBlank { "no definido" }}
            - Duración: ${c.duration.ifBlank { "no definida" }}
            - Método de pago: ${c.payment.ifBlank { "no definido" }}
            - Estado de venta: ${c.state}
            - Cliente caliente: ${if (c.hot) "sí" else "no"}
            - Último mensaje: ${c.lastMessage}
            - Última respuesta enviada: ${c.lastReply}

            Flujo obligatorio:
            SALUDO → PRODUCTO → DURACIÓN → PAGO → COMPROBANTE → ASESOR.
            No reinicies el flujo si el cliente ya eligió producto o pago.
        """.trimIndent()
    }

    private fun detectService(lower: String): String {
        return when {
            lower.contains("disney") -> "Disney Premium"
            lower.contains("prime") || lower.contains("amazon") -> "Amazon Prime"
            lower.contains("max") || lower.contains("hbo") -> "Max Platino"
            else -> ""
        }
    }

    private fun servicePrice(service: String): String {
        return when {
            service.contains("Disney", ignoreCase = true) -> "8.5 USD"
            service.contains("Prime", ignoreCase = true) -> "2 USD"
            service.contains("Max", ignoreCase = true) -> "4.5 USD"
            else -> "precio por confirmar"
        }
    }

    private fun detectDuration(lower: String): String {
        return when {
            lower.contains("1 mes") || lower == "mes" || lower.contains("un mes") -> "1 mes"
            lower.contains("30 dias") || lower.contains("30 días") -> "1 mes"
            else -> ""
        }
    }

    private fun detectPayment(lower: String): String {
        return when {
            lower.contains("nequi") -> "Nequi"
            lower.contains("binance") -> "Binance"
            lower.contains("pago") || lower.contains("pagar") || lower.contains("dónde pago") || lower.contains("donde pago") -> "Ambos"
            else -> ""
        }
    }

    private fun looksLikeOwnBotReply(lower: String, settings: SettingsStore): Boolean {
        val candidates = listOf(
            settings.getFallbackMessage(),
            settings.getWelcomeMessage(),
            "puedes pagar por nequi",
            "puedes pagar por binance",
            "tu comprobante será validado",
            "un asesor continuará"
        ).map { it.lowercase().take(45) }

        return candidates.any { it.isNotBlank() && lower.startsWith(it.take(25)) }
    }

    private fun isGreeting(lower: String): Boolean {
        val clean = lower.replace("!", "").replace(".", "").trim()
        return clean in listOf("hola", "buenas", "buenos dias", "buenos días", "buenas tardes", "buenas noches", "hey")
    }

    private fun parseKeywordRules(value: String): List<Pair<String, String>> {
        return value.lines()
            .map { it.trim() }
            .filter { it.isNotBlank() && !it.startsWith("#") && it.contains("=") }
            .map {
                val parts = it.split("=", limit = 2)
                parts[0].trim() to parts[1].trim()
            }
            .filter { it.first.isNotBlank() && it.second.isNotBlank() }
    }

    private fun containsAny(value: String, words: List<String>): Boolean =
        words.any { value.contains(it, ignoreCase = true) }
}
