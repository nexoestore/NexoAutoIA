package com.nexoestore.autoia

object SalesAssistantEngine {

    private data class Product(val canonical: String, val price: String)

    private val products = listOf(
        Product("Amazon Prime", "2 USD"),
        Product("Max Platino", "4.5 USD"),
        Product("Disney Premium", "8.5 USD")
    )

    fun decide(
        customerName: String,
        customerMessage: String,
        settings: SettingsStore,
        stateStore: SalesStateStore = SalesStateStore(settings.context)
    ): RuleDecision {
        val msg = customerMessage.trim()
        val lower = normalize(msg)
        val state = stateStore.get(customerName)

        if (msg.isBlank()) return RuleDecision(false, false, "", "Mensaje vacío")

        if (stateStore.isHumanModeActive(customerName)) {
            return RuleDecision(false, false, "", "Modo humano activo para este cliente")
        }

        val product = detectProduct(lower)
        val duration = detectDuration(lower)
        val payment = detectPayment(lower)
        val isHot = containsAny(lower, listOf("comprar", "quiero", "pagar", "envíame", "enviame", "me interesa", "listo", "lo quiero", "dale"))

        if (containsAny(lower, listOf("asesor", "humano", "ayuda", "reclamo", "garantia", "garantía", "devolucion", "devolución", "soporte"))) {
            val reply = "Claro 😊 Te derivaremos con un asesor para ayudarte mejor."
            stateStore.update(
                chatTitle = customerName,
                incoming = msg,
                outgoing = reply,
                status = "asesor_humano",
                hot = isHot || state.hot,
                humanUntil = System.currentTimeMillis() + 30 * 60 * 1000L
            )
            return RuleDecision(true, false, reply, "Modo humano automático por 30 minutos")
        }

        if (containsAny(lower, listOf("comprobante", "capture", "captura", "pagué", "pague", "pagado", "transferencia", "recibo"))) {
            val reply = "Perfecto ✅ Tu comprobante será validado por un asesor. En breve te confirmamos."
            stateStore.update(customerName, msg, reply, status = "comprobante_recibido", hot = true)
            return RuleDecision(true, false, reply, "Comprobante recibido")
        }

        if (lower.contains("netflix")) {
            val reply = "Por el momento no manejamos renovación de Netflix. Tenemos Amazon Prime, Max Platino y Disney Premium disponibles 😊"
            stateStore.update(customerName, msg, reply, service = "", status = "netflix_no_disponible", hot = isHot || state.hot)
            return RuleDecision(true, false, reply, "Regla crítica: Nexo no renueva Netflix")
        }

        if (payment != null) {
            val service = state.service
            val durationText = state.duration
            val reply = when (payment) {
                "Nequi" -> "Puedes pagar por Nequi al 3052154226. Luego envíanos el comprobante para validarlo ✅"
                "Binance" -> "Puedes pagar por Binance al ID 376619565. Luego envíanos el comprobante para validarlo ✅"
                else -> "Puedes pagar por Nequi al 3052154226 o por Binance al ID 376619565. Luego envíanos el comprobante ✅"
            }
            stateStore.update(
                chatTitle = customerName,
                incoming = msg,
                outgoing = reply,
                service = service,
                duration = durationText,
                status = "esperando_comprobante",
                paymentMethod = payment,
                hot = true
            )
            return RuleDecision(true, false, reply, "Método de pago elegido")
        }

        if (product != null && duration != null) {
            val reply = "Perfecto 😊 ${product.canonical} por $duration cuesta ${product.price}. ¿Deseas pagar por Nequi o Binance?"
            stateStore.update(customerName, msg, reply, service = product.canonical, duration = duration, status = "esperando_pago", hot = true)
            return RuleDecision(true, false, reply, "Producto + duración detectados")
        }

        if (product != null) {
            val reply = "Claro 😊 ${product.canonical} cuesta ${product.price}. ¿Lo deseas por 1 mes?"
            stateStore.update(customerName, msg, reply, service = product.canonical, status = "esperando_duracion", hot = isHot || state.hot)
            return RuleDecision(true, false, reply, "Producto detectado")
        }

        if (duration != null && state.service.isNotBlank()) {
            val productState = products.firstOrNull { it.canonical.equals(state.service, ignoreCase = true) }
            if (productState != null) {
                val reply = "Perfecto 😊 ${productState.canonical} por $duration cuesta ${productState.price}. ¿Deseas pagar por Nequi o Binance?"
                stateStore.update(customerName, msg, reply, duration = duration, status = "esperando_pago", hot = true)
                return RuleDecision(true, false, reply, "Duración detectada usando memoria del cliente")
            }
        }

        if (containsAny(lower, listOf("precio", "precios", "cuanto", "cuánto", "vale", "cuesta", "costos"))) {
            val reply = if (state.service.isNotBlank()) {
                val p = products.firstOrNull { it.canonical.equals(state.service, ignoreCase = true) }
                if (p != null) "${p.canonical} cuesta ${p.price}. ¿Lo deseas por 1 mes?" else priceList()
            } else {
                priceList()
            }
            stateStore.update(customerName, msg, reply, status = "cotizando", hot = isHot || state.hot)
            return RuleDecision(true, false, reply, "Consulta de precios")
        }

        if (settings.isMenuEnabled() && containsAny(lower, listOf("menu", "menú", "opciones", "catalogo", "catálogo", "servicios", "disponible", "disponibles"))) {
            val reply = "Tenemos Amazon Prime 2 USD, Max Platino 4.5 USD y Disney Premium 8.5 USD 😊 ¿Cuál te interesa?"
            stateStore.update(customerName, msg, reply, status = "menu_enviado", hot = isHot || state.hot)
            return RuleDecision(true, false, reply, "Menú comercial")
        }

        if (settings.isWelcomeEnabled() && isGreeting(lower)) {
            val reply = if (state.service.isNotBlank() && state.status == "esperando_pago") {
                "Seguimos con ${state.service} ${state.duration}. ¿Deseas pagar por Nequi o Binance?"
            } else {
                settings.getWelcomeMessage()
            }
            stateStore.update(customerName, msg, reply, status = if (state.status == "nuevo") "saludado" else state.status, hot = state.hot)
            return RuleDecision(true, false, reply, "Bienvenida contextual")
        }

        if (settings.areKeywordRulesEnabled()) {
            val keywordReply = matchKeywordRule(lower, settings.getKeywordRules())
            if (keywordReply != null) {
                stateStore.update(customerName, msg, keywordReply, hot = isHot || state.hot)
                return RuleDecision(true, false, keywordReply, "Palabra clave personalizada")
            }
        }

        if (stateStore.shouldSuppressDuplicate(customerName, msg, state.lastOutgoing)) {
            return RuleDecision(false, false, "", "Anti-spam: mensaje o respuesta repetida recientemente")
        }

        stateStore.update(customerName, msg, "", hot = isHot || state.hot)
        return RuleDecision(true, true, "", buildContextReason(state))
    }

    fun buildMemoryContext(customerName: String, settings: SettingsStore): String {
        val state = SalesStateStore(settings.context).get(customerName)
        return """
            Memoria del cliente actual:
            - Servicio elegido: ${state.service.ifBlank { "aún no definido" }}
            - Duración elegida: ${state.duration.ifBlank { "aún no definida" }}
            - Estado del embudo: ${state.status}
            - Método de pago: ${state.paymentMethod.ifBlank { "aún no definido" }}
            - Cliente caliente: ${if (state.hot) "sí" else "no"}
            - Último mensaje del cliente: ${state.lastIncoming.ifBlank { "sin historial" }}
            - Última respuesta enviada: ${state.lastOutgoing.ifBlank { "sin historial" }}

            Usa esta memoria. No vuelvas a preguntar datos ya conocidos.
        """.trimIndent()
    }

    fun rememberGeminiReply(customerName: String, incoming: String, outgoing: String, settings: SettingsStore) {
        val store = SalesStateStore(settings.context)
        val current = store.get(customerName)
        store.update(
            chatTitle = customerName,
            incoming = incoming,
            outgoing = outgoing,
            service = current.service,
            duration = current.duration,
            status = current.status.ifBlank { "respondido_con_gemini" },
            hot = current.hot
        )
    }

    private fun priceList(): String {
        return "Tenemos Amazon Prime 2 USD, Max Platino 4.5 USD y Disney Premium 8.5 USD 😊 ¿Cuál te interesa?"
    }

    private fun detectProduct(text: String): Product? {
        return when {
            containsAny(text, listOf("disney", "disney+", "disney plus")) -> Product("Disney Premium", "8.5 USD")
            containsAny(text, listOf("amazon", "prime", "prime video")) -> Product("Amazon Prime", "2 USD")
            containsAny(text, listOf("max", "hbo", "hbo max", "max platino")) -> Product("Max Platino", "4.5 USD")
            else -> null
        }
    }

    private fun detectDuration(text: String): String? {
        return when {
            containsAny(text, listOf("1 mes", "un mes", "mensual", "30 dias", "30 días")) -> "1 mes"
            containsAny(text, listOf("2 meses", "dos meses")) -> "2 meses"
            containsAny(text, listOf("3 meses", "tres meses")) -> "3 meses"
            else -> null
        }
    }

    private fun detectPayment(text: String): String? {
        return when {
            text.contains("nequi") -> "Nequi"
            text.contains("binance") -> "Binance"
            containsAny(text, listOf("pagar", "pago", "donde pago", "dónde pago", "metodo", "método")) -> "Ambos"
            else -> null
        }
    }

    private fun buildContextReason(state: CustomerState): String {
        return "Sin regla local. Usar Gemini con memoria: servicio=${state.service}, duración=${state.duration}, estado=${state.status}"
    }

    private fun matchKeywordRule(lower: String, rules: String): String? {
        rules.lines().forEach { raw ->
            val line = raw.trim()
            if (line.isBlank() || line.startsWith("#") || !line.contains("=")) return@forEach
            val key = line.substringBefore("=").trim().lowercase()
            val value = line.substringAfter("=").trim()
            if (key.isNotBlank() && value.isNotBlank() && lower.contains(key)) return value
        }
        return null
    }

    private fun isGreeting(text: String): Boolean {
        val cleaned = text.trim().lowercase()
        return cleaned in listOf("hola", "buenas", "buenos dias", "buenos días", "buenas tardes", "buenas noches", "hey", "ola")
    }

    private fun containsAny(text: String, words: List<String>): Boolean {
        return words.any { text.contains(it.lowercase()) }
    }

    private fun normalize(value: String): String {
        return value.lowercase().replace(Regex("\\s+"), " ").trim()
    }
}
