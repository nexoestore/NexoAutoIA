package com.nexoestore.autoia

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : Activity() {

    private lateinit var settings: SettingsStore
    private lateinit var content: LinearLayout

    private val bg = 0xFF0B1822.toInt()
    private val card = 0xFF132838.toInt()
    private val accent = 0xFF009688.toInt()
    private val textColor = 0xFFFFFFFF.toInt()
    private val muted = 0xFFB7C0C7.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = SettingsStore(this)
        askNotificationPermissionIfNeeded()
        showMain()
    }

    private fun showMain() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

        root.addView(TextView(this).apply {
            setTextColor(textColor)
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            text = "Nexo Auto IA"
            setPadding(28, 35, 28, 18)
        })

        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 0, 8, 8)
        }

        tabs.addView(tabButton("MENÚ") { showMenu() })
        tabs.addView(tabButton("INICIO") { showInicio() })
        tabs.addView(tabButton("IA") { showRespuestaIA() })
        tabs.addView(tabButton("CONTACTOS") { showContactos() })
        tabs.addView(tabButton("CONFIG") { showConfiguracion() })
        root.addView(tabs)

        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 12, 20, 24)
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
        showInicio()
    }

    private fun tabButton(label: String, action: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(textColor)
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(4, 15, 4, 15)
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
    }

    private fun showInicio() {
        content.removeAllViews()

        content.addView(cardView("Respuesta automática", if (settings.isBotEnabled()) "ACTIVADA" else "DESACTIVADA") {
            val sw = Switch(this@MainActivity)
            sw.isChecked = settings.isBotEnabled()
            sw.setOnCheckedChangeListener { _, checked ->
                settings.setBotEnabled(checked)
                toast(if (checked) "Bot activado" else "Bot desactivado")
                showInicio()
            }
            addView(sw)
        })

        content.addView(cardView("Configurar OpenAI", if (settings.getOpenAiApiKey().isBlank()) "Falta API Key. Toca aquí para configurarla." else "API Key configurada. Toca aquí para editarla.") {
            setOnClickListener { showRespuestaIA() }
            button("Abrir configuración IA") { showRespuestaIA() }
        })

        content.addView(cardView("Permiso de notificaciones", "Necesario para leer mensajes de WhatsApp y responder desde la notificación.") {
            button("Abrir permiso de notificaciones") {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        })

        content.addView(cardView("Estado del sistema", buildString {
            append("WhatsApp soportado: WhatsApp y WhatsApp Business\n")
            append("Bot: ${if (settings.isBotEnabled()) "Activo" else "Pausado"}\n")
            append("OpenAI: ${if (settings.getOpenAiApiKey().isBlank()) "Falta API Key" else "Configurado"}\n")
            append("Modo contactos: ${if (settings.getContactMode() == "ALL") "Todos los chats" else "Clientes nuevos / no guardados"}")
        }) {})

        content.addView(cardView("Respuesta de prueba", "Prueba la IA o el mensaje de respaldo sin esperar un WhatsApp.") {
            button("Probar ahora") { showTestReply() }
        })
    }

    private fun showMenu() {
        content.removeAllViews()

        menuCard("Apps soportadas", "WhatsApp normal y WhatsApp Business.") {
            toast("Soporta com.whatsapp y com.whatsapp.w4b")
        }
        menuCard("Respuesta de IA", "Configura ChatGPT, API Key, modelo y prompt.") {
            showRespuestaIA()
        }
        menuCard("Respuesta por palabra clave", "Próxima versión: Netflix, Nequi, soporte.") {
            showProximamente("Respuesta por palabra clave")
        }
        menuCard("Respuesta del menú", "Próxima versión: menú 1, 2, 3, 4.") {
            showProximamente("Respuesta del menú")
        }
        menuCard("Mensaje de bienvenida", "Usa el mensaje de respaldo como bienvenida inicial.") {
            showConfiguracion()
        }
        menuCard("Respuesta de prueba", "Simula una respuesta antes de usarla.") {
            showTestReply()
        }
        menuCard("Historial", "Ver últimos mensajes detectados y respondidos.") {
            showHistorial()
        }
        menuCard("Configuración", "Tiempo, seguridad y mensaje de respaldo.") {
            showConfiguracion()
        }
    }

    private fun menuCard(title: String, desc: String, action: () -> Unit) {
        content.addView(cardView(title, desc) {
            setOnClickListener { action() }
            button("Abrir") { action() }
        })
    }

    private fun showProximamente(feature: String) {
        content.removeAllViews()
        content.addView(label(feature))
        content.addView(cardView("Próxima versión", "Esta función todavía no está conectada. La app actual ya puede responder usando IA/OpenAI o el mensaje de respaldo.") {
            button("Volver al menú") { showMenu() }
        })
    }

    private fun showContactos() {
        content.removeAllViews()

        content.addView(label("Responder automáticamente a"))

        val all = RadioButton(this).apply {
            text = "Todos los chats"
            setTextColor(textColor)
            isChecked = settings.getContactMode() == "ALL"
            setOnClickListener {
                settings.setContactMode("ALL")
                showContactos()
            }
        }

        val unknown = RadioButton(this).apply {
            text = "Números no guardados / clientes nuevos"
            setTextColor(textColor)
            isChecked = settings.getContactMode() == "UNKNOWN_ONLY"
            setOnClickListener {
                settings.setContactMode("UNKNOWN_ONLY")
                showContactos()
            }
        }

        val groups = CheckBox(this).apply {
            text = "Habilitar grupos"
            setTextColor(textColor)
            isChecked = settings.areGroupsEnabled()
            setOnCheckedChangeListener { _, checked ->
                settings.setGroupsEnabled(checked)
                toast(if (checked) "Grupos habilitados" else "Grupos desactivados")
            }
        }

        content.addView(all)
        content.addView(unknown)
        content.addView(groups)

        content.addView(cardView("Recomendación para Nexo", "Usa clientes nuevos y grupos desactivados para evitar respuestas a contactos personales.") {})
    }

    private fun showConfiguracion() {
        content.removeAllViews()

        content.addView(cardView("Tiempo de respuesta", "${settings.getResponseDelaySeconds()} segundos") {
            val input = EditText(this@MainActivity).apply {
                setText(settings.getResponseDelaySeconds().toString())
                setTextColor(textColor)
                setHintTextColor(muted)
                inputType = InputType.TYPE_CLASS_NUMBER
                hint = "3"
            }
            addView(input)
            button("Guardar tiempo") {
                settings.setResponseDelaySeconds(input.text.toString().toIntOrNull() ?: 3)
                toast("Tiempo guardado")
                showConfiguracion()
            }
        })

        content.addView(cardView("Mensaje de respaldo / bienvenida", settings.getFallbackMessage()) {
            val input = EditText(this@MainActivity).apply {
                setText(settings.getFallbackMessage())
                setTextColor(textColor)
                setHintTextColor(muted)
                minLines = 3
                gravity = Gravity.TOP
            }
            addView(input)
            button("Guardar mensaje") {
                settings.setFallbackMessage(input.text.toString())
                toast("Mensaje guardado")
                showConfiguracion()
            }
        })

        content.addView(cardView("Seguridad", "La API Key se guarda localmente en este teléfono. No compartas capturas ni backups con tu clave visible.") {
            button("Configurar API Key") { showRespuestaIA() }
        })
    }

    private fun showRespuestaIA() {
        content.removeAllViews()
        content.addView(label("Respuesta de IA / ChatGPT"))

        content.addView(cardView("Estado de OpenAI", if (settings.getOpenAiApiKey().isBlank()) "Falta configurar API Key" else "API Key guardada correctamente") {})

        content.addView(cardView("Clave API de OpenAI", "Pega tu API Key. Se guarda solo en este teléfono.") {
            val keyInput = EditText(this@MainActivity).apply {
                setText(settings.getOpenAiApiKey())
                setTextColor(textColor)
                setHintTextColor(muted)
                hint = "sk-..."
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                minLines = 1
            }
            addView(keyInput)

            val modelInput = EditText(this@MainActivity).apply {
                setText(settings.getAiModel())
                setTextColor(textColor)
                setHintTextColor(muted)
                hint = "gpt-4o-mini"
            }
            addView(modelInput)

            val maxChars = EditText(this@MainActivity).apply {
                setText(settings.getMaxWhatsappChars().toString())
                setTextColor(textColor)
                setHintTextColor(muted)
                hint = "500"
                inputType = InputType.TYPE_CLASS_NUMBER
            }
            addView(TextView(this@MainActivity).apply {
                text = "Máximo de caracteres para WhatsApp"
                setTextColor(muted)
                textSize = 14f
                setPadding(0, 14, 0, 0)
            })
            addView(maxChars)

            button("Guardar OpenAI") {
                settings.setOpenAiApiKey(keyInput.text.toString())
                settings.setAiModel(modelInput.text.toString().ifBlank { "gpt-4o-mini" })
                settings.setMaxWhatsappChars(maxChars.text.toString().toIntOrNull() ?: 500)
                toast("Configuración IA guardada")
                showRespuestaIA()
            }

            button("Probar IA") { showTestReply() }
        })

        content.addView(cardView("Entrenar IA", "Personaliza las respuestas de Nexo E Store.") {
            val prompt = EditText(this@MainActivity).apply {
                setText(settings.getBusinessPrompt())
                setTextColor(textColor)
                setHintTextColor(muted)
                minLines = 10
                gravity = Gravity.TOP
            }
            addView(prompt)
            button("Guardar entrenamiento") {
                settings.setBusinessPrompt(prompt.text.toString())
                toast("Prompt guardado")
            }
        })
    }

    private fun showTestReply() {
        content.removeAllViews()
        content.addView(label("Respuesta de prueba"))

        val input = EditText(this).apply {
            hint = "Ejemplo: Hola, tienes Netflix?"
            setHintTextColor(muted)
            setTextColor(textColor)
            minLines = 3
            gravity = Gravity.TOP
        }
        content.addView(input)

        val result = TextView(this).apply {
            setTextColor(textColor)
            textSize = 16f
            setPadding(0, 18, 0, 18)
        }
        content.addView(result)

        button("Generar respuesta") {
            result.text = "Generando..."
            CoroutineScope(Dispatchers.IO).launch {
                val reply = AutoReplyEngine.generateReply(
                    customerName = "Cliente de prueba",
                    customerMessage = input.text.toString(),
                    settings = settings
                )
                withContext(Dispatchers.Main) {
                    result.text = reply
                }
            }
        }.also { content.addView(it) }

        button("Volver a IA") { showRespuestaIA() }.also { content.addView(it) }
    }

    private fun showHistorial() {
        content.removeAllViews()
        content.addView(label("Historial básico"))
        val logs = MessageHistoryStore(this).getLogs().ifBlank { "Aún no hay mensajes respondidos." }
        content.addView(cardView("Mensajes", logs) {
            button("Limpiar historial") {
                MessageHistoryStore(this@MainActivity).clear()
                showHistorial()
            }
        })
    }

    private fun cardView(title: String, desc: String, extra: LinearLayout.() -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(card)
            setPadding(26, 22, 26, 22)
            val params = LinearLayout.LayoutParams(-1, -2)
            params.setMargins(0, 0, 0, 18)
            layoutParams = params

            addView(TextView(this@MainActivity).apply {
                text = title
                setTextColor(textColor)
                textSize = 20f
                typeface = Typeface.DEFAULT_BOLD
            })

            addView(TextView(this@MainActivity).apply {
                text = desc
                setTextColor(muted)
                textSize = 16f
                setPadding(0, 8, 0, 8)
            })

            extra()
        }
    }

    private fun label(value: String): TextView {
        return TextView(this).apply {
            text = value
            setTextColor(accent)
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 10, 0, 18)
        }
    }

    private fun button(value: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = value
            setTextColor(textColor)
            setBackgroundColor(accent)
            setOnClickListener { action() }
            val params = LinearLayout.LayoutParams(-1, -2)
            params.setMargins(0, 12, 0, 0)
            layoutParams = params
        }
    }

    private fun askNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
    }

    private fun toast(value: String) {
        Toast.makeText(this, value, Toast.LENGTH_SHORT).show()
    }
}
