package com.nexoestore.autoia

import android.content.Context
import android.content.SharedPreferences

class SettingsStore(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("nexo_auto_ia_settings", Context.MODE_PRIVATE)

    fun isBotEnabled(): Boolean = prefs.getBoolean("botEnabled", false)
    fun setBotEnabled(value: Boolean) = prefs.edit().putBoolean("botEnabled", value).apply()

    fun getResponseMode(): String = prefs.getString("responseMode", "AUTO") ?: "AUTO"
    fun setResponseMode(value: String) = prefs.edit().putString("responseMode", value).apply()

    fun getGeminiApiKey(): String = prefs.getString("geminiApiKey", "") ?: ""
    fun setGeminiApiKey(value: String) = prefs.edit().putString("geminiApiKey", value.trim()).apply()

    fun getGeminiModel(): String = prefs.getString("geminiModel", "gemini-2.0-flash") ?: "gemini-2.0-flash"
    fun setGeminiModel(value: String) = prefs.edit().putString("geminiModel", value.trim().ifBlank { "gemini-2.0-flash" }).apply()

    fun getBusinessPrompt(): String =
        prefs.getString("businessPrompt", DEFAULT_NEXO_PROMPT) ?: DEFAULT_NEXO_PROMPT
    fun setBusinessPrompt(value: String) =
        prefs.edit().putString("businessPrompt", value.trim()).apply()

    fun getFallbackMessage(): String =
        prefs.getString("fallbackMessage", DEFAULT_FALLBACK) ?: DEFAULT_FALLBACK
    fun setFallbackMessage(value: String) =
        prefs.edit().putString("fallbackMessage", value.trim().ifBlank { DEFAULT_FALLBACK }).apply()

    fun getWelcomeMessage(): String =
        prefs.getString("welcomeMessage", DEFAULT_WELCOME) ?: DEFAULT_WELCOME
    fun setWelcomeMessage(value: String) =
        prefs.edit().putString("welcomeMessage", value.trim().ifBlank { DEFAULT_WELCOME }).apply()

    fun getMenuMessage(): String =
        prefs.getString("menuMessage", DEFAULT_MENU) ?: DEFAULT_MENU
    fun setMenuMessage(value: String) =
        prefs.edit().putString("menuMessage", value.trim().ifBlank { DEFAULT_MENU }).apply()

    fun getKeywordRules(): String =
        prefs.getString("keywordRules", DEFAULT_KEYWORDS) ?: DEFAULT_KEYWORDS
    fun setKeywordRules(value: String) =
        prefs.edit().putString("keywordRules", value.trim().ifBlank { DEFAULT_KEYWORDS }).apply()

    fun getServerUrl(): String = prefs.getString("serverUrl", "") ?: ""
    fun setServerUrl(value: String) = prefs.edit().putString("serverUrl", value.trim()).apply()

    fun getNotes(): String = prefs.getString("notes", "") ?: ""
    fun setNotes(value: String) = prefs.edit().putString("notes", value).apply()

    fun getMaxWhatsappChars(): Int = prefs.getInt("maxWhatsappChars", 500)
    fun setMaxWhatsappChars(value: Int) = prefs.edit().putInt("maxWhatsappChars", value.coerceIn(80, 1500)).apply()

    fun getResponseDelaySeconds(): Int = prefs.getInt("responseDelaySeconds", 3)
    fun setResponseDelaySeconds(value: Int) = prefs.edit().putInt("responseDelaySeconds", value.coerceIn(0, 60)).apply()

    fun getContactMode(): String = prefs.getString("contactMode", "INDIVIDUAL_ONLY") ?: "INDIVIDUAL_ONLY"
    fun setContactMode(value: String) = prefs.edit().putString("contactMode", value).apply()

    fun areGroupsEnabled(): Boolean = prefs.getBoolean("groupsEnabled", false)
    fun setGroupsEnabled(value: Boolean) = prefs.edit().putBoolean("groupsEnabled", value).apply()

    fun getWhatsappMode(): String = prefs.getString("whatsappMode", "BOTH") ?: "BOTH"
    fun setWhatsappMode(value: String) = prefs.edit().putString("whatsappMode", value).apply()

    fun isPrivacyAccepted(): Boolean = prefs.getBoolean("privacyAccepted", false)
    fun setPrivacyAccepted(value: Boolean) = prefs.edit().putBoolean("privacyAccepted", value).apply()

    companion object {
        const val DEFAULT_FALLBACK =
            "¡Hola! 😊 Gracias por escribir a Nexo E Store. En breve te ayudamos."

        const val DEFAULT_WELCOME =
            "¡Hola! 😊 Bienvenido a Nexo E Store. ¿Qué servicio necesitas hoy: streaming, recargas o soporte?"

        val DEFAULT_MENU = """
            ¡Hola! 😊 Soy el asistente de Nexo E Store.
            Responde con una opción:
            1. Streaming
            2. Recargas
            3. Métodos de pago
            4. Soporte
            5. Hablar con asesor
        """.trimIndent()

        val DEFAULT_KEYWORDS = """
            netflix=¡Hola! 😊 Claro, te ayudo con Netflix. ¿Lo necesitas por 1 mes, renovación o cuenta nueva?
            disney=¡Hola! 😊 Claro, te ayudo con Disney+. ¿Lo necesitas por 1 mes o renovación?
            prime=¡Hola! 😊 Claro, te ayudo con Prime Video. ¿Qué duración necesitas?
            nequi=Perfecto ✅ Puedes pagar por Nequi. Envía el comprobante y un asesor validará tu pedido.
            soporte=Claro, para soporte envíame tu número de pedido, servicio comprado y el problema presentado.
            asesor=Claro 😊 Te comunico con un asesor de Nexo E Store para ayudarte.
        """.trimIndent()

        val DEFAULT_NEXO_PROMPT = """
            Eres el asistente virtual de Nexo E Store.

            Nexo E Store vende servicios de streaming, recargas digitales y productos relacionados.

            Reglas:
            - Responde en español latino.
            - Sé breve, amable y comercial.
            - No digas que eres Gemini ni ChatGPT.
            - No inventes precios.
            - No pidas contraseñas personales.
            - No solicites datos de tarjetas.
            - Si el cliente pregunta por precios, indica que confirmarás disponibilidad.
            - Si el cliente quiere comprar, pide servicio, duración y método de pago.
            - Si envía comprobante, responde que será validado por un asesor.
            - Si escribe asesor, humano, garantía o reclamo, deriva a atención humana.
            - Usa máximo 3 líneas.
        """.trimIndent()
    }
}
