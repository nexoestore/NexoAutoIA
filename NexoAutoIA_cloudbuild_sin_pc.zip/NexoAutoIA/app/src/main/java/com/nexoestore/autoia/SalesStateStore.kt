package com.nexoestore.autoia

import android.content.Context
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class CustomerState(
    val chatId: String,
    val displayName: String,
    val service: String,
    val duration: String,
    val status: String,
    val paymentMethod: String,
    val hot: Boolean,
    val lastIncoming: String,
    val lastOutgoing: String,
    val lastAt: Long,
    val humanUntil: Long
)

class SalesStateStore(context: Context) {
    private val prefs = context.getSharedPreferences("nexo_sales_state", Context.MODE_PRIVATE)

    fun get(chatTitle: String): CustomerState {
        val id = key(chatTitle)
        val raw = prefs.getString("customer_$id", null)
        if (raw.isNullOrBlank()) {
            return CustomerState(id, chatTitle, "", "", "nuevo", "", false, "", "", 0L, 0L)
        }

        return try {
            val json = JSONObject(raw)
            CustomerState(
                chatId = id,
                displayName = json.optString("displayName", chatTitle),
                service = json.optString("service"),
                duration = json.optString("duration"),
                status = json.optString("status", "nuevo"),
                paymentMethod = json.optString("paymentMethod"),
                hot = json.optBoolean("hot", false),
                lastIncoming = json.optString("lastIncoming"),
                lastOutgoing = json.optString("lastOutgoing"),
                lastAt = json.optLong("lastAt", 0L),
                humanUntil = json.optLong("humanUntil", 0L)
            )
        } catch (_: Exception) {
            CustomerState(id, chatTitle, "", "", "nuevo", "", false, "", "", 0L, 0L)
        }
    }

    fun save(chatTitle: String, state: CustomerState) {
        val id = key(chatTitle)
        val json = JSONObject()
            .put("displayName", state.displayName.ifBlank { chatTitle })
            .put("service", state.service)
            .put("duration", state.duration)
            .put("status", state.status)
            .put("paymentMethod", state.paymentMethod)
            .put("hot", state.hot)
            .put("lastIncoming", state.lastIncoming.take(500))
            .put("lastOutgoing", state.lastOutgoing.take(800))
            .put("lastAt", state.lastAt)
            .put("humanUntil", state.humanUntil)

        prefs.edit()
            .putString("customer_$id", json.toString())
            .putString("customers", addToList(prefs.getString("customers", "") ?: "", id))
            .apply()
    }

    fun update(
        chatTitle: String,
        incoming: String,
        outgoing: String,
        service: String? = null,
        duration: String? = null,
        status: String? = null,
        paymentMethod: String? = null,
        hot: Boolean? = null,
        humanUntil: Long? = null
    ): CustomerState {
        val old = get(chatTitle)
        val next = old.copy(
            displayName = old.displayName.ifBlank { chatTitle },
            service = service ?: old.service,
            duration = duration ?: old.duration,
            status = status ?: old.status,
            paymentMethod = paymentMethod ?: old.paymentMethod,
            hot = hot ?: old.hot,
            lastIncoming = incoming,
            lastOutgoing = outgoing,
            lastAt = System.currentTimeMillis(),
            humanUntil = humanUntil ?: old.humanUntil
        )
        save(chatTitle, next)
        return next
    }

    fun isHumanModeActive(chatTitle: String): Boolean {
        return get(chatTitle).humanUntil > System.currentTimeMillis()
    }

    fun shouldSuppressDuplicate(chatTitle: String, incoming: String, proposedReply: String): Boolean {
        val state = get(chatTitle)
        val now = System.currentTimeMillis()
        if (state.lastAt <= 0L) return false

        val sameIncoming = normalize(state.lastIncoming) == normalize(incoming)
        val sameOutgoing = normalize(state.lastOutgoing) == normalize(proposedReply)
        return now - state.lastAt < 90_000L && (sameIncoming || sameOutgoing)
    }

    fun summary(limit: Int = 40): String {
        val ids = customerIds().take(limit)
        if (ids.isEmpty()) return "Aún no hay clientes registrados."

        return ids.joinToString("\n\n") { id ->
            val state = getById(id)
            val date = if (state.lastAt > 0) {
                SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(state.lastAt))
            } else "-"
            val human = if (state.humanUntil > System.currentTimeMillis()) " · Modo humano" else ""
            "Cliente: ${state.displayName}\nInterés: ${state.service.ifBlank { "-" }} ${state.duration.ifBlank { "" }}\nEstado: ${state.status}${human}\nÚltimo: ${state.lastIncoming.take(80)}\nHora: $date"
        }
    }

    fun stats(): String {
        val states = customerIds().map { getById(it) }
        if (states.isEmpty()) return "Sin datos comerciales todavía."

        val hot = states.count { it.hot }
        val pendingPay = states.count { it.status == "esperando_pago" }
        val paid = states.count { it.status == "comprobante_recibido" }
        val human = states.count { it.humanUntil > System.currentTimeMillis() }
        val disney = states.count { it.service.contains("Disney", ignoreCase = true) }
        val prime = states.count { it.service.contains("Prime", ignoreCase = true) }
        val max = states.count { it.service.contains("Max", ignoreCase = true) }

        return """
            Clientes registrados: ${states.size}
            Clientes calientes: $hot
            Pagos pendientes: $pendingPay
            Comprobantes recibidos: $paid
            Derivados a asesor: $human

            Interés por producto:
            Disney Premium: $disney
            Amazon Prime: $prime
            Max Platino: $max
        """.trimIndent()
    }

    fun clearAll() {
        val edit = prefs.edit()
        customerIds().forEach { edit.remove("customer_$it") }
        edit.remove("customers").apply()
    }

    private fun getById(id: String): CustomerState {
        val raw = prefs.getString("customer_$id", null)
        if (raw.isNullOrBlank()) return CustomerState(id, id, "", "", "nuevo", "", false, "", "", 0L, 0L)
        return try {
            val json = JSONObject(raw)
            CustomerState(
                chatId = id,
                displayName = json.optString("displayName", id),
                service = json.optString("service"),
                duration = json.optString("duration"),
                status = json.optString("status", "nuevo"),
                paymentMethod = json.optString("paymentMethod"),
                hot = json.optBoolean("hot", false),
                lastIncoming = json.optString("lastIncoming"),
                lastOutgoing = json.optString("lastOutgoing"),
                lastAt = json.optLong("lastAt", 0L),
                humanUntil = json.optLong("humanUntil", 0L)
            )
        } catch (_: Exception) {
            CustomerState(id, id, "", "", "nuevo", "", false, "", "", 0L, 0L)
        }
    }

    private fun customerIds(): List<String> {
        return (prefs.getString("customers", "") ?: "")
            .split("|")
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()
    }

    private fun addToList(current: String, id: String): String {
        val items = (listOf(id) + current.split("|")).map { it.trim() }.filter { it.isNotBlank() }.distinct()
        return items.take(80).joinToString("|")
    }

    private fun key(value: String): String {
        return value.lowercase()
            .replace(Regex("[^a-z0-9]+"), "_")
            .trim('_')
            .ifBlank { "cliente" }
            .take(80)
    }

    private fun normalize(value: String): String {
        return value.lowercase().replace(Regex("\\s+"), " ").trim()
    }
}
