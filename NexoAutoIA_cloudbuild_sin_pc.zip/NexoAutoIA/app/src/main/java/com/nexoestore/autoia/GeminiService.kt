package com.nexoestore.autoia

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

object GeminiService {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json".toMediaType()

    fun isValidKey(apiKey: String): Boolean {
        val key = apiKey.trim()
        return key.startsWith("AIza") && key.length >= 25
    }

    fun createChatResponse(
        apiKey: String,
        model: String,
        systemPrompt: String,
        userMessage: String,
        maxOutputTokens: Int = 220
    ): String {
        if (!isValidKey(apiKey)) {
            throw IllegalArgumentException("API Key Gemini inválida. Debe empezar por AIza.")
        }

        val safeModel = model.trim().ifBlank { "gemini-2.0-flash" }
        val encodedModel = URLEncoder.encode(safeModel, "UTF-8")
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$encodedModel:generateContent?key=${apiKey.trim()}"

        val finalPrompt = """
            $systemPrompt

            Mensaje del cliente:
            $userMessage
        """.trimIndent()

        val parts = JSONArray().put(JSONObject().put("text", finalPrompt))
        val content = JSONObject().put("role", "user").put("parts", parts)

        val body = JSONObject()
            .put("contents", JSONArray().put(content))
            .put(
                "generationConfig",
                JSONObject()
                    .put("temperature", 0.4)
                    .put("maxOutputTokens", maxOutputTokens.coerceIn(80, 1000))
            )

        val request = Request.Builder()
            .url(url)
            .addHeader("Content-Type", "application/json")
            .post(body.toString().toRequestBody(jsonMediaType))
            .build()

        client.newCall(request).execute().use { response ->
            val responseBody = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val msg = try {
                    JSONObject(responseBody).optJSONObject("error")?.optString("message")
                } catch (_: Exception) { null }
                throw RuntimeException("Gemini ${response.code}: ${msg ?: responseBody.take(180)}")
            }

            val json = JSONObject(responseBody)
            val candidates = json.optJSONArray("candidates") ?: throw RuntimeException("Gemini no devolvió candidatos.")
            if (candidates.length() == 0) throw RuntimeException("Gemini devolvió respuesta vacía.")

            val candidate = candidates.getJSONObject(0)
            val candidateContent = candidate.optJSONObject("content") ?: throw RuntimeException("Respuesta sin contenido.")
            val candidateParts = candidateContent.optJSONArray("parts") ?: throw RuntimeException("Respuesta sin partes.")
            if (candidateParts.length() == 0) throw RuntimeException("Respuesta vacía.")

            return candidateParts.getJSONObject(0).optString("text", "").trim()
                .ifBlank { throw RuntimeException("Gemini respondió texto vacío.") }
        }
    }
}
