package com.nexoestore.autoia

import android.content.Context
import android.content.SharedPreferences

class SettingsStore(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("nexo_auto_ia_settings", Context.MODE_PRIVATE)

    fun isBotEnabled(): Boolean = prefs.getBoolean("botEnabled", false)
    fun setBotEnabled(value: Boolean) = prefs.edit().putBoolean("botEnabled", value).apply()

    fun getOpenAiApiKey(): String = prefs.getString("openAiApiKey", "") ?: ""
    fun setOpenAiApiKey(value: String) = prefs.edit().putString("openAiApiKey", value.trim()).apply()

    fun getAiModel(): String = prefs.getString("aiModel", "gpt-4o-mini") ?: "gpt-4o-mini"
    fun setAiModel(value: String) = prefs.edit().putString("aiModel", value.trim()).apply()

    fun getBusinessPrompt(): String =
        prefs.getString("businessPrompt", DEFAULT_NEXO_PROMPT) ?: DEFAULT_NEXO_PROMPT

    fun setBusinessPrompt(value: String) =
        prefs.edit().putString("businessPrompt", value.trim()).apply()

    fun getFallbackMessage(): String =
        prefs.getString("fallbackMessage", DEFAULT_FALLBACK) ?: DEFAULT_FALLBACK

    fun setFallbackMessage(value: String) =
        prefs.edit().putString("fallbackMessage", value.trim()).apply()

    fun getMaxWhatsappChars(): Int = prefs.getInt("maxWhatsappChars", 500)
    fun setMaxWhatsappChars(value: Int) = prefs.edit().putInt("maxWhatsappChars", value.coerceIn(80, 1500)).apply()

    fun getResponseDelaySeconds(): Int = prefs.getInt("responseDelaySeconds", 3)
    fun setResponseDelaySeconds(value: Int) = prefs.edit().putInt("responseDelaySeconds", value.coerceIn(0, 60)).apply()

    fun getContactMode(): String = prefs.getString("contactMode", "UNKNOWN_ONLY") ?: "UNKNOWN_ONLY"
    fun setContactMode(value: String) = prefs.edit().putString("contactMode", value).apply()

    fun areGroupsEnabled(): Boolean = prefs.getBoolean("groupsEnabled", false)
    fun setGroupsEnabled(value: Boolean) = prefs.edit().putBoolean("groupsEnabled", value).apply()

    fun getWhatsappMode(): String = prefs.getString("whatsappMode", "BOTH") ?: "BOTH"
    fun setWhatsappMode(value: String) = prefs.edit().putString("whatsappMode", value).apply()

    fun isPrivacyAccepted(): Boolean = prefs.getBoolean("privacyAccepted", false)
    fun setPrivacyAccepted(value: Boolean) = prefs.edit().putBoolean("privacyAccepted", value).apply()

    companion object {
        const val DEFAULT_FALLBACK =
            "¡Hola! 😊 Gracias por escribir a Nexo E Store. En breve te ayudamos."

        val DEFAULT_NEXO_PROMPT = """
            Eres el asistente virtual de Nexo E Store.

            Nexo E Store vende servicios de streaming, recargas digitales y productos relacionados.

            Reglas:
            - Responde en español latino.
            - Sé breve, amable y comercial.
            - No digas que eres ChatGPT.
            - No inventes precios.
            - No pidas contraseñas personales.
            - No solicites datos de tarjetas.
            - Si el cliente pregunta por precios, indica que confirmarás disponibilidad.
            - Si el cliente quiere comprar, pide servicio, duración y método de pago.
            - Si envía comprobante, responde que será validado por un asesor.
            - Si escribe asesor, humano, garantía o reclamo, deriva a atención humana.
            - Usa máximo 3 líneas.
        """.trimIndent()
    }
}
