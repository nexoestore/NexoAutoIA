package com.nexoestore.autoia

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class NexoNotificationListener : NotificationListenerService() {

    private val scope = CoroutineScope(Dispatchers.IO)
    private val processedMessages = LinkedHashSet<String>()

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val settings = SettingsStore(applicationContext)
        if (!ContactRules.supportsPackage(sbn.packageName, settings)) return

        val notification = sbn.notification ?: return
        val extras = notification.extras

        val chatTitle = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val messageText = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()

        if (chatTitle.isBlank() || messageText.isBlank()) return
        if (messageText.contains("mensajes nuevos", ignoreCase = true)) return
        if (messageText.contains("new messages", ignoreCase = true)) return

        val normalizedKey = "${sbn.packageName}-${chatTitle.lowercase()}-${messageText.lowercase()}".take(300)
        if (processedMessages.contains(normalizedKey)) return
        processedMessages.add(normalizedKey)

        if (processedMessages.size > 250) {
            val iterator = processedMessages.iterator()
            repeat(80) {
                if (iterator.hasNext()) {
                    iterator.next()
                    iterator.remove()
                }
            }
        }

        val replyAction = notification.actions?.firstOrNull { action ->
            action.remoteInputs?.isNotEmpty() == true
        } ?: run {
            settings.setLastDiagnostic("No se encontró acción de respuesta rápida en la notificación.")
            return
        }

        scope.launch {
            try {
                if (!settings.isBotEnabled()) return@launch
                if (!ContactRules.shouldReply(applicationContext, chatTitle, messageText, settings)) return@launch

                val delayMillis = settings.getResponseDelaySeconds().coerceIn(0, 60) * 1000L
                if (delayMillis > 0) delay(delayMillis)

                val result = AutoReplyEngine.generateReplyDetailed(
                    customerName = chatTitle,
                    customerMessage = messageText,
                    settings = settings
                )
                settings.setLastDiagnostic(result.diagnostic)

                if (!result.ok && result.text.isBlank()) return@launch

                sendReply(replyAction, result.text)
                MessageHistoryStore(applicationContext).addLog(chatTitle, messageText, result.text, result.diagnostic)
            } catch (e: Exception) {
                settings.setLastDiagnostic("Error general en notificación: ${e.javaClass.simpleName}: ${e.message}")
            }
        }
    }

    private fun sendReply(action: Notification.Action, message: String) {
        val remoteInput = action.remoteInputs?.firstOrNull() ?: return

        val intent = Intent()
        val bundle = Bundle()
        bundle.putCharSequence(remoteInput.resultKey, message)
        RemoteInput.addResultsToIntent(arrayOf(remoteInput), intent, bundle)

        try {
            action.actionIntent.send(this, 0, intent)
        } catch (e: PendingIntent.CanceledException) {
            SettingsStore(applicationContext).setLastDiagnostic("No se pudo enviar respuesta: ${e.message}")
        }
    }
}
