package com.nexoestore.autoia

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : Activity() {

    private lateinit var settings: SettingsStore
    private lateinit var content: LinearLayout

    private val bg = 0xFF0B1822.toInt()
    private val card = 0xFF132838.toInt()
    private val accent = 0xFF009688.toInt()
    private val textColor = 0xFFFFFFFF.toInt()
    private val muted = 0xFFB7C0C7.toInt()
    private val danger = 0xFFD32F2F.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = SettingsStore(this)
        askNotificationPermissionIfNeeded()
        showMain()
    }

    override fun onResume() {
        super.onResume()
        if (::content.isInitialized) showInicio()
    }

    private fun showMain() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

        root.addView(TextView(this).apply {
            setTextColor(textColor)
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            text = "Nexo Auto IA"
            setPadding(28, 35, 28, 12)
        })

        val tabsScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 0, 8, 8)
        }

        tabs.addView(tabButton("MENÚ") { showMenu() })
        tabs.addView(tabButton("INICIO") { showInicio() })
        tabs.addView(tabButton("IA") { showRespuestaIA() })
        tabs.addView(tabButton("PERMISOS") { showPermisos() })
        tabs.addView(tabButton("CONTACTOS") { showContactos() })
        tabs.addView(tabButton("CONFIG") { showConfiguracion() })
        tabsScroll.addView(tabs)
        root.addView(tabsScroll)

        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 12, 20, 28)
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
        showInicio()
    }

    private fun tabButton(label: String, action: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(textColor)
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(18, 15, 18, 15)
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(-2, -2)
        }
    }

    private fun showInicio() {
        content.removeAllViews()

        content.addView(cardView("Respuesta automática", if (settings.isBotEnabled()) "ACTIVADA" else "DESACTIVADA") {
            val sw = Switch(this@MainActivity)
            sw.isChecked = settings.isBotEnabled()
            sw.setOnCheckedChangeListener { _, checked ->
                settings.setBotEnabled(checked)
                toast(if (checked) "Bot activado" else "Bot desactivado")
                showInicio()
            }
            addView(sw)
        })

        val notificationStatus = if (isNotificationListenerEnabled()) "Activo" else "Falta activar"
        val openAiStatus = if (settings.getOpenAiApiKey().startsWith("sk-")) "Configurado" else "Falta API Key"
        val privacyStatus = if (settings.isPrivacyAccepted()) "Aceptada" else "Pendiente"

        content.addView(cardView("Estado del sistema", buildString {
            append("Permiso de notificaciones: $notificationStatus\n")
            append("OpenAI: $openAiStatus\n")
            append("Privacidad: $privacyStatus\n")
            append("Modo WhatsApp: ${settings.getWhatsappMode()}\n")
            append("Bot: ${if (settings.isBotEnabled()) "Activo" else "Pausado"}")
        }) {
            button("Abrir permisos") { showPermisos() }
            button("Configurar IA") { showRespuestaIA() }
        })

        content.addView(cardView("Prueba rápida", "Comprueba la respuesta antes de esperar un WhatsApp.") {
            button("Probar respuesta") { showTestReply() }
            button("Ver historial") { showHistorial() }
        })
    }

    private fun showMenu() {
        content.removeAllViews()

        menuCard("Apps soportadas", "WhatsApp normal y WhatsApp Business.") { showAppsSoportadas() }
        menuCard("Respuesta de IA", "Configura ChatGPT, API Key, modelo y prompt.") { showRespuestaIA() }
        menuCard("Permisos y Play Protect", "Estado de permisos, privacidad y recomendaciones.") { showPermisos() }
        menuCard("Respuesta por palabra clave", "Reglas simples: Netflix, Nequi, soporte. Próxima versión.") { showProximamente("Respuesta por palabra clave") }
        menuCard("Respuesta del menú", "Menú 1, 2, 3, 4. Próxima versión.") { showProximamente("Respuesta del menú") }
        menuCard("Mensaje de bienvenida", "Se usa el mensaje de respaldo cuando no hay API o falla internet.") { showConfiguracion() }
        menuCard("Respuesta de prueba", "Simula una respuesta antes de usarla.") { showTestReply() }
        menuCard("Historial", "Últimos mensajes detectados y respondidos.") { showHistorial() }
        menuCard("Configuración", "Tiempo de respuesta, respaldo y seguridad.") { showConfiguracion() }
    }

    private fun showAppsSoportadas() {
        content.removeAllViews()
        content.addView(label("Apps soportadas"))

        val both = RadioButton(this).apply {
            text = "WhatsApp normal y WhatsApp Business"
            setTextColor(textColor)
            isChecked = settings.getWhatsappMode() == "BOTH"
            setOnClickListener { settings.setWhatsappMode("BOTH"); showAppsSoportadas() }
        }
        val normal = RadioButton(this).apply {
            text = "Solo WhatsApp normal"
            setTextColor(textColor)
            isChecked = settings.getWhatsappMode() == "NORMAL"
            setOnClickListener { settings.setWhatsappMode("NORMAL"); showAppsSoportadas() }
        }
        val business = RadioButton(this).apply {
            text = "Solo WhatsApp Business"
            setTextColor(textColor)
            isChecked = settings.getWhatsappMode() == "BUSINESS"
            setOnClickListener { settings.setWhatsappMode("BUSINESS"); showAppsSoportadas() }
        }

        content.addView(both)
        content.addView(normal)
        content.addView(business)
        content.addView(cardView("Recomendación", "Para un negocio usa WhatsApp Business y mantén WhatsApp normal fuera del bot si lo usas para asuntos personales.") {})
    }

    private fun menuCard(title: String, desc: String, action: () -> Unit) {
        content.addView(cardView(title, desc) {
            setOnClickListener { action() }
            button("Abrir") { action() }
        })
    }

    private fun showProximamente(feature: String) {
        content.removeAllViews()
        content.addView(label(feature))
        content.addView(cardView("Próxima versión", "Esta función todavía no está conectada. La app actual responde usando IA/OpenAI o el mensaje de respaldo.") {
            button("Volver al menú") { showMenu() }
        })
    }

    private fun showPermisos() {
        content.removeAllViews()
        content.addView(label("Permisos y seguridad"))

        content.addView(cardView("Acceso a notificaciones", if (isNotificationListenerEnabled()) "Activo. Nexo Auto IA puede detectar notificaciones." else "Pendiente. Activa Nexo Auto IA en acceso a notificaciones.") {
            button("Abrir acceso a notificaciones") {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        })

        content.addView(cardView("Optimización de batería", "En algunos teléfonos Android puede dormir la app. Permite ejecución en segundo plano para mejores resultados.") {
            button("Abrir ajustes de batería") {
                try {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_SETTINGS))
                }
            }
        })

        content.addView(cardView("Privacidad", "Esta app lee notificaciones solo para detectar mensajes de WhatsApp y responder desde la notificación. La API Key se guarda localmente en tu teléfono.") {
            val accepted = CheckBox(this@MainActivity).apply {
                text = "Acepto usar esta app solo para mi negocio y no enviar spam."
                setTextColor(textColor)
                isChecked = settings.isPrivacyAccepted()
                setOnCheckedChangeListener { _, checked ->
                    settings.setPrivacyAccepted(checked)
                    toast(if (checked) "Privacidad aceptada" else "Privacidad pendiente")
                }
            }
            addView(accepted)
        })

        content.addView(cardView("Play Protect", "Esta versión elimina permisos innecesarios como contactos. Aun así, Android puede alertar porque la app lee notificaciones y se instala fuera de Play Store.") {})
    }

    private fun showContactos() {
        content.removeAllViews()

        content.addView(label("Responder automáticamente a"))

        val all = RadioButton(this).apply {
            text = "Todos los chats"
            setTextColor(textColor)
            isChecked = settings.getContactMode() == "ALL"
            setOnClickListener {
                settings.setContactMode("ALL")
                showContactos()
            }
        }

        val unknown = RadioButton(this).apply {
            text = "Chats individuales / clientes nuevos"
            setTextColor(textColor)
            isChecked = settings.getContactMode() == "UNKNOWN_ONLY"
            setOnClickListener {
                settings.setContactMode("UNKNOWN_ONLY")
                showContactos()
            }
        }

        val groups = CheckBox(this).apply {
            text = "Habilitar grupos"
            setTextColor(textColor)
            isChecked = settings.areGroupsEnabled()
            setOnCheckedChangeListener { _, checked ->
                settings.setGroupsEnabled(checked)
                toast(if (checked) "Grupos habilitados" else "Grupos desactivados")
            }
        }

        content.addView(all)
        content.addView(unknown)
        content.addView(groups)

        content.addView(cardView("Recomendación para Nexo", "Usa chats individuales y grupos desactivados para evitar respuestas en conversaciones personales o grupos.") {})
    }

    private fun showConfiguracion() {
        content.removeAllViews()

        content.addView(cardView("Tiempo de respuesta", "${settings.getResponseDelaySeconds()} segundos") {
            val input = EditText(this@MainActivity).apply {
                setText(settings.getResponseDelaySeconds().toString())
                setTextColor(textColor)
                setHintTextColor(muted)
                inputType = InputType.TYPE_CLASS_NUMBER
                hint = "3"
            }
            addView(input)
            button("Guardar tiempo") {
                settings.setResponseDelaySeconds(input.text.toString().toIntOrNull() ?: 3)
                toast("Tiempo guardado")
                showConfiguracion()
            }
        })

        content.addView(cardView("Mensaje de respaldo / bienvenida", settings.getFallbackMessage()) {
            val input = EditText(this@MainActivity).apply {
                setText(settings.getFallbackMessage())
                setTextColor(textColor)
                setHintTextColor(muted)
                minLines = 3
                gravity = Gravity.TOP
            }
            addView(input)
            button("Guardar mensaje") {
                settings.setFallbackMessage(input.text.toString())
                toast("Mensaje guardado")
                showConfiguracion()
            }
        })

        content.addView(cardView("Seguridad", "No compartas capturas de la pestaña IA si tu API Key está visible. Si ya la mostraste, bórrala en OpenAI y crea una nueva.") {
            button("Configurar API Key") { showRespuestaIA() }
        })
    }

    private fun showRespuestaIA() {
        content.removeAllViews()
        content.addView(label("IA / Configuración paso a paso"))

        val currentKey = settings.getOpenAiApiKey()
        val statusText = if (currentKey.startsWith("sk-")) {
            "API Key guardada. Puedes probar la IA."
        } else {
            "Falta guardar una API Key válida. Debe empezar por sk-."
        }

        content.addView(cardView("Estado", statusText) {
            addPrimaryAction("1. PEGAR Y GUARDAR API KEY") {
                showApiKeyScreen()
            }
            addSecondaryAction("2. PROBAR IA") {
                showTestReply()
            }
        })

        content.addView(cardView("Modelo actual", settings.getAiModel()) {
            addPrimaryAction("Configurar modelo y límite") {
                showModelScreen()
            }
        })

        content.addView(cardView("Entrenamiento actual", "Prompt de negocio de Nexo E Store configurado. Tócalo para editarlo sin tapar los botones de guardado.") {
            addPrimaryAction("Editar entrenamiento / prompt") {
                showPromptScreen()
            }
        })

        content.addView(cardView("Cómo dejarlo funcionando", "1. Guarda API Key completa.\n2. Activa permisos en PERMISOS.\n3. Activa el bot en INICIO.\n4. Prueba con WhatsApp cerrado para que llegue notificación.") {})
    }

    private fun showApiKeyScreen() {
        content.removeAllViews()
        content.addView(label("Paso 1: Guardar API Key"))

        content.addView(cardView("API Key de OpenAI", "Pega la clave completa. Debe empezar por sk-. No compartas capturas con la clave visible.") {
            val keyInput = EditText(this@MainActivity).apply {
                setText(settings.getOpenAiApiKey())
                setTextColor(textColor)
                setHintTextColor(muted)
                hint = "sk-..."
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                minLines = 1
                setSingleLine(true)
            }
            addView(keyInput)

            addPrimaryAction("GUARDAR API KEY") {
                val key = keyInput.text.toString().trim()
                if (!key.startsWith("sk-")) {
                    toast("No se guardó: la API Key debe empezar por sk-")
                } else if (key.length < 25) {
                    toast("No se guardó: la API Key parece incompleta")
                } else {
                    settings.setOpenAiApiKey(key)
                    toast("API Key guardada correctamente")
                    showRespuestaIA()
                }
            }

            addSecondaryAction("BORRAR API KEY GUARDADA") {
                settings.setOpenAiApiKey("")
                toast("API Key borrada")
                showApiKeyScreen()
            }
        })

        content.addView(cardView("Estado después de guardar", if (settings.getOpenAiApiKey().startsWith("sk-")) "Guardada correctamente" else "Aún no hay API Key válida guardada") {
            addPrimaryAction("Volver a IA") { showRespuestaIA() }
        })
    }

    private fun showModelScreen() {
        content.removeAllViews()
        content.addView(label("Paso 2: Modelo y límite"))

        content.addView(cardView("Modelo de OpenAI", "Recomendado: gpt-4o-mini") {
            val modelInput = EditText(this@MainActivity).apply {
                setText(settings.getAiModel())
                setTextColor(textColor)
                setHintTextColor(muted)
                hint = "gpt-4o-mini"
                setSingleLine(true)
            }
            addView(modelInput)

            val maxChars = EditText(this@MainActivity).apply {
                setText(settings.getMaxWhatsappChars().toString())
                setTextColor(textColor)
                setHintTextColor(muted)
                hint = "500"
                inputType = InputType.TYPE_CLASS_NUMBER
                setSingleLine(true)
            }
            addView(TextView(this@MainActivity).apply {
                text = "Máximo de caracteres para WhatsApp"
                setTextColor(muted)
                textSize = 14f
                setPadding(0, 18, 0, 0)
            })
            addView(maxChars)

            addPrimaryAction("GUARDAR MODELO") {
                settings.setAiModel(modelInput.text.toString().trim().ifBlank { "gpt-4o-mini" })
                settings.setMaxWhatsappChars(maxChars.text.toString().toIntOrNull() ?: 500)
                toast("Modelo guardado")
                showRespuestaIA()
            }
        })
    }

    private fun showPromptScreen() {
        content.removeAllViews()
        content.addView(label("Paso 3: Entrenar IA"))

        content.addView(cardView("Prompt / entrenamiento", "Edita las reglas de respuesta del negocio.") {
            val prompt = EditText(this@MainActivity).apply {
                setText(settings.getBusinessPrompt())
                setTextColor(textColor)
                setHintTextColor(muted)
                minLines = 8
                maxLines = 12
                gravity = Gravity.TOP
            }
            addView(prompt)

            addPrimaryAction("GUARDAR ENTRENAMIENTO") {
                settings.setBusinessPrompt(prompt.text.toString())
                toast("Entrenamiento guardado")
                showRespuestaIA()
            }

            addSecondaryAction("RESTAURAR PROMPT DE NEXO") {
                settings.setBusinessPrompt(SettingsStore.DEFAULT_NEXO_PROMPT)
                toast("Prompt restaurado")
                showPromptScreen()
            }
        })
    }

    private fun showTestReply() {
        content.removeAllViews()
        content.addView(label("Respuesta de prueba"))

        val input = EditText(this).apply {
            hint = "Ejemplo: Hola, tienes Netflix?"
            setHintTextColor(muted)
            setTextColor(textColor)
            minLines = 3
            gravity = Gravity.TOP
        }
        content.addView(input)

        val result = TextView(this).apply {
            setTextColor(textColor)
            textSize = 16f
            setPadding(0, 18, 0, 18)
        }
        content.addView(result)

        button("Generar respuesta") {
            result.text = "Generando..."
            CoroutineScope(Dispatchers.IO).launch {
                val reply = AutoReplyEngine.generateReply(
                    customerName = "Cliente de prueba",
                    customerMessage = input.text.toString().ifBlank { "Hola, tienes Netflix?" },
                    settings = settings
                )
                withContext(Dispatchers.Main) {
                    result.text = reply
                }
            }
        }.also { content.addView(it) }

        button("Volver a IA") { showRespuestaIA() }.also { content.addView(it) }
    }

    private fun showHistorial() {
        content.removeAllViews()
        content.addView(label("Historial básico"))
        val logs = MessageHistoryStore(this).getLogs().ifBlank { "Aún no hay mensajes respondidos." }
        content.addView(cardView("Mensajes", logs) {
            button("Limpiar historial") {
                MessageHistoryStore(this@MainActivity).clear()
                showHistorial()
            }
        })
    }

    private fun cardView(title: String, desc: String, extra: LinearLayout.() -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(card)
            setPadding(26, 22, 26, 22)
            val params = LinearLayout.LayoutParams(-1, -2)
            params.setMargins(0, 0, 0, 18)
            layoutParams = params

            addView(TextView(this@MainActivity).apply {
                text = title
                setTextColor(textColor)
                textSize = 20f
                typeface = Typeface.DEFAULT_BOLD
            })

            addView(TextView(this@MainActivity).apply {
                text = desc
                setTextColor(muted)
                textSize = 16f
                setPadding(0, 8, 0, 8)
            })

            extra()
        }
    }

    private fun label(value: String): TextView {
        return TextView(this).apply {
            text = value
            setTextColor(accent)
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 10, 0, 18)
        }
    }

    private fun LinearLayout.addPrimaryAction(value: String, action: () -> Unit) {
        addView(TextView(this@MainActivity).apply {
            text = value
            setTextColor(textColor)
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setBackgroundColor(accent)
            setPadding(20, 18, 20, 18)
            setOnClickListener { action() }
            val params = LinearLayout.LayoutParams(-1, -2)
            params.setMargins(0, 16, 0, 0)
            layoutParams = params
        })
    }

    private fun LinearLayout.addSecondaryAction(value: String, action: () -> Unit) {
        addView(TextView(this@MainActivity).apply {
            text = value
            setTextColor(textColor)
            textSize = 14f
            gravity = Gravity.CENTER
            setBackgroundColor(0xFF24485A.toInt())
            setPadding(20, 16, 20, 16)
            setOnClickListener { action() }
            val params = LinearLayout.LayoutParams(-1, -2)
            params.setMargins(0, 12, 0, 0)
            layoutParams = params
        })
    }

    private fun button(value: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = value
            setTextColor(textColor)
            setBackgroundColor(accent)
            setOnClickListener { action() }
            val params = LinearLayout.LayoutParams(-1, -2)
            params.setMargins(0, 12, 0, 0)
            layoutParams = params
        }
    }

    private fun isNotificationListenerEnabled(): Boolean {
        val enabledListeners = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        val componentName = ComponentName(this, NexoNotificationListener::class.java).flattenToString()
        return enabledListeners.contains(componentName)
    }

    private fun askNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
    }

    private fun toast(value: String) {
        Toast.makeText(this, value, Toast.LENGTH_SHORT).show()
    }
}
