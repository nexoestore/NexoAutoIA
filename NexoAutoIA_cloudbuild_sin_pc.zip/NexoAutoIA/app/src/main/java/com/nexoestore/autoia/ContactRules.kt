package com.nexoestore.autoia

import android.content.Context

object ContactRules {

    fun shouldReply(context: Context, chatTitle: String, messageText: String, settings: SettingsStore): Boolean {
        if (chatTitle.isBlank() || messageText.isBlank()) return false

        val isPossibleGroup = chatTitle.contains(":") || messageText.startsWith("~")
        if (isPossibleGroup && !settings.areGroupsEnabled()) return false

        // Primera versión:
        // ALL: responde todo.
        // UNKNOWN_ONLY: responde chats individuales. La detección real de contactos guardados
        // puede ampliarse con READ_CONTACTS y listas manuales.
        return when (settings.getContactMode()) {
            "ALL" -> true
            "UNKNOWN_ONLY" -> !isPossibleGroup
            else -> !isPossibleGroup
        }
    }
}
