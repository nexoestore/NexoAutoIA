package com.nexoestore.autoia

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MessageHistoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("nexo_auto_ia_history", Context.MODE_PRIVATE)

    fun addLog(chatTitle: String, incoming: String, outgoing: String, diagnostic: String = "") {
        val current = prefs.getString("logs", "") ?: ""
        val date = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        val line = "[$date] $chatTitle\nCliente: $incoming\nBot: $outgoing\nDiagnóstico: $diagnostic\n---\n"
        prefs.edit().putString("logs", (line + current).take(20000)).apply()
    }

    fun getLogs(): String = prefs.getString("logs", "") ?: ""
    fun clear() = prefs.edit().clear().apply()
}
