package com.nexoestore.autoia

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class NexoNotificationListener : NotificationListenerService() {

    private val scope = CoroutineScope(Dispatchers.IO)
    private val processedMessages = LinkedHashSet<String>()

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val settings = SettingsStore(applicationContext)
        val packageName = sbn.packageName

        val allowedByMode = when (settings.getWhatsappMode()) {
            "NORMAL" -> packageName == "com.whatsapp"
            "BUSINESS" -> packageName == "com.whatsapp.w4b"
            else -> packageName == "com.whatsapp" || packageName == "com.whatsapp.w4b"
        }
        if (!allowedByMode) return

        val notification = sbn.notification ?: return
        val extras = notification.extras

        val chatTitle = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val messageText = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()

        if (chatTitle.isBlank() || messageText.isBlank()) return
        if (messageText.contains("mensajes nuevos", ignoreCase = true)) return
        if (messageText.contains("new messages", ignoreCase = true)) return
        if (messageText == settings.getFallbackMessage()) return

        val messageKey = "${sbn.packageName}-${chatTitle}-${messageText}"
        if (processedMessages.contains(messageKey)) return
        processedMessages.add(messageKey)

        if (processedMessages.size > 300) {
            val iterator = processedMessages.iterator()
            repeat(80) {
                if (iterator.hasNext()) {
                    iterator.next()
                    iterator.remove()
                }
            }
        }

        val replyAction = notification.actions?.firstOrNull { action ->
            action.remoteInputs?.isNotEmpty() == true
        } ?: return

        scope.launch {
            try {
                if (!settings.isBotEnabled()) return@launch
                if (!ContactRules.shouldReply(applicationContext, chatTitle, messageText, settings)) return@launch

                val delayMillis = settings.getResponseDelaySeconds().coerceIn(0, 60) * 1000L
                if (delayMillis > 0) delay(delayMillis)

                val response = AutoReplyEngine.generateReply(
                    customerName = chatTitle,
                    customerMessage = messageText,
                    settings = settings
                )

                if (response.isBlank()) return@launch

                sendReply(replyAction, response)
                MessageHistoryStore(applicationContext).addLog(chatTitle, messageText, response)
            } catch (e: Exception) {
                MessageHistoryStore(applicationContext).addLog(chatTitle, messageText, "ERROR: ${e.message}")
                e.printStackTrace()
            }
        }
    }

    private fun sendReply(action: Notification.Action, message: String) {
        val remoteInput = action.remoteInputs?.firstOrNull() ?: return

        val intent = Intent()
        val bundle = Bundle()
        bundle.putCharSequence(remoteInput.resultKey, message)

        RemoteInput.addResultsToIntent(
            arrayOf(remoteInput),
            intent,
            bundle
        )

        try {
            action.actionIntent.send(this, 0, intent)
        } catch (e: PendingIntent.CanceledException) {
            e.printStackTrace()
        }
    }
}
