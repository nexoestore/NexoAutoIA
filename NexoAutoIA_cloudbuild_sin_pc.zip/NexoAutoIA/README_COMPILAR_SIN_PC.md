# Compilar Nexo Auto IA sin PC usando solo celular

Esta versión incluye un flujo de GitHub Actions para generar el APK en la nube.

## Pasos desde el celular

1. Crea o entra a tu cuenta de GitHub.
2. Crea un repositorio nuevo llamado `NexoAutoIA`.
3. Sube todos los archivos de esta carpeta al repositorio.
4. Entra a la pestaña **Actions**.
5. Abre el flujo **Construir APK Android**.
6. Toca **Run workflow**.
7. Espera que termine.
8. Abre la ejecución finalizada.
9. En **Artifacts**, descarga `NexoAutoIA-debug-apk`.
10. Descomprime el archivo descargado y encontrarás el APK.

## Instalar en Android

1. Descarga el APK en el celular.
2. Toca el archivo APK.
3. Permite instalar apps de origen desconocido si Android lo solicita.
4. Abre **Nexo Auto IA**.
5. Activa el permiso de acceso a notificaciones.
6. Pega tu API Key de OpenAI.
7. Activa el bot.

## Importante

Este APK es una versión debug para pruebas. Para publicar o vender la app se debe generar un APK/AAB release firmado.


## Corrección incluida

Esta versión corrige el conflicto de nombre `text` en `MainActivity.kt` que podía provocar error de compilación Kotlin en GitHub Actions.
