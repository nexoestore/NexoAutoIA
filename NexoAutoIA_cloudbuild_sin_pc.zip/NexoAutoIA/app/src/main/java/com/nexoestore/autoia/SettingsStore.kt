package com.nexoestore.autoia

import android.content.Context
import android.content.SharedPreferences

class SettingsStore(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("nexo_auto_ia_settings", Context.MODE_PRIVATE)

    fun isBotEnabled(): Boolean = prefs.getBoolean("botEnabled", false)
    fun setBotEnabled(value: Boolean) = prefs.edit().putBoolean("botEnabled", value).apply()

    fun getGeminiApiKey(): String = prefs.getString("geminiApiKey", "") ?: ""
    fun setGeminiApiKey(value: String) = prefs.edit().putString("geminiApiKey", value.trim()).apply()
    fun clearGeminiApiKey() = prefs.edit().remove("geminiApiKey").apply()

    fun getGeminiModel(): String = prefs.getString("geminiModel", "gemini-2.5-flash") ?: "gemini-2.5-flash"
    fun setGeminiModel(value: String) = prefs.edit().putString("geminiModel", value.trim().ifBlank { "gemini-2.5-flash" }).apply()

    fun getBusinessPrompt(): String =
        prefs.getString("businessPrompt", DEFAULT_NEXO_PROMPT) ?: DEFAULT_NEXO_PROMPT

    fun setBusinessPrompt(value: String) =
        prefs.edit().putString("businessPrompt", value.trim().ifBlank { DEFAULT_NEXO_PROMPT }).apply()

    fun getFallbackMessage(): String =
        prefs.getString("fallbackMessage", DEFAULT_FALLBACK) ?: DEFAULT_FALLBACK

    fun setFallbackMessage(value: String) =
        prefs.edit().putString("fallbackMessage", value.trim().ifBlank { DEFAULT_FALLBACK }).apply()

    fun getWelcomeMessage(): String =
        prefs.getString("welcomeMessage", DEFAULT_WELCOME) ?: DEFAULT_WELCOME

    fun setWelcomeMessage(value: String) =
        prefs.edit().putString("welcomeMessage", value.trim().ifBlank { DEFAULT_WELCOME }).apply()

    fun isWelcomeEnabled(): Boolean = prefs.getBoolean("welcomeEnabled", true)
    fun setWelcomeEnabled(value: Boolean) = prefs.edit().putBoolean("welcomeEnabled", value).apply()

    fun getMenuMessage(): String =
        prefs.getString("menuMessage", DEFAULT_MENU) ?: DEFAULT_MENU

    fun setMenuMessage(value: String) =
        prefs.edit().putString("menuMessage", value.trim().ifBlank { DEFAULT_MENU }).apply()

    fun isMenuEnabled(): Boolean = prefs.getBoolean("menuEnabled", true)
    fun setMenuEnabled(value: Boolean) = prefs.edit().putBoolean("menuEnabled", value).apply()

    fun getKeywordRules(): String =
        prefs.getString("keywordRules", DEFAULT_KEYWORDS) ?: DEFAULT_KEYWORDS

    fun setKeywordRules(value: String) =
        prefs.edit().putString("keywordRules", value.trim()).apply()

    fun areKeywordRulesEnabled(): Boolean = prefs.getBoolean("keywordEnabled", true)
    fun setKeywordRulesEnabled(value: Boolean) = prefs.edit().putBoolean("keywordEnabled", value).apply()

    fun getServerUrl(): String = prefs.getString("serverUrl", "") ?: ""
    fun setServerUrl(value: String) = prefs.edit().putString("serverUrl", value.trim()).apply()
    fun isServerEnabled(): Boolean = prefs.getBoolean("serverEnabled", false)
    fun setServerEnabled(value: Boolean) = prefs.edit().putBoolean("serverEnabled", value).apply()

    fun getNotes(): String = prefs.getString("notes", "") ?: ""
    fun setNotes(value: String) = prefs.edit().putString("notes", value).apply()

    fun getMaxWhatsappChars(): Int = prefs.getInt("maxWhatsappChars", 500)
    fun setMaxWhatsappChars(value: Int) = prefs.edit().putInt("maxWhatsappChars", value.coerceIn(80, 1500)).apply()

    fun getResponseDelaySeconds(): Int = prefs.getInt("responseDelaySeconds", 3)
    fun setResponseDelaySeconds(value: Int) = prefs.edit().putInt("responseDelaySeconds", value.coerceIn(0, 60)).apply()

    fun getContactMode(): String = prefs.getString("contactMode", "ALL") ?: "ALL"
    fun setContactMode(value: String) = prefs.edit().putString("contactMode", value).apply()

    fun areGroupsEnabled(): Boolean = prefs.getBoolean("groupsEnabled", false)
    fun setGroupsEnabled(value: Boolean) = prefs.edit().putBoolean("groupsEnabled", value).apply()

    fun getSupportedAppsMode(): String = prefs.getString("supportedAppsMode", "BOTH") ?: "BOTH"
    fun setSupportedAppsMode(value: String) = prefs.edit().putString("supportedAppsMode", value).apply()

    fun getLastDiagnostic(): String = prefs.getString("lastDiagnostic", "Sin diagnóstico todavía.") ?: "Sin diagnóstico todavía."
    fun setLastDiagnostic(value: String) = prefs.edit().putString("lastDiagnostic", value.take(2000)).apply()

    companion object {
        const val DEFAULT_FALLBACK =
            "¡Hola! 😊 Gracias por escribir a Nexo E Store. En breve te ayudamos."

        const val DEFAULT_WELCOME =
            "¡Hola! 😊 Bienvenido a Nexo E Store. ¿Qué servicio necesitas hoy?"

        val DEFAULT_MENU = """
            Menú Nexo E Store 😊
            1. Streaming
            2. Recargas
            3. Métodos de pago
            4. Hablar con asesor
        """.trimIndent()

        val DEFAULT_KEYWORDS = """
            netflix=Hola 😊 Por el momento no manejamos renovación de Netflix. Tenemos otros servicios disponibles. ¿Deseas que te comparta opciones?
            disney=Claro 😊 Te ayudo con Disney+. Indícame si lo necesitas por 1 mes y te confirmo disponibilidad.
            prime=Claro 😊 Te ayudo con Prime Video. ¿Lo necesitas por 1 mes?
            youtube=Claro 😊 Te ayudo con YouTube Premium. ¿Deseas cuenta nueva o renovación?
            nequi=Perfecto ✅ Puedes pagar por Nequi. Envía el comprobante por este chat para validar tu pedido.
            soporte=Claro, te ayudo con soporte. Envíame tu número de pedido y el problema presentado.
            asesor=Claro 😊 Te comunico con un asesor de Nexo E Store.
        """.trimIndent()

        val DEFAULT_NEXO_PROMPT = """
            Eres el asistente virtual de Nexo E Store.

            Nexo E Store vende servicios de streaming, recargas digitales y productos relacionados.

            Información crítica del negocio:
            - Nexo E Store NO renueva Netflix.
            - Si preguntan por renovación de Netflix, responde que por el momento no se maneja renovación de Netflix y ofrece otros servicios.
            - No inventes precios ni disponibilidad.
            - No prometas activaciones inmediatas sin validar pago.
            - Si envían comprobante, responde que será validado por un asesor.
            - Si escriben asesor, humano, reclamo o garantía, deriva a atención humana.

            Reglas de estilo:
            - Responde en español latino.
            - Sé breve, amable y comercial.
            - Usa máximo 3 líneas.
            - No digas que eres Gemini ni IA.
            - No pidas contraseñas personales.
            - No solicites datos de tarjetas.
            - Si el cliente quiere comprar, pide servicio, duración y método de pago.
        """.trimIndent()
    }
}
