package com.nexoestore.autoia

data class RuleDecision(
    val shouldReply: Boolean,
    val useGemini: Boolean,
    val reply: String,
    val reason: String
)

object RuleEngine {
    fun decide(
        customerName: String,
        customerMessage: String,
        settings: SettingsStore
    ): RuleDecision {
        val msg = customerMessage.trim()
        val lower = msg.lowercase()

        if (msg.isBlank()) {
            return RuleDecision(false, false, "", "Mensaje vacío")
        }

        if (looksLikeOwnBotReply(lower, settings)) {
            return RuleDecision(false, false, "", "Ignorado: parece una respuesta enviada por el bot")
        }

        if (containsAny(lower, listOf("asesor", "humano", "reclamo", "garantía", "garantia"))) {
            return RuleDecision(true, false, "Claro 😊 Te comunico con un asesor de Nexo E Store para revisar tu caso.", "Derivar a asesor")
        }

        if (lower.contains("netflix") && containsAny(lower, listOf("renov", "renuevo", "renovar", "renovación", "renovacion"))) {
            return RuleDecision(
                true,
                false,
                "Hola 😊 Por el momento no manejamos renovación de Netflix. Tenemos Amazon Prime, Max Platino y Disney Premium disponibles.",
                "Regla crítica: no renovar Netflix"
            )
        }

        if (settings.isWelcomeEnabled() && isGreeting(lower)) {
            return RuleDecision(true, false, settings.getWelcomeMessage(), "Mensaje de bienvenida")
        }

        if (settings.isMenuEnabled() && containsAny(lower, listOf("menu", "menú", "opciones", "catalogo", "catálogo", "servicios", "disponible", "disponibles"))) {
            return RuleDecision(true, false, settings.getMenuMessage(), "Menú automático")
        }

        if (containsAny(lower, listOf("nequi", "binance", "pagar", "pago", "método de pago", "metodo de pago", "donde pago", "dónde pago"))) {
            return RuleDecision(true, false, "Puedes pagar por Nequi al 3052154226 o por Binance al 376619565. Luego envíanos el comprobante para validarlo ✅", "Métodos de pago")
        }

        if (containsAny(lower, listOf("comprobante", "recibo", "capture", "captura", "ya pague", "ya pagué"))) {
            return RuleDecision(true, false, "Perfecto ✅ Tu comprobante será validado por un asesor. En breve te confirmamos.", "Validación de comprobante")
        }

        // Importante:
        // No respondemos localmente a Disney, Prime, Max ni precio.
        // Esos mensajes pasan a Gemini para que actúe como asistente usando el entrenamiento completo.
        if (settings.areKeywordRulesEnabled()) {
            parseKeywordRules(settings.getKeywordRules()).forEach { (keyword, response) ->
                val key = keyword.lowercase()
                val reservedForGemini = key in listOf("disney", "prime", "amazon", "max", "precio", "precios")
                if (!reservedForGemini && key.isNotBlank() && lower.contains(key)) {
                    return RuleDecision(true, false, response, "Palabra clave: $keyword")
                }
            }
        }

        return RuleDecision(true, true, "", "Sin regla local: consultar Gemini como asistente")
    }

    fun parseKeywordRules(raw: String): List<Pair<String, String>> {
        return raw.lines()
            .map { it.trim() }
            .filter { it.isNotBlank() && !it.startsWith("#") && it.contains("=") }
            .mapNotNull { line ->
                val parts = line.split("=", limit = 2)
                val key = parts.getOrNull(0)?.trim().orEmpty()
                val value = parts.getOrNull(1)?.trim().orEmpty()
                if (key.isBlank() || value.isBlank()) null else key to value
            }
    }

    private fun containsAny(text: String, words: List<String>): Boolean {
        return words.any { text.contains(it.lowercase()) }
    }

    private fun isGreeting(text: String): Boolean {
        val cleaned = text.trim().lowercase()
        return cleaned in listOf("hola", "buenas", "buenos dias", "buenos días", "buenas tardes", "buenas noches", "hey", "ola")
    }

    private fun looksLikeOwnBotReply(text: String, settings: SettingsStore): Boolean {
        val cleaned = text.trim().lowercase()
        if (cleaned.isBlank()) return false

        val knownBotPhrases = listOf(
            "bienvenido a nexo e store",
            "gracias por escribir a nexo e store",
            "te comunico con un asesor",
            "tu comprobante será validado",
            "tu comprobante sera validado",
            "puedes pagar por nequi",
            "por el momento no manejamos renovación de netflix",
            "por el momento no manejamos renovacion de netflix"
        )

        return knownBotPhrases.any { cleaned.contains(it) }
    }
}
