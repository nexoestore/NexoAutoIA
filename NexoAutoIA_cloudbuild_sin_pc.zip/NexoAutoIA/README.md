# Nexo Auto IA v11

Versión enfocada en que el usuario pueda operar todo desde pantalla:

- Guardar API Key Gemini visible.
- Guardar modelo y límite.
- Guardar entrenamiento/prompt.
- Abrir acceso a notificaciones.
- Abrir ajustes de app si Android bloquea permisos restringidos.
- Diagnóstico Gemini real.
- Respuesta de prueba con diagnóstico.
- Motor de reglas: Netflix no renovable, bienvenida, menú, palabras clave.
- Historial y mensaje de respaldo.

La API Key Gemini puede empezar por `AQ` o `AIza`.


## v14 CRM + Campañas controladas

Esta versión combina:
- CRM de clientes.
- Embudo comercial.
- Memoria por cliente.
- Clientes calientes.
- Modo humano 30 minutos.
- Seguimiento programado.
- Campañas controladas.
- Apertura de WhatsApp con mensaje preparado.
- Motor de reglas antes de Gemini para reducir costos.

Nota: por seguridad, las campañas no hacen spam automático. Preparan/copían/abren WhatsApp cliente por cliente.
