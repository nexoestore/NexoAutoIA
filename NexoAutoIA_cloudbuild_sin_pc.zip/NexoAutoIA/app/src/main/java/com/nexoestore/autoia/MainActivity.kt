package com.nexoestore.autoia

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : Activity() {

    private lateinit var settings: SettingsStore
    private lateinit var content: LinearLayout

    private val bg = 0xFF07131D.toInt()
    private val card = 0xFF102536.toInt()
    private val accent = 0xFF00A884.toInt()
    private val danger = 0xFFB3261E.toInt()
    private val white = 0xFFFFFFFF.toInt()
    private val muted = 0xFFC6D0D6.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = SettingsStore(this)
        askNotificationPermissionIfNeeded()
        showMain()
    }

    private fun showMain() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

        root.addView(TextView(this).apply {
            setTextColor(white)
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
            text = "Nexo Auto IA v10"
            setPadding(24, 30, 24, 10)
        })

        val tabs1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(10, 0, 10, 0) }
        val tabs2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(10, 0, 10, 8) }

        tabs1.addView(tabButton("INICIO") { showInicio() })
        tabs1.addView(tabButton("GEMINI") { showGemini() })
        tabs1.addView(tabButton("REGLAS") { showReglas() })
        tabs2.addView(tabButton("ENTRENAR") { showEntrenamiento() })
        tabs2.addView(tabButton("PERMISOS") { showPermisos() })
        tabs2.addView(tabButton("HISTORIAL") { showHistorial() })

        root.addView(tabs1)
        root.addView(tabs2)

        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 12, 18, 28)
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
        showInicio()
    }

    private fun showInicio() {
        content.removeAllViews()

        content.addView(cardView("Respuesta automática", if (settings.isBotEnabled()) "ACTIVADA ✅" else "DESACTIVADA") {
            val sw = Switch(this@MainActivity).apply {
                isChecked = settings.isBotEnabled()
                setOnCheckedChangeListener { _, checked ->
                    settings.setBotEnabled(checked)
                    toast(if (checked) "Bot activado" else "Bot pausado")
                }
            }
            addView(sw)
        })

        content.addView(cardView("Estado real del bot", buildString {
            append("Gemini: ${if (settings.getGeminiApiKey().isBlank()) "Falta API Key" else "API guardada"}\n")
            append("Modelo: ${settings.getGeminiModel()}\n")
            append("Apps: ${settings.getSupportedAppsMode()}\n")
            append("Último diagnóstico: ${settings.getLastDiagnostic()}")
        }) {
            button("Configurar Gemini") { showGemini() }
            button("Probar respuesta") { showTestReply() }
            button("Abrir permisos") { showPermisos() }
        })

        content.addView(cardView("Flujo profesional", "WhatsApp → Notificación → Motor de reglas → Gemini si hace falta → Respuesta automática.") {})
    }

    private fun showGemini() {
        content.removeAllViews()
        content.addView(label("Gemini API"))

        content.addView(cardView("Paso 1: API Key Gemini", "Acepta claves nuevas que empiezan por AQ y claves estándar que empiezan por AIza.") {
            val keyInput = EditText(this@MainActivity).apply {
                setText(settings.getGeminiApiKey())
                setTextColor(white)
                setHintTextColor(muted)
                hint = "AQ... o AIza..."
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            }
            addView(keyInput)

            button("GUARDAR API KEY") {
                val key = keyInput.text.toString().trim()
                if (GeminiService.isValidKeyFormat(key)) {
                    settings.setGeminiApiKey(key)
                    settings.setLastDiagnostic("API Key Gemini guardada.")
                    toast("API Key Gemini guardada")
                    showGemini()
                } else {
                    toast("No se guardó: debe empezar por AQ o AIza")
                }
            }

            redButton("BORRAR API KEY") {
                settings.clearGeminiApiKey()
                settings.setLastDiagnostic("API Key Gemini borrada.")
                toast("API Key borrada")
                showGemini()
            }
        })

        content.addView(cardView("Paso 2: Modelo y límite", "Modelo recomendado: gemini-2.5-flash") {
            val modelInput = EditText(this@MainActivity).apply {
                setText(settings.getGeminiModel())
                setTextColor(white)
                setHintTextColor(muted)
                hint = "gemini-2.5-flash"
            }
            val charsInput = EditText(this@MainActivity).apply {
                setText(settings.getMaxWhatsappChars().toString())
                setTextColor(white)
                setHintTextColor(muted)
                hint = "500"
                inputType = InputType.TYPE_CLASS_NUMBER
            }
            addView(modelInput)
            addView(charsInput)

            button("GUARDAR MODELO") {
                settings.setGeminiModel(modelInput.text.toString())
                settings.setMaxWhatsappChars(charsInput.text.toString().toIntOrNull() ?: 500)
                toast("Modelo guardado")
            }
        })

        content.addView(cardView("Paso 3: Diagnóstico Gemini", "Prueba conexión real con Gemini y mira el error exacto si falla.") {
            button("PROBAR GEMINI REAL") { showTestReply() }
        })
    }

    private fun showReglas() {
        content.removeAllViews()
        content.addView(label("Motor de reglas"))

        content.addView(cardView("Por qué existe", "El motor de reglas decide si responde localmente, si llama a Gemini o si no responde. Ahorra costo y evita errores.") {})

        content.addView(cardView("Palabras clave", "Formato: palabra=respuesta. Una regla por línea.") {
            val enabled = CheckBox(this@MainActivity).apply {
                text = "Activar palabras clave"
                setTextColor(white)
                isChecked = settings.areKeywordRulesEnabled()
                setOnCheckedChangeListener { _, checked -> settings.setKeywordRulesEnabled(checked) }
            }
            val input = EditText(this@MainActivity).apply {
                setText(settings.getKeywordRules())
                setTextColor(white)
                setHintTextColor(muted)
                minLines = 8
                gravity = Gravity.TOP
            }
            addView(enabled)
            addView(input)
            button("GUARDAR PALABRAS CLAVE") {
                settings.setKeywordRules(input.text.toString())
                toast("Reglas guardadas")
            }
        })

        content.addView(cardView("Menú automático", "Se envía cuando el cliente escribe menú, opciones, catálogo o servicios.") {
            val enabled = CheckBox(this@MainActivity).apply {
                text = "Activar menú automático"
                setTextColor(white)
                isChecked = settings.isMenuEnabled()
                setOnCheckedChangeListener { _, checked -> settings.setMenuEnabled(checked) }
            }
            val input = EditText(this@MainActivity).apply {
                setText(settings.getMenuMessage())
                setTextColor(white)
                setHintTextColor(muted)
                minLines = 5
                gravity = Gravity.TOP
            }
            addView(enabled)
            addView(input)
            button("GUARDAR MENÚ") {
                settings.setMenuMessage(input.text.toString())
                toast("Menú guardado")
            }
        })

        content.addView(cardView("Mensaje de bienvenida", "Se usa para saludos simples como hola, buenas o hey.") {
            val enabled = CheckBox(this@MainActivity).apply {
                text = "Activar bienvenida"
                setTextColor(white)
                isChecked = settings.isWelcomeEnabled()
                setOnCheckedChangeListener { _, checked -> settings.setWelcomeEnabled(checked) }
            }
            val input = EditText(this@MainActivity).apply {
                setText(settings.getWelcomeMessage())
                setTextColor(white)
                setHintTextColor(muted)
                minLines = 3
            }
            addView(enabled)
            addView(input)
            button("GUARDAR BIENVENIDA") {
                settings.setWelcomeMessage(input.text.toString())
                toast("Bienvenida guardada")
            }
        })
    }

    private fun showEntrenamiento() {
        content.removeAllViews()
        content.addView(label("Entrenamiento Gemini"))

        content.addView(cardView("Regla crítica incluida", "Nexo E Store NO renueva Netflix. Gemini debe saberlo siempre.") {})

        content.addView(cardView("Prompt del negocio", "Este texto se envía como instrucción a Gemini antes de responder.") {
            val prompt = EditText(this@MainActivity).apply {
                setText(settings.getBusinessPrompt())
                setTextColor(white)
                setHintTextColor(muted)
                minLines = 14
                gravity = Gravity.TOP
            }
            addView(prompt)
            button("GUARDAR ENTRENAMIENTO") {
                settings.setBusinessPrompt(prompt.text.toString())
                toast("Entrenamiento guardado")
            }
            button("RESTAURAR PROMPT NEXO") {
                settings.setBusinessPrompt(SettingsStore.DEFAULT_NEXO_PROMPT)
                toast("Prompt restaurado")
                showEntrenamiento()
            }
        })

        content.addView(cardView("Notas internas", "Guarda precios, recordatorios o reglas que quieras copiar al prompt después.") {
            val notes = EditText(this@MainActivity).apply {
                setText(settings.getNotes())
                setTextColor(white)
                setHintTextColor(muted)
                minLines = 5
                gravity = Gravity.TOP
                hint = "Ejemplo: Disney 1 mes, métodos de pago, horarios..."
            }
            addView(notes)
            button("GUARDAR NOTAS") {
                settings.setNotes(notes.text.toString())
                toast("Notas guardadas")
            }
        })
    }

    private fun showPermisos() {
        content.removeAllViews()
        content.addView(label("Permisos y apps"))

        content.addView(cardView("Acceso a notificaciones", "Obligatorio para leer mensajes de WhatsApp y responder desde la notificación.") {
            button("ABRIR ACCESO A NOTIFICACIONES") {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        })

        content.addView(cardView("Batería", "Desactiva optimización de batería para que Android no duerma la app.") {
            button("ABRIR AJUSTES DE BATERÍA") {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        })

        content.addView(cardView("Apps soportadas", "Elige dónde responder.") {
            radio("WhatsApp normal", settings.getSupportedAppsMode() == "WHATSAPP") {
                settings.setSupportedAppsMode("WHATSAPP")
                showPermisos()
            }
            radio("WhatsApp Business", settings.getSupportedAppsMode() == "BUSINESS") {
                settings.setSupportedAppsMode("BUSINESS")
                showPermisos()
            }
            radio("Ambos", settings.getSupportedAppsMode() == "BOTH") {
                settings.setSupportedAppsMode("BOTH")
                showPermisos()
            }
        })

        content.addView(cardView("Contactos y grupos", "Por seguridad, grupos vienen desactivados.") {
            radio("Responder todos los chats individuales", settings.getContactMode() == "ALL") {
                settings.setContactMode("ALL")
                showPermisos()
            }
            radio("Modo seguro: no grupos", settings.getContactMode() == "UNKNOWN_ONLY") {
                settings.setContactMode("UNKNOWN_ONLY")
                showPermisos()
            }
            val groups = CheckBox(this@MainActivity).apply {
                text = "Habilitar grupos"
                setTextColor(white)
                isChecked = settings.areGroupsEnabled()
                setOnCheckedChangeListener { _, checked -> settings.setGroupsEnabled(checked) }
            }
            addView(groups)
        })
    }

    private fun showTestReply() {
        content.removeAllViews()
        content.addView(label("Respuesta de prueba"))

        val input = EditText(this).apply {
            hint = "Ejemplo: ¿Renuevas Netflix?"
            setHintTextColor(muted)
            setTextColor(white)
            minLines = 3
        }
        content.addView(input)

        val result = TextView(this).apply {
            setTextColor(white)
            textSize = 16f
            setPadding(0, 18, 0, 18)
        }
        content.addView(result)

        button("GENERAR RESPUESTA") {
            result.text = "Generando..."
            CoroutineScope(Dispatchers.IO).launch {
                val reply = AutoReplyEngine.generateReplyDetailed(
                    customerName = "Cliente de prueba",
                    customerMessage = input.text.toString(),
                    settings = settings
                )
                settings.setLastDiagnostic(reply.diagnostic)
                withContext(Dispatchers.Main) {
                    result.text = "Respuesta:\n${reply.text}\n\nDiagnóstico:\n${reply.diagnostic}"
                }
            }
        }.also { content.addView(it) }

        button("PROBAR NETFLIX NO RENOVACIÓN") {
            input.setText("Hola, ¿me renuevas Netflix?")
        }.also { content.addView(it) }
    }

    private fun showHistorial() {
        content.removeAllViews()
        content.addView(label("Historial y diagnóstico"))

        content.addView(cardView("Último diagnóstico", settings.getLastDiagnostic()) {})

        val logs = MessageHistoryStore(this).getLogs().ifBlank { "Aún no hay mensajes respondidos." }
        content.addView(cardView("Mensajes", logs) {
            button("LIMPIAR HISTORIAL") {
                MessageHistoryStore(this@MainActivity).clear()
                toast("Historial limpio")
                showHistorial()
            }
        })

        content.addView(cardView("Mensaje de respaldo", settings.getFallbackMessage()) {
            val input = EditText(this@MainActivity).apply {
                setText(settings.getFallbackMessage())
                setTextColor(white)
                setHintTextColor(muted)
                minLines = 3
            }
            addView(input)
            button("GUARDAR RESPALDO") {
                settings.setFallbackMessage(input.text.toString())
                toast("Mensaje de respaldo guardado")
            }
        })
    }

    private fun tabButton(label: String, action: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(white)
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(6, 13, 6, 13)
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
    }

    private fun cardView(title: String, desc: String, extra: LinearLayout.() -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(card)
            setPadding(24, 20, 24, 20)
            val params = LinearLayout.LayoutParams(-1, -2)
            params.setMargins(0, 0, 0, 16)
            layoutParams = params

            addView(TextView(this@MainActivity).apply {
                text = title
                setTextColor(white)
                textSize = 19f
                typeface = Typeface.DEFAULT_BOLD
            })

            addView(TextView(this@MainActivity).apply {
                text = desc
                setTextColor(muted)
                textSize = 15f
                setPadding(0, 8, 0, 10)
            })

            extra()
        }
    }

    private fun label(value: String): TextView {
        return TextView(this).apply {
            text = value
            setTextColor(accent)
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 8, 0, 16)
        }
    }

    private fun button(value: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = value
            setTextColor(white)
            setBackgroundColor(accent)
            setOnClickListener { action() }
        }
    }

    private fun redButton(value: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = value
            setTextColor(white)
            setBackgroundColor(danger)
            setOnClickListener { action() }
        }
    }

    private fun LinearLayout.radio(value: String, checked: Boolean, action: () -> Unit) {
        addView(RadioButton(this@MainActivity).apply {
            text = value
            setTextColor(white)
            isChecked = checked
            setOnClickListener { action() }
        })
    }

    private fun askNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
    }

    private fun toast(value: String) {
        Toast.makeText(this, value, Toast.LENGTH_SHORT).show()
    }
}
