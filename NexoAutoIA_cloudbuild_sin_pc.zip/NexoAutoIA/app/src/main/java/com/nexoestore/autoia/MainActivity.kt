package com.nexoestore.autoia

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : Activity() {

    private lateinit var settings: SettingsStore
    private lateinit var content: LinearLayout

    private val bg = 0xFF0B1822.toInt()
    private val card = 0xFF132838.toInt()
    private val accent = 0xFF009688.toInt()
    private val textColor = 0xFFFFFFFF.toInt()
    private val muted = 0xFFB7C0C7.toInt()
    private val danger = 0xFFD32F2F.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = SettingsStore(this)
        askNotificationPermissionIfNeeded()
        showMain()
    }

    override fun onResume() {
        super.onResume()
        if (::content.isInitialized) showInicio()
    }

    private fun showMain() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

        root.addView(TextView(this).apply {
            setTextColor(textColor)
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            text = "Nexo Auto IA"
            setPadding(28, 35, 28, 12)
        })

        val tabsScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 0, 8, 8)
        }

        tabs.addView(tabButton("MENÚ") { showMenu() })
        tabs.addView(tabButton("INICIO") { showInicio() })
        tabs.addView(tabButton("GEMINI") { showRespuestaIA() })
        tabs.addView(tabButton("PERMISOS") { showPermisos() })
        tabs.addView(tabButton("CONTACTOS") { showContactos() })
        tabs.addView(tabButton("CONFIG") { showConfiguracion() })
        tabsScroll.addView(tabs)
        root.addView(tabsScroll)

        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 12, 20, 28)
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
        showInicio()
    }

    private fun tabButton(label: String, action: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            setTextColor(textColor)
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(18, 15, 18, 15)
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(-2, -2)
        }

    private fun showInicio() {
        content.removeAllViews()

        content.addView(cardView("Respuesta automática", if (settings.isBotEnabled()) "ACTIVADA" else "DESACTIVADA") {
            val sw = Switch(this@MainActivity)
            sw.isChecked = settings.isBotEnabled()
            sw.setOnCheckedChangeListener { _, checked ->
                settings.setBotEnabled(checked)
                toast(if (checked) "Bot activado" else "Bot desactivado")
                showInicio()
            }
            addView(sw)
        })

        val notificationStatus = if (isNotificationListenerEnabled()) "Activo" else "Falta activar"
        val geminiStatus = if (GeminiService.isValidKey(settings.getGeminiApiKey())) "Configurado" else "Falta API Key"
        val privacyStatus = if (settings.isPrivacyAccepted()) "Aceptada" else "Pendiente"

        content.addView(cardView("Estado del sistema", buildString {
            append("Permiso de notificaciones: $notificationStatus\n")
            append("Gemini: $geminiStatus\n")
            append("Privacidad: $privacyStatus\n")
            append("Modo respuesta: ${modeName(settings.getResponseMode())}\n")
            append("WhatsApp: ${settings.getWhatsappMode()}\n")
            append("Bot: ${if (settings.isBotEnabled()) "Activo" else "Pausado"}")
        }) {
            button("Abrir permisos") { showPermisos() }
            button("Configurar Gemini") { showRespuestaIA() }
            button("Probar respuesta") { showTestReply() }
        })

        content.addView(cardView("Checklist para funcionar", "1. Guarda API Key Gemini.\n2. Activa acceso a notificaciones.\n3. Acepta privacidad.\n4. Activa el bot.\n5. Cierra WhatsApp y espera una notificación.") {})
    }

    private fun showMenu() {
        content.removeAllViews()
        menuCard("Apps soportadas", "WhatsApp normal y WhatsApp Business.") { showAppsSoportadas() }
        menuCard("Respuesta de IA Gemini", "Configura API Key, modelo, prompt y prueba.") { showRespuestaIA() }
        menuCard("Respuesta por palabra clave", "Reglas tipo netflix=respuesta. Funcional.") { showKeywordScreen() }
        menuCard("Respuesta del menú", "Envía opciones 1, 2, 3, 4. Funcional.") { showMenuResponseScreen() }
        menuCard("Mensaje de bienvenida", "Configura mensaje inicial o modo bienvenida.") { showWelcomeScreen() }
        menuCard("Servidor", "Usa tu propio endpoint para responder. Funcional.") { showServerScreen() }
        menuCard("Respuesta de prueba", "Simula respuesta antes de usar WhatsApp.") { showTestReply() }
        menuCard("Historial", "Últimos mensajes detectados/respondidos.") { showHistorial() }
        menuCard("Notas", "Notas rápidas para copiar o recordar datos.") { showNotesScreen() }
        menuCard("Configuración", "Tiempo, respaldo y seguridad.") { showConfiguracion() }
    }

    private fun menuCard(title: String, desc: String, action: () -> Unit) {
        content.addView(cardView(title, desc) {
            setOnClickListener { action() }
            button("Abrir") { action() }
        })
    }

    private fun showAppsSoportadas() {
        content.removeAllViews()
        content.addView(label("Apps soportadas"))

        radio("WhatsApp normal y WhatsApp Business", settings.getWhatsappMode() == "BOTH") {
            settings.setWhatsappMode("BOTH"); showAppsSoportadas()
        }
        radio("Solo WhatsApp normal", settings.getWhatsappMode() == "NORMAL") {
            settings.setWhatsappMode("NORMAL"); showAppsSoportadas()
        }
        radio("Solo WhatsApp Business", settings.getWhatsappMode() == "BUSINESS") {
            settings.setWhatsappMode("BUSINESS"); showAppsSoportadas()
        }

        content.addView(cardView("Estado", "Modo actual: ${settings.getWhatsappMode()}") {})
        content.button("Volver al menú") { showMenu() }
    }

    private fun showRespuestaIA() {
        content.removeAllViews()
        content.addView(label("Gemini / Configuración"))

        val keyStatus = if (GeminiService.isValidKey(settings.getGeminiApiKey())) "API Key Gemini guardada." else "Falta API Key válida. Debe empezar por AIza."
        content.addView(cardView("Estado Gemini", keyStatus) {
            button("Guardar API Key Gemini") { showGeminiKeyScreen() }
            button("Modelo y límite") { showModelScreen() }
            button("Entrenar IA / Prompt") { showPromptScreen() }
            button("Usar modo IA Gemini") {
                settings.setResponseMode("GEMINI")
                toast("Modo Gemini activado")
                showInicio()
            }
            button("Probar Gemini") { showTestReply() }
        })

        content.addView(cardView("Modelo actual", settings.getGeminiModel()) {})
        content.addView(cardView("Modo actual", modeName(settings.getResponseMode())) {})
    }

    private fun showGeminiKeyScreen() {
        content.removeAllViews()
        content.addView(label("Paso 1: Guardar API Key Gemini"))

        content.addView(cardView("API Key de Gemini", "Pega la clave completa. Debe empezar por AIza. No compartas capturas con la clave visible.") {
            val keyInput = EditText(this@MainActivity).apply {
                setText(settings.getGeminiApiKey())
                setTextColor(textColor)
                setHintTextColor(muted)
                hint = "AIza..."
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                minLines = 1
                setSingleLine(true)
            }
            addView(keyInput)

            addPrimaryAction("GUARDAR API KEY GEMINI") {
                val key = keyInput.text.toString().trim()
                if (!GeminiService.isValidKey(key)) {
                    toast("No se guardó: debe empezar por AIza y estar completa")
                } else {
                    settings.setGeminiApiKey(key)
                    toast("API Key Gemini guardada")
                    showRespuestaIA()
                }
            }

            addSecondaryAction("BORRAR API KEY GUARDADA") {
                settings.setGeminiApiKey("")
                toast("API Key borrada")
                showGeminiKeyScreen()
            }
        })

        content.addView(cardView("Estado", if (GeminiService.isValidKey(settings.getGeminiApiKey())) "Guardada correctamente" else "Aún no hay API Key Gemini válida") {})
    }

    private fun showModelScreen() {
        content.removeAllViews()
        content.addView(label("Modelo y límite"))

        content.addView(cardView("Modelo de Gemini", "Recomendado: gemini-2.0-flash. También puedes probar gemini-1.5-flash.") {
            val modelInput = EditText(this@MainActivity).apply {
                setText(settings.getGeminiModel())
                setTextColor(textColor)
                setHintTextColor(muted)
                hint = "gemini-2.0-flash"
                setSingleLine(true)
            }
            addView(modelInput)

            val maxChars = EditText(this@MainActivity).apply {
                setText(settings.getMaxWhatsappChars().toString())
                setTextColor(textColor)
                setHintTextColor(muted)
                hint = "500"
                inputType = InputType.TYPE_CLASS_NUMBER
                setSingleLine(true)
            }
            smallText("Máximo de caracteres para WhatsApp")
            addView(maxChars)

            button("Guardar modelo") {
                settings.setGeminiModel(modelInput.text.toString().trim().ifBlank { "gemini-2.0-flash" })
                settings.setMaxWhatsappChars(maxChars.text.toString().toIntOrNull() ?: 500)
                toast("Modelo guardado")
                showRespuestaIA()
            }
        })
    }

    private fun showPromptScreen() {
        content.removeAllViews()
        content.addView(label("Entrenar IA"))

        content.addView(cardView("Prompt / entrenamiento", "Edita las reglas del asistente de Nexo E Store.") {
            val prompt = EditText(this@MainActivity).apply {
                setText(settings.getBusinessPrompt())
                setTextColor(textColor)
                setHintTextColor(muted)
                minLines = 8
                maxLines = 14
                gravity = Gravity.TOP
            }
            addView(prompt)

            button("Guardar entrenamiento") {
                settings.setBusinessPrompt(prompt.text.toString())
                toast("Entrenamiento guardado")
                showRespuestaIA()
            }
            button("Restaurar prompt de Nexo") {
                settings.setBusinessPrompt(SettingsStore.DEFAULT_NEXO_PROMPT)
                toast("Prompt restaurado")
                showPromptScreen()
            }
        })
    }

    private fun showKeywordScreen() {
        content.removeAllViews()
        content.addView(label("Respuesta por palabra clave"))

        content.addView(cardView("Reglas", "Formato: palabra=respuesta. Una regla por línea. La app revisa estas reglas antes de Gemini en modo automático.") {
            val input = EditText(this@MainActivity).apply {
                setText(settings.getKeywordRules())
                setTextColor(textColor)
                setHintTextColor(muted)
                minLines = 8
                maxLines = 14
                gravity = Gravity.TOP
            }
            addView(input)

            button("Guardar reglas") {
                settings.setKeywordRules(input.text.toString())
                toast("Reglas guardadas")
                showKeywordScreen()
            }
            button("Usar solo palabras clave") {
                settings.setResponseMode("KEYWORD")
                settings.setKeywordRules(input.text.toString())
                toast("Modo palabras clave activado")
                showInicio()
            }
            button("Usar automático: palabra clave + Gemini") {
                settings.setResponseMode("AUTO")
                settings.setKeywordRules(input.text.toString())
                toast("Modo automático activado")
                showInicio()
            }
        })

        content.addView(cardView("Prueba rápida", "Escribe una palabra como Disney, Netflix o Nequi en Respuesta de prueba.") {
            button("Probar") { showTestReply() }
        })
    }

    private fun showMenuResponseScreen() {
        content.removeAllViews()
        content.addView(label("Respuesta del menú"))

        content.addView(cardView("Mensaje de menú", "Este texto se enviará cuando el modo de respuesta sea MENÚ.") {
            val input = EditText(this@MainActivity).apply {
                setText(settings.getMenuMessage())
                setTextColor(textColor)
                setHintTextColor(muted)
                minLines = 6
                maxLines = 12
                gravity = Gravity.TOP
            }
            addView(input)

            button("Guardar menú") {
                settings.setMenuMessage(input.text.toString())
                toast("Menú guardado")
                showMenuResponseScreen()
            }
            button("Activar modo menú") {
                settings.setMenuMessage(input.text.toString())
                settings.setResponseMode("MENU")
                toast("Modo menú activado")
                showInicio()
            }
        })
    }

    private fun showWelcomeScreen() {
        content.removeAllViews()
        content.addView(label("Mensaje de bienvenida"))

        content.addView(cardView("Bienvenida", "Puedes usarlo como respuesta fija de bienvenida o como mensaje de respaldo.") {
            val input = EditText(this@MainActivity).apply {
                setText(settings.getWelcomeMessage())
                setTextColor(textColor)
                setHintTextColor(muted)
                minLines = 4
                maxLines = 8
                gravity = Gravity.TOP
            }
            addView(input)

            button("Guardar bienvenida") {
                settings.setWelcomeMessage(input.text.toString())
                toast("Bienvenida guardada")
                showWelcomeScreen()
            }
            button("Activar modo bienvenida") {
                settings.setWelcomeMessage(input.text.toString())
                settings.setResponseMode("WELCOME")
                toast("Modo bienvenida activado")
                showInicio()
            }
        })
    }

    private fun showServerScreen() {
        content.removeAllViews()
        content.addView(label("Servidor propio"))

        content.addView(cardView("URL del servidor", "Endpoint POST. Debe responder texto plano o JSON con campo reply. Ejemplo: https://tusitio.com/api/bot") {
            val input = EditText(this@MainActivity).apply {
                setText(settings.getServerUrl())
                setTextColor(textColor)
                setHintTextColor(muted)
                hint = "https://..."
                setSingleLine(true)
            }
            addView(input)

            button("Guardar URL") {
                settings.setServerUrl(input.text.toString())
                toast("Servidor guardado")
                showServerScreen()
            }
            button("Activar modo servidor") {
                settings.setServerUrl(input.text.toString())
                settings.setResponseMode("SERVER")
                toast("Modo servidor activado")
                showInicio()
            }
            button("Probar servidor") { showTestReply() }
        })
    }

    private fun showNotesScreen() {
        content.removeAllViews()
        content.addView(label("Notas"))

        content.addView(cardView("Notas internas", "Guarda datos útiles: números de pago, horarios, enlaces o pasos de venta.") {
            val input = EditText(this@MainActivity).apply {
                setText(settings.getNotes())
                setTextColor(textColor)
                setHintTextColor(muted)
                hint = "Ejemplo: Nequi: 3000000000"
                minLines = 8
                maxLines = 14
                gravity = Gravity.TOP
            }
            addView(input)
            button("Guardar notas") {
                settings.setNotes(input.text.toString())
                toast("Notas guardadas")
                showNotesScreen()
            }
        })
    }

    private fun showPermisos() {
        content.removeAllViews()
        content.addView(label("Permisos y seguridad"))

        content.addView(cardView("Acceso a notificaciones", if (isNotificationListenerEnabled()) "Activo. Nexo Auto IA puede detectar notificaciones." else "Pendiente. Activa Nexo Auto IA en acceso a notificaciones.") {
            button("Abrir acceso a notificaciones") {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        })

        content.addView(cardView("Optimización de batería", "Permite ejecución en segundo plano para mejores resultados.") {
            button("Abrir ajustes de batería") {
                try {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_SETTINGS))
                }
            }
        })

        content.addView(cardView("Privacidad", "La app lee notificaciones solo para detectar mensajes de WhatsApp y responder desde la notificación. La API Key se guarda localmente en tu teléfono.") {
            val accepted = CheckBox(this@MainActivity).apply {
                text = "Acepto usar esta app solo para mi negocio y no enviar spam."
                setTextColor(textColor)
                isChecked = settings.isPrivacyAccepted()
                setOnCheckedChangeListener { _, checked ->
                    settings.setPrivacyAccepted(checked)
                    toast(if (checked) "Privacidad aceptada" else "Privacidad pendiente")
                }
            }
            addView(accepted)
        })

        content.addView(cardView("Play Protect", "La app no pide contactos. Android puede alertar porque lee notificaciones y se instala fuera de Play Store.") {})
    }

    private fun showContactos() {
        content.removeAllViews()
        content.addView(label("Responder automáticamente a"))

        radio("Todos los chats", settings.getContactMode() == "ALL") {
            settings.setContactMode("ALL"); showContactos()
        }
        radio("Chats individuales / clientes nuevos", settings.getContactMode() == "INDIVIDUAL_ONLY") {
            settings.setContactMode("INDIVIDUAL_ONLY"); showContactos()
        }
        val groups = CheckBox(this).apply {
            text = "Habilitar grupos"
            setTextColor(textColor)
            isChecked = settings.areGroupsEnabled()
            setOnCheckedChangeListener { _, checked ->
                settings.setGroupsEnabled(checked)
                toast(if (checked) "Grupos habilitados" else "Grupos desactivados")
            }
        }
        content.addView(groups)

        content.addView(cardView("Recomendación para Nexo", "Usa chats individuales y grupos desactivados para evitar respuestas en conversaciones personales o grupos.") {})
    }

    private fun showConfiguracion() {
        content.removeAllViews()
        content.addView(label("Configuración general"))

        content.addView(cardView("Modo de respuesta", modeName(settings.getResponseMode())) {
            button("Automático: palabra clave + Gemini") { settings.setResponseMode("AUTO"); toast("Modo automático"); showInicio() }
            button("Solo Gemini") { settings.setResponseMode("GEMINI"); toast("Modo Gemini"); showInicio() }
            button("Solo palabras clave") { settings.setResponseMode("KEYWORD"); toast("Modo palabras clave"); showInicio() }
            button("Menú") { settings.setResponseMode("MENU"); toast("Modo menú"); showInicio() }
            button("Bienvenida") { settings.setResponseMode("WELCOME"); toast("Modo bienvenida"); showInicio() }
            button("Servidor") { settings.setResponseMode("SERVER"); toast("Modo servidor"); showInicio() }
        })

        content.addView(cardView("Tiempo de respuesta", "${settings.getResponseDelaySeconds()} segundos") {
            val input = EditText(this@MainActivity).apply {
                setText(settings.getResponseDelaySeconds().toString())
                setTextColor(textColor)
                setHintTextColor(muted)
                inputType = InputType.TYPE_CLASS_NUMBER
                setSingleLine(true)
            }
            addView(input)
            button("Guardar tiempo") {
                settings.setResponseDelaySeconds(input.text.toString().toIntOrNull() ?: 3)
                toast("Tiempo guardado")
                showConfiguracion()
            }
        })

        content.addView(cardView("Mensaje de respaldo", settings.getFallbackMessage()) {
            val input = EditText(this@MainActivity).apply {
                setText(settings.getFallbackMessage())
                setTextColor(textColor)
                setHintTextColor(muted)
                minLines = 3
                maxLines = 6
                gravity = Gravity.TOP
            }
            addView(input)
            button("Guardar respaldo") {
                settings.setFallbackMessage(input.text.toString())
                toast("Respaldo guardado")
                showConfiguracion()
            }
        })

        content.addView(cardView("Seguridad", "No compartas capturas donde tu API Key sea visible. Si la mostraste, bórrala en Google AI Studio y crea una nueva.") {
            button("Borrar API Key Gemini") {
                settings.setGeminiApiKey("")
                toast("API Key borrada")
                showRespuestaIA()
            }
        })
    }

    private fun showTestReply() {
        content.removeAllViews()
        content.addView(label("Respuesta de prueba"))

        val input = EditText(this).apply {
            hint = "Ejemplo: Hola, quiero Disney por un mes"
            setHintTextColor(muted)
            setTextColor(textColor)
            minLines = 3
            gravity = Gravity.TOP
        }
        content.addView(input)

        val result = TextView(this).apply {
            setTextColor(textColor)
            textSize = 16f
            setPadding(0, 18, 0, 18)
        }
        content.addView(result)

        content.button("Generar respuesta") {
            result.text = "Generando..."
            CoroutineScope(Dispatchers.IO).launch {
                val reply = AutoReplyEngine.generateReply(
                    customerName = "Cliente de prueba",
                    customerMessage = input.text.toString().ifBlank { "Hola, quiero Disney por un mes" },
                    settings = settings,
                    diagnostic = true
                )
                withContext(Dispatchers.Main) { result.text = reply }
            }
        }

        content.button("Volver a Gemini") { showRespuestaIA() }
    }

    private fun showHistorial() {
        content.removeAllViews()
        content.addView(label("Historial básico"))
        val logs = MessageHistoryStore(this).getLogs().ifBlank { "Aún no hay mensajes respondidos." }
        content.addView(cardView("Mensajes", logs) {
            button("Limpiar historial") {
                MessageHistoryStore(this@MainActivity).clear()
                showHistorial()
            }
        })
    }

    private fun radio(label: String, checked: Boolean, action: () -> Unit) {
        content.addView(RadioButton(this).apply {
            text = label
            setTextColor(textColor)
            isChecked = checked
            setOnClickListener { action() }
        })
    }

    private fun smallText(value: String) {
        content.addView(TextView(this).apply {
            text = value
            setTextColor(muted)
            textSize = 14f
            setPadding(0, 18, 0, 0)
        })
    }

    private fun cardView(title: String, desc: String, extra: LinearLayout.() -> Unit): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(card)
            setPadding(26, 22, 26, 22)
            val params = LinearLayout.LayoutParams(-1, -2)
            params.setMargins(0, 0, 0, 18)
            layoutParams = params

            addView(TextView(this@MainActivity).apply {
                text = title
                setTextColor(textColor)
                textSize = 20f
                typeface = Typeface.DEFAULT_BOLD
            })

            addView(TextView(this@MainActivity).apply {
                text = desc
                setTextColor(muted)
                textSize = 16f
                setPadding(0, 8, 0, 8)
            })

            extra()
        }

    private fun label(value: String): TextView =
        TextView(this).apply {
            text = value
            setTextColor(accent)
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 10, 0, 18)
        }

    private fun LinearLayout.addPrimaryAction(value: String, action: () -> Unit) {
        addView(TextView(this@MainActivity).apply {
            text = value
            setTextColor(textColor)
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setBackgroundColor(accent)
            setPadding(20, 18, 20, 18)
            setOnClickListener { action() }
            val params = LinearLayout.LayoutParams(-1, -2)
            params.setMargins(0, 16, 0, 0)
            layoutParams = params
        })
    }

    private fun LinearLayout.addSecondaryAction(value: String, action: () -> Unit) {
        addView(TextView(this@MainActivity).apply {
            text = value
            setTextColor(textColor)
            textSize = 14f
            gravity = Gravity.CENTER
            setBackgroundColor(0xFF24485A.toInt())
            setPadding(20, 16, 20, 16)
            setOnClickListener { action() }
            val params = LinearLayout.LayoutParams(-1, -2)
            params.setMargins(0, 12, 0, 0)
            layoutParams = params
        })
    }

    private fun LinearLayout.button(value: String, action: () -> Unit) {
        addView(Button(this@MainActivity).apply {
            text = value
            setTextColor(textColor)
            setBackgroundColor(accent)
            setOnClickListener { action() }
            val params = LinearLayout.LayoutParams(-1, -2)
            params.setMargins(0, 12, 0, 0)
            layoutParams = params
        })
    }

    private fun modeName(mode: String): String =
        when (mode) {
            "AUTO" -> "Automático: palabra clave + Gemini"
            "GEMINI" -> "Gemini IA"
            "KEYWORD" -> "Respuesta por palabra clave"
            "MENU" -> "Respuesta del menú"
            "WELCOME" -> "Mensaje de bienvenida"
            "SERVER" -> "Servidor propio"
            else -> mode
        }

    private fun isNotificationListenerEnabled(): Boolean {
        val enabledListeners = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        val componentName = ComponentName(this, NexoNotificationListener::class.java).flattenToString()
        return enabledListeners.contains(componentName)
    }

    private fun askNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
    }

    private fun toast(value: String) {
        Toast.makeText(this, value, Toast.LENGTH_SHORT).show()
    }
}
