package com.nexoestore.autoia

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class NexoNotificationListener : NotificationListenerService() {

    private val scope = CoroutineScope(Dispatchers.IO)
    private val processedMessages = LinkedHashSet<String>()
    private val recentBotReplies = LinkedHashMap<String, Long>()
    private val lastReplyAtByChat = HashMap<String, Long>()

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val settings = SettingsStore(applicationContext)
        if (!ContactRules.supportsPackage(sbn.packageName, settings)) return

        val notification = sbn.notification ?: return
        val extras = notification.extras

        val chatTitle = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val messageText = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()

        if (chatTitle.isBlank() || messageText.isBlank()) return
        if (messageText.contains("mensajes nuevos", ignoreCase = true)) return
        if (messageText.contains("new messages", ignoreCase = true)) return
        if (messageText.contains("escribiendo", ignoreCase = true)) return

        val normalizedText = normalize(messageText)

        // Anti-bucle: ignora textos que el propio bot acaba de enviar.
        if (isRecentBotReply(normalizedText)) {
            settings.setLastDiagnostic("Ignorado para evitar bucle: el mensaje coincide con una respuesta reciente del bot.")
            return
        }

        val normalizedKey = "${sbn.packageName}-${chatTitle.lowercase()}-$normalizedText".take(300)
        if (processedMessages.contains(normalizedKey)) return
        processedMessages.add(normalizedKey)
        trimProcessedMessages()

        val replyAction = notification.actions?.firstOrNull { action ->
            action.remoteInputs?.isNotEmpty() == true
        } ?: run {
            settings.setLastDiagnostic("No se encontró acción de respuesta rápida en la notificación.")
            return
        }

        scope.launch {
            try {
                if (!settings.isBotEnabled()) return@launch
                if (!ContactRules.shouldReply(applicationContext, chatTitle, messageText, settings)) return@launch

                // Evita ráfagas: WhatsApp puede publicar varias notificaciones del mismo chat.
                val chatKey = "${sbn.packageName}-${chatTitle.lowercase()}"
                val now = System.currentTimeMillis()
                val lastAt = lastReplyAtByChat[chatKey] ?: 0L
                if (now - lastAt < 7000L) {
                    settings.setLastDiagnostic("Ignorado por anti-ráfaga: último envío hace menos de 7 segundos.")
                    return@launch
                }

                val delayMillis = settings.getResponseDelaySeconds().coerceIn(0, 60) * 1000L
                if (delayMillis > 0) delay(delayMillis)

                // Revisa otra vez después del delay por si otro evento ya respondió.
                val nowAfterDelay = System.currentTimeMillis()
                val lastAtAfterDelay = lastReplyAtByChat[chatKey] ?: 0L
                if (nowAfterDelay - lastAtAfterDelay < 7000L) return@launch

                val result = AutoReplyEngine.generateReplyDetailed(
                    customerName = chatTitle,
                    customerMessage = messageText,
                    settings = settings
                )
                settings.setLastDiagnostic(result.diagnostic)

                if (!result.ok && result.text.isBlank()) return@launch
                if (result.text.isBlank()) return@launch

                sendReply(replyAction, result.text)
                lastReplyAtByChat[chatKey] = System.currentTimeMillis()
                rememberBotReply(result.text)
                MessageHistoryStore(applicationContext).addLog(chatTitle, messageText, result.text, result.diagnostic)
            } catch (e: Exception) {
                settings.setLastDiagnostic("Error general en notificación: ${e.javaClass.simpleName}: ${e.message}")
            }
        }
    }

    private fun sendReply(action: Notification.Action, message: String) {
        val remoteInput = action.remoteInputs?.firstOrNull() ?: return

        val intent = Intent()
        val bundle = Bundle()
        bundle.putCharSequence(remoteInput.resultKey, message)
        RemoteInput.addResultsToIntent(arrayOf(remoteInput), intent, bundle)

        try {
            action.actionIntent.send(this, 0, intent)
        } catch (e: PendingIntent.CanceledException) {
            SettingsStore(applicationContext).setLastDiagnostic("No se pudo enviar respuesta: ${e.message}")
        }
    }

    private fun normalize(value: String): String {
        return value.lowercase()
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(500)
    }

    private fun rememberBotReply(reply: String) {
        val normalized = normalize(reply)
        if (normalized.isBlank()) return
        recentBotReplies[normalized] = System.currentTimeMillis()
        trimRecentBotReplies()
    }

    private fun isRecentBotReply(message: String): Boolean {
        val now = System.currentTimeMillis()
        trimRecentBotReplies()
        return recentBotReplies.any { (reply, createdAt) ->
            now - createdAt < 120_000L && (
                message == reply ||
                message.contains(reply.take(80)) ||
                reply.contains(message.take(80))
            )
        }
    }

    private fun trimRecentBotReplies() {
        val now = System.currentTimeMillis()
        val iterator = recentBotReplies.entries.iterator()
        while (iterator.hasNext()) {
            val item = iterator.next()
            if (now - item.value > 120_000L) iterator.remove()
        }
        while (recentBotReplies.size > 30) {
            val firstKey = recentBotReplies.keys.firstOrNull() ?: break
            recentBotReplies.remove(firstKey)
        }
    }

    private fun trimProcessedMessages() {
        if (processedMessages.size > 250) {
            val iterator = processedMessages.iterator()
            repeat(80) {
                if (iterator.hasNext()) {
                    iterator.next()
                    iterator.remove()
                }
            }
        }
    }
}
