# Nexo Auto IA

Proyecto base Android para una APK tipo Whatauto, personalizada para Nexo E Store.

## Qué incluye

- App Android nativa en Kotlin.
- Diseño oscuro tipo panel.
- Pantallas:
  - Inicio
  - Menú
  - Contactos
  - Configuración
  - Respuesta de IA
  - Respuesta de prueba
  - Historial básico
- Servicio `NotificationListenerService` para leer notificaciones de WhatsApp.
- Respuesta automática usando `RemoteInput`.
- Integración con OpenAI / ChatGPT.
- Soporte para:
  - WhatsApp normal: `com.whatsapp`
  - WhatsApp Business: `com.whatsapp.w4b`

## Cómo abrir el proyecto

1. Instala Android Studio.
2. Abre Android Studio.
3. Selecciona **Open**.
4. Elige la carpeta `NexoAutoIA`.
5. Espera a que Gradle sincronice.
6. Conecta tu teléfono Android.
7. Ejecuta la app.

## Cómo generar APK

En Android Studio:

```txt
Build
↓
Build Bundle(s) / APK(s)
↓
Build APK(s)
```

APK debug:

```txt
app/build/outputs/apk/debug/app-debug.apk
```

## Configuración en el teléfono

1. Instala la APK.
2. Abre **Nexo Auto IA**.
3. Entra a **Respuesta de IA**.
4. Pega tu API Key de OpenAI.
5. Guarda.
6. Vuelve a **Inicio**.
7. Toca **Abrir permiso de notificaciones**.
8. Activa el permiso para **Nexo Auto IA**.
9. Activa el switch de respuesta automática.
10. Prueba enviando un mensaje a WhatsApp desde otro teléfono.

## Recomendación inicial

- Contactos: `Números no guardados / clientes nuevos`
- Grupos: desactivado
- Tiempo de respuesta: 3 segundos
- Modelo: `gpt-4o-mini`

## Advertencias

Esta versión responde desde las notificaciones del teléfono. Por eso:

- El celular debe estar encendido.
- WhatsApp debe tener notificaciones activas.
- La conversación debe mostrar botón de respuesta rápida.
- Android puede limitar la app si el ahorro de batería está activo.
- No uses esta app para spam ni mensajes masivos.

## Próximas mejoras sugeridas

- Palabras clave: Netflix, Disney, Nequi, soporte.
- Menú automático 1, 2, 3, 4.
- Horario de atención.
- Productos y precios editables.
- Lista permitida y bloqueada.
- Backup local.
- Bloqueo con PIN.
- Compilación firmada para versión release.
